import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:file_picker/file_picker.dart';

class BuildAppPage extends StatefulWidget {
  const BuildAppPage({super.key});
  @override
  State<BuildAppPage> createState() => _BuildAppPageState();
}

class _BuildAppPageState extends State<BuildAppPage> with TickerProviderStateMixin {
  static const Color primary = Color(0xFF00E5CC);
  static const Color bg = Color(0xFF060E17);
  static const Color card = Color(0xFF0D1F2D);
  static const Color card2 = Color(0xFF111E2B);
  static const Color accent = Color(0xFF00BFA5);

  final List<String> _steps = [
    'Validasi Token','Siapkan Repo','Upload ZIP',
    'Push Workflow','Trigger Build','Queue & Setup',
    'Flutter Build','Ambil APK',
  ];
  final List<IconData> _stepIcons = [
    Icons.verified_user_rounded, Icons.folder_special_rounded, Icons.upload_file_rounded,
    Icons.code_rounded, Icons.play_circle_rounded, Icons.hourglass_empty_rounded,
    Icons.build_rounded, Icons.download_rounded,
  ];

  final TextEditingController _tokenCtrl = TextEditingController();
  bool _tokenVisible = false;
  bool _isBuilding = false;
  bool _isDone = false;
  bool _isError = false;
  String _status = '';
  String _downloadLink = '';
  String _repoName = '';
  String _runId = '';
  int _currentStep = -1;
  int _progress = 0;
  Timer? _pollTimer;
  List<String> _logs = [];

  // File ZIP
  String? _zipFileName;
  Uint8List? _zipBytes;
  int _zipSizeKb = 0;

  late AnimationController _pulseCtrl;
  late Animation<double> _pulseAnim;
  late AnimationController _glowCtrl;
  late Animation<double> _glowAnim;

  @override
  void initState() {
    super.initState();
    _pulseCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 2))..repeat(reverse: true);
    _pulseAnim = Tween<double>(begin: 0.4, end: 1.0).animate(CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut));
    _glowCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 3))..repeat(reverse: true);
    _glowAnim = Tween<double>(begin: 0.5, end: 1.0).animate(CurvedAnimation(parent: _glowCtrl, curve: Curves.easeInOut));
    _loadSavedToken();
  }

  @override
  void dispose() {
    _tokenCtrl.dispose();
    _pollTimer?.cancel();
    _pulseCtrl.dispose();
    _glowCtrl.dispose();
    super.dispose();
  }

  Future<void> _loadSavedToken() async {
    final prefs = await SharedPreferences.getInstance();
    final saved = prefs.getString('ghp_token') ?? '';
    if (saved.isNotEmpty && mounted) setState(() => _tokenCtrl.text = saved);
  }

  Future<void> _saveToken(String token) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('ghp_token', token);
  }

  Future<void> _pickZip() async {
    try {
      final result = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: ['zip'],
        withData: true,
      );
      if (result != null && result.files.isNotEmpty) {
        final file = result.files.first;
        if (file.bytes == null) { _showSnack('Gagal baca file'); return; }
        setState(() {
          _zipFileName = file.name;
          _zipBytes = file.bytes;
          _zipSizeKb = (file.size / 1024).round();
        });
        _showSnack('ZIP dipilih: ${file.name}');
      }
    } catch (e) {
      _showSnack('Error pilih file: $e');
    }
  }

  Future<void> _startBuild() async {
    final token = _tokenCtrl.text.trim();
    if (token.isEmpty) { _showSnack('Masukkan GitHub Token dulu'); return; }
    if (!token.startsWith('ghp_') && !token.startsWith('github_pat_')) {
      _showSnack('Token harus dimulai ghp_ atau github_pat_'); return;
    }
    if (_zipBytes == null || _zipFileName == null) {
      _showSnack('Pilih file ZIP Flutter dulu'); return;
    }
    if (_zipBytes!.length > 50 * 1024 * 1024) {
      _showSnack('ZIP terlalu besar (maks 50 MB)'); return;
    }

    await _saveToken(token);
    setState(() {
      _isBuilding = true; _isDone = false; _isError = false;
      _status = 'Memulai...'; _downloadLink = ''; _repoName = '';
      _runId = ''; _currentStep = 0; _progress = 0;
      _logs = ['[${_time()}] ⚡ GitHub Actions Builder dimulai'];
    });

    try {
      _setStep(0, 'Memvalidasi GitHub Token...');
      final user = await _validateToken(token);
      if (user == null) { _setError('Token tidak valid atau expired'); return; }
      _addLog('[${_time()}] ✅ Token valid. User: $user');

      _setStep(1, 'Membuat repository build...');
      _repoName = 'kzx-build-${DateTime.now().millisecondsSinceEpoch}';
      final repoCreated = await _createRepo(token, user, _repoName);
      if (!repoCreated) { _setError('Gagal buat repo GitHub'); return; }
      _addLog('[${_time()}] ✅ Repo dibuat: $user/$_repoName');
      await Future.delayed(const Duration(seconds: 2));

      _setStep(2, 'Upload ZIP ke repo...');
      final uploaded = await _uploadZipBytes(token, user, _repoName, _zipBytes!);
      if (!uploaded) { _setError('Gagal upload ZIP ke repo'); return; }
      _addLog('[${_time()}] ✅ ZIP berhasil di-upload ($_zipSizeKb KB)');
      await Future.delayed(const Duration(seconds: 1));

      _setStep(3, 'Push GitHub Actions workflow...');
      final wfPushed = await _pushWorkflow(token, user, _repoName);
      if (!wfPushed) { _setError('Gagal push workflow'); return; }
      _addLog('[${_time()}] ✅ Workflow .yml di-push');
      await Future.delayed(const Duration(seconds: 2));

      _setStep(4, 'Trigger build via GitHub Actions...');
      final triggered = await _triggerWorkflow(token, user, _repoName);
      if (!triggered) { _setError('Gagal trigger workflow'); return; }
      _addLog('[${_time()}] ✅ Build di-trigger');

      _setStep(5, 'Menunggu runner antri...');
      _startPolling(token, user, _repoName);

    } catch (e) {
      _setError('Error: $e');
    }
  }

  Future<String?> _validateToken(String token) async {
    try {
      final res = await http.get(Uri.parse('https://api.github.com/user'),
        headers: {'Authorization': 'token $token', 'Accept': 'application/vnd.github+json'},
      ).timeout(const Duration(seconds: 15));
      if (res.statusCode == 200) return jsonDecode(res.body)['login'] as String?;
    } catch (_) {}
    return null;
  }

  Future<bool> _createRepo(String token, String user, String repoName) async {
    try {
      final res = await http.post(Uri.parse('https://api.github.com/user/repos'),
        headers: {'Authorization': 'token $token', 'Accept': 'application/vnd.github+json', 'Content-Type': 'application/json'},
        body: jsonEncode({'name': repoName, 'private': false, 'auto_init': true, 'description': 'Flutter build via XCUBE'}),
      ).timeout(const Duration(seconds: 20));
      return res.statusCode == 201;
    } catch (_) { return false; }
  }

  Future<bool> _uploadZipBytes(String token, String user, String repoName, Uint8List bytes) async {
    try {
      _addLog('[${_time()}] Mengupload ZIP (${(bytes.length / 1024).toStringAsFixed(1)} KB)...');
      final b64 = base64Encode(bytes);
      final res = await http.put(
        Uri.parse('https://api.github.com/repos/$user/$repoName/contents/project.zip'),
        headers: {'Authorization': 'token $token', 'Accept': 'application/vnd.github+json', 'Content-Type': 'application/json'},
        body: jsonEncode({'message': 'Upload Flutter project ZIP', 'content': b64}),
      ).timeout(const Duration(seconds: 120));
      return res.statusCode == 201;
    } catch (e) { _addLog('[${_time()}] Upload error: $e'); return false; }
  }

  Future<bool> _pushWorkflow(String token, String user, String repoName) async {
    const yml = r'''name: Build Flutter APK
on:
  push:
    branches: [ main ]
  workflow_dispatch:
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - name: Setup Java
        uses: actions/setup-java@v4
        with:
          distribution: 'zulu'
          java-version: '17'
      - name: Extract ZIP
        run: |
          unzip -o project.zip -d extracted || true
          if [ -d "extracted" ]; then
            SUBFOLDER=$(ls extracted | head -1)
            if [ -d "extracted/$SUBFOLDER/lib" ]; then
              cp -r extracted/$SUBFOLDER/. ./
            else
              cp -r extracted/. ./
            fi
          fi
      - uses: subosito/flutter-action@v2
        with:
          channel: 'stable'
          flutter-version-file: pubspec.yaml
      - name: Setup Android NDK
        run: echo "y" | $ANDROID_SDK_ROOT/cmdline-tools/latest/bin/sdkmanager "ndk;28.2.13676358" || true
      - run: flutter pub get
      - run: flutter build apk --release --no-tree-shake-icons
      - uses: actions/upload-artifact@v4
        with:
          name: release-apk
          path: build/app/outputs/flutter-apk/app-release.apk
''';
    try {
      final b64 = base64Encode(utf8.encode(yml));
      final res = await http.put(
        Uri.parse('https://api.github.com/repos/$user/$repoName/contents/.github/workflows/build.yml'),
        headers: {'Authorization': 'token $token', 'Accept': 'application/vnd.github+json', 'Content-Type': 'application/json'},
        body: jsonEncode({'message': 'Add Flutter workflow', 'content': b64}),
      ).timeout(const Duration(seconds: 20));
      return res.statusCode == 201;
    } catch (_) { return false; }
  }

  Future<bool> _triggerWorkflow(String token, String user, String repoName) async {
    try {
      final res = await http.post(
        Uri.parse('https://api.github.com/repos/$user/$repoName/actions/workflows/build.yml/dispatches'),
        headers: {'Authorization': 'token $token', 'Accept': 'application/vnd.github+json', 'Content-Type': 'application/json'},
        body: jsonEncode({'ref': 'main'}),
      ).timeout(const Duration(seconds: 20));
      return res.statusCode == 204;
    } catch (_) { return false; }
  }

  void _startPolling(String token, String user, String repoName) {
    int attempt = 0;
    _pollTimer = Timer.periodic(const Duration(seconds: 10), (timer) async {
      attempt++;
      try {
        final res = await http.get(
          Uri.parse('https://api.github.com/repos/$user/$repoName/actions/runs?per_page=1'),
          headers: {'Authorization': 'token $token', 'Accept': 'application/vnd.github+json'},
        ).timeout(const Duration(seconds: 15));
        if (res.statusCode != 200) return;
        final runs = jsonDecode(res.body)['workflow_runs'] as List?;
        if (runs == null || runs.isEmpty) return;
        final run = runs.first;
        _runId = run['id'].toString();
        final status = run['status'] as String? ?? '';
        final conclusion = run['conclusion'] as String? ?? '';
        _addLog('[${_time()}] Run #$_runId · $status · $conclusion');
        if (status == 'queued') {
          _setStep(5, 'Runner antri...');
          setState(() => _progress = 22);
        } else if (status == 'in_progress') {
          _setStep(6, 'Flutter build berjalan...');
          setState(() => _progress = (_progress + 5).clamp(35, 88));
        } else if (status == 'completed') {
          timer.cancel();
          if (conclusion == 'success') {
            _setStep(7, 'Build selesai! Mengambil APK...');
            setState(() => _progress = 96);
            await Future.delayed(const Duration(seconds: 2));
            final apkUrl = await _getArtifactUrl(token, user, repoName, _runId);
            _setDone(apkUrl ?? 'https://github.com/$user/$repoName/actions/runs/$_runId');
          } else {
            _setError('Build gagal ($conclusion). Cek GitHub Actions.');
          }
        }
        if (attempt >= 90) { timer.cancel(); _setError('Build timeout (15 menit).'); }
      } catch (e) { _addLog('[${_time()}] Poll error: $e'); }
    });
  }

  Future<String?> _getArtifactUrl(String token, String user, String repoName, String runId) async {
    try {
      final res = await http.get(
        Uri.parse('https://api.github.com/repos/$user/$repoName/actions/runs/$runId/artifacts'),
        headers: {'Authorization': 'token $token', 'Accept': 'application/vnd.github+json'},
      ).timeout(const Duration(seconds: 15));
      if (res.statusCode == 200) {
        final arts = jsonDecode(res.body)['artifacts'] as List?;
        if (arts != null && arts.isNotEmpty) return arts.first['archive_download_url'] as String?;
      }
    } catch (_) {}
    return null;
  }

  void _setStep(int step, String msg) {
    if (!mounted) return;
    setState(() {
      _currentStep = step;
      _status = msg;
      _progress = ((step / (_steps.length - 1)) * 100).toInt().clamp(0, 95);
    });
    _addLog('[${_time()}] → ${_steps[step.clamp(0, _steps.length-1)]}: $msg');
  }

  void _setDone(String link) {
    if (!mounted) return;
    setState(() { _isBuilding = false; _isDone = true; _isError = false; _downloadLink = link; _progress = 100; _currentStep = _steps.length - 1; _status = 'Build selesai! APK siap.'; });
    _addLog('[${_time()}] ✅ Build sukses!');
  }

  void _setError(String msg) {
    if (!mounted) return;
    setState(() { _isBuilding = false; _isDone = false; _isError = true; _status = msg; });
    _addLog('[${_time()}] ❌ $msg');
  }

  void _addLog(String msg) {
    if (!mounted) return;
    setState(() { _logs.add(msg); if (_logs.length > 100) _logs.removeAt(0); });
  }

  String _time() {
    final n = DateTime.now();
    return "${n.hour.toString().padLeft(2, '0')}:${n.minute.toString().padLeft(2, '0')}:${n.second.toString().padLeft(2, '0')}";
  }

  void _showSnack(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(msg, style: const TextStyle(fontFamily: 'ShareTechMono', fontSize: 12)),
        backgroundColor: card2, duration: const Duration(seconds: 2)));
  }

  void _reset() {
    _pollTimer?.cancel();
    setState(() {
      _isBuilding = false; _isDone = false; _isError = false;
      _status = ''; _downloadLink = ''; _repoName = ''; _runId = '';
      _currentStep = -1; _progress = 0; _logs = [];
      _zipFileName = null; _zipBytes = null; _zipSizeKb = 0;
    });
  }

  // ═══════════════════════ UI ═══════════════════════
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bg,
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(colors: [Color(0xFF060E17), Color(0xFF071520)], begin: Alignment.topCenter, end: Alignment.bottomCenter),
        ),
        child: SafeArea(
          child: Column(children: [
            _buildHeader(),
            Expanded(
              child: SingleChildScrollView(
                physics: const BouncingScrollPhysics(),
                padding: const EdgeInsets.fromLTRB(16, 4, 16, 32),
                child: Column(children: [
                  _buildHeroCard(),
                  const SizedBox(height: 14),
                  _buildStepsChips(),
                  const SizedBox(height: 14),
                  _buildTokenCard(),
                  const SizedBox(height: 14),
                  _buildZipCard(),
                  const SizedBox(height: 14),
                  _buildInfoCards(),
                  if (_isBuilding || _isDone || _isError) ...[
                    const SizedBox(height: 14),
                    _buildProgressCard(),
                  ],
                  if (_isDone && _downloadLink.isNotEmpty) ...[
                    const SizedBox(height: 14),
                    _buildDownloadCard(),
                  ],
                  if (_logs.isNotEmpty) ...[
                    const SizedBox(height: 14),
                    _buildLogsCard(),
                  ],
                  const SizedBox(height: 20),
                  _buildActionButton(),
                ]),
              ),
            ),
          ]),
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
      child: Row(children: [
        GestureDetector(
          onTap: () => Navigator.pop(context),
          child: Container(
            width: 40, height: 40,
            decoration: BoxDecoration(color: primary.withOpacity(0.15), borderRadius: BorderRadius.circular(12), border: Border.all(color: primary.withOpacity(0.4))),
            child: const Icon(Icons.arrow_back_ios_new_rounded, color: primary, size: 18),
          ),
        ),
        const SizedBox(width: 12),
        Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('GitHub Actions Builder', style: TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.w900, fontFamily: 'Orbitron', letterSpacing: 1)),
          Text('Build APK via GitHub', style: TextStyle(color: Colors.white.withOpacity(0.4), fontSize: 10, fontFamily: 'ShareTechMono')),
        ]),
        const Spacer(),
        AnimatedBuilder(
          animation: _glowAnim,
          builder: (_, __) => Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
            decoration: BoxDecoration(color: primary.withOpacity(0.1 * _glowAnim.value), borderRadius: BorderRadius.circular(16), border: Border.all(color: primary.withOpacity(0.3))),
            child: Row(mainAxisSize: MainAxisSize.min, children: [
              Container(width: 6, height: 6, decoration: const BoxDecoration(color: primary, shape: BoxShape.circle)),
              const SizedBox(width: 5),
              const Text('MANTA', style: TextStyle(color: primary, fontSize: 10, fontFamily: 'ShareTechMono', fontWeight: FontWeight.bold)),
            ]),
          ),
        ),
      ]),
    );
  }

  Widget _buildHeroCard() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: LinearGradient(colors: [primary.withOpacity(0.12), const Color(0xFF0D3040)], begin: Alignment.topLeft, end: Alignment.bottomRight),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: primary.withOpacity(0.25)),
      ),
      child: Row(children: [
        Container(
          width: 56, height: 56,
          decoration: BoxDecoration(gradient: LinearGradient(colors: [primary, accent]), borderRadius: BorderRadius.circular(16), boxShadow: [BoxShadow(color: primary.withOpacity(0.4), blurRadius: 12)]),
          child: const Icon(Icons.bolt_rounded, color: Colors.black, size: 30),
        ),
        const SizedBox(width: 14),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('MANTA GitHub Actions Builder', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 13, fontFamily: 'Orbitron')),
          const SizedBox(height: 4),
          Text('Tanpa VPS · Tanpa SSH · Cukup token GitHub', style: TextStyle(color: Colors.white.withOpacity(0.55), fontSize: 10, fontFamily: 'ShareTechMono')),
          const SizedBox(height: 2),
          Text('Upload ZIP → build APK → notifikasi otomatis', style: TextStyle(color: primary.withOpacity(0.8), fontSize: 10, fontFamily: 'ShareTechMono')),
        ])),
      ]),
    );
  }

  Widget _buildStepsChips() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(color: card, borderRadius: BorderRadius.circular(20), border: Border.all(color: Colors.white.withOpacity(0.06))),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('8 LANGKAH OTOMATIS VIA GITHUB API', style: TextStyle(color: Colors.white.withOpacity(0.35), fontSize: 9, fontFamily: 'ShareTechMono', letterSpacing: 1.5)),
        const SizedBox(height: 12),
        Wrap(
          spacing: 8, runSpacing: 8,
          children: List.generate(_steps.length, (i) {
            final isActive = _currentStep == i;
            final isDone = _currentStep > i;
            final c = isDone ? const Color(0xFF00C853) : isActive ? primary : Colors.white.withOpacity(0.25);
            return AnimatedContainer(
              duration: const Duration(milliseconds: 300),
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
              decoration: BoxDecoration(
                color: isActive ? primary.withOpacity(0.15) : isDone ? Colors.green.withOpacity(0.08) : Colors.transparent,
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: c.withOpacity(isActive ? 0.8 : 0.45)),
              ),
              child: Row(mainAxisSize: MainAxisSize.min, children: [
                Icon(_stepIcons[i], color: c, size: 12),
                const SizedBox(width: 5),
                Text(_steps[i], style: TextStyle(color: c, fontSize: 10, fontFamily: 'ShareTechMono', fontWeight: isActive ? FontWeight.bold : FontWeight.normal)),
              ]),
            );
          }),
        ),
      ]),
    );
  }

  Widget _buildTokenCard() {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(color: card, borderRadius: BorderRadius.circular(20), border: Border.all(color: primary.withOpacity(0.2))),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Container(width: 38, height: 38, decoration: BoxDecoration(color: primary.withOpacity(0.12), borderRadius: BorderRadius.circular(10), border: Border.all(color: primary.withOpacity(0.3))),
            child: const Icon(Icons.key_rounded, color: primary, size: 18)),
          const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('GitHub Personal Access Token', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 12, fontFamily: 'Orbitron')),
            Text('GHP Token · Settings › Developer Settings › PAT', style: TextStyle(color: Colors.white.withOpacity(0.35), fontSize: 9, fontFamily: 'ShareTechMono')),
          ])),
        ]),
        const SizedBox(height: 14),
        Container(
          decoration: BoxDecoration(color: card2, borderRadius: BorderRadius.circular(14), border: Border.all(color: Colors.white10)),
          child: TextField(
            controller: _tokenCtrl, obscureText: !_tokenVisible,
            style: const TextStyle(color: Colors.white, fontSize: 13, fontFamily: 'ShareTechMono'),
            cursorColor: primary,
            decoration: InputDecoration(
              hintText: 'ghp_xxxxxxxxxxxxxxxxxxxx',
              hintStyle: TextStyle(color: Colors.white.withOpacity(0.2), fontFamily: 'ShareTechMono', fontSize: 12),
              prefixIcon: const Padding(padding: EdgeInsets.only(left: 14, right: 8), child: Icon(Icons.lock_outline_rounded, color: Colors.white38, size: 18)),
              prefixIconConstraints: const BoxConstraints(minWidth: 40),
              suffixIcon: IconButton(
                icon: Icon(_tokenVisible ? Icons.visibility_off_rounded : Icons.visibility_rounded, color: Colors.white38, size: 18),
                onPressed: () => setState(() => _tokenVisible = !_tokenVisible),
              ),
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
              enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
              focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: const BorderSide(color: primary, width: 1.5)),
              contentPadding: const EdgeInsets.symmetric(vertical: 14, horizontal: 14),
            ),
          ),
        ),
        const SizedBox(height: 12),
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(color: primary.withOpacity(0.04), borderRadius: BorderRadius.circular(12), border: Border.all(color: primary.withOpacity(0.15))),
          child: Column(children: [
            Row(children: [
              const Icon(Icons.info_outline_rounded, color: primary, size: 12),
              const SizedBox(width: 6),
              Text('Scope token yang dibutuhkan', style: TextStyle(color: primary, fontSize: 10, fontFamily: 'ShareTechMono')),
            ]),
            const SizedBox(height: 8),
            Row(children: [
              _scopeChip('repo'),
              const SizedBox(width: 8),
              Expanded(child: Text('Akses penuh ke repo (push workflow & ZIP)', style: TextStyle(color: Colors.white.withOpacity(0.45), fontSize: 10, fontFamily: 'ShareTechMono'))),
            ]),
            const SizedBox(height: 6),
            Row(children: [
              _scopeChip('workflow'),
              const SizedBox(width: 8),
              Expanded(child: Text('Buat & jalankan GitHub Actions workflow', style: TextStyle(color: Colors.white.withOpacity(0.45), fontSize: 10, fontFamily: 'ShareTechMono'))),
            ]),
          ]),
        ),
      ]),
    );
  }

  Widget _scopeChip(String label) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
    decoration: BoxDecoration(color: primary.withOpacity(0.15), borderRadius: BorderRadius.circular(6), border: Border.all(color: primary.withOpacity(0.4))),
    child: Text(label, style: const TextStyle(color: primary, fontSize: 10, fontFamily: 'ShareTechMono', fontWeight: FontWeight.bold)),
  );

  Widget _buildZipCard() {
    final hasFile = _zipBytes != null;
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(color: card, borderRadius: BorderRadius.circular(20), border: Border.all(color: primary.withOpacity(0.2))),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Container(width: 38, height: 38, decoration: BoxDecoration(color: primary.withOpacity(0.12), borderRadius: BorderRadius.circular(10), border: Border.all(color: primary.withOpacity(0.3))),
            child: const Icon(Icons.folder_zip_rounded, color: primary, size: 18)),
          const SizedBox(width: 12),
          const Text('Upload Project Flutter (ZiP)', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 12, fontFamily: 'Orbitron')),
        ]),
        const SizedBox(height: 14),
        GestureDetector(
          onTap: _isBuilding ? null : _pickZip,
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 200),
            width: double.infinity,
            padding: const EdgeInsets.symmetric(vertical: 28),
            decoration: BoxDecoration(
              color: hasFile ? primary.withOpacity(0.08) : card2,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: hasFile ? primary.withOpacity(0.5) : Colors.white10),
            ),
            child: Column(children: [
              AnimatedSwitcher(
                duration: const Duration(milliseconds: 300),
                child: Container(
                  key: ValueKey(hasFile),
                  width: 52, height: 52,
                  decoration: BoxDecoration(
                    color: hasFile ? primary.withOpacity(0.2) : primary.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(14),
                    border: hasFile ? Border.all(color: primary.withOpacity(0.5)) : null,
                  ),
                  child: Icon(hasFile ? Icons.check_circle_rounded : Icons.upload_file_rounded, color: primary, size: 28),
                ),
              ),
              const SizedBox(height: 12),
              Text(
                hasFile ? _zipFileName! : 'Ketuk untuk pilih file ZiP',
                style: TextStyle(color: hasFile ? primary : Colors.white, fontSize: 13, fontFamily: 'Orbitron', fontWeight: FontWeight.bold),
                textAlign: TextAlign.center, maxLines: 1, overflow: TextOverflow.ellipsis,
              ),
              const SizedBox(height: 4),
              Text(
                hasFile ? '$_zipSizeKb KB · Siap di-upload' : 'ZiP project Flutter kamu (pubspec.yaml harus ada di dalam)',
                style: TextStyle(color: Colors.white.withOpacity(0.4), fontSize: 10, fontFamily: 'ShareTechMono'),
                textAlign: TextAlign.center,
              ),
              if (hasFile) ...[
                const SizedBox(height: 10),
                GestureDetector(
                  onTap: _isBuilding ? null : () => setState(() { _zipFileName = null; _zipBytes = null; _zipSizeKb = 0; }),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
                    decoration: BoxDecoration(color: Colors.red.withOpacity(0.1), borderRadius: BorderRadius.circular(8), border: Border.all(color: Colors.red.withOpacity(0.3))),
                    child: const Text('Ganti File', style: TextStyle(color: Colors.redAccent, fontSize: 10, fontFamily: 'ShareTechMono')),
                  ),
                ),
              ],
            ]),
          ),
        ),
        const SizedBox(height: 10),
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(color: primary.withOpacity(0.04), borderRadius: BorderRadius.circular(12), border: Border.all(color: primary.withOpacity(0.12))),
          child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Icon(Icons.info_outline_rounded, color: primary, size: 13),
            const SizedBox(width: 8),
            Expanded(child: Text(
              'ZIP akan diupload ke repo GitHub kamu, kemudian diekstrak & di-build oleh GitHub Actions. Ukuran maksimal ±50 MB. Struktur ZiP: bisa root langsung atau satu folder di dalam.',
              style: TextStyle(color: Colors.white.withOpacity(0.45), fontSize: 10, fontFamily: 'ShareTechMono', height: 1.5),
            )),
          ]),
        ),
      ]),
    );
  }

  Widget _buildInfoCards() {
    return Column(children: [
      Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(color: const Color(0xFF1A1200), borderRadius: BorderRadius.circular(14), border: Border.all(color: Colors.amber.withOpacity(0.3))),
        child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Icon(Icons.schedule_rounded, color: Colors.amber, size: 15),
          const SizedBox(width: 10),
          Expanded(child: Text.rich(TextSpan(children: [
            const TextSpan(text: 'Estimasi build: 5–15 menit (Ubuntu runner)\n', style: TextStyle(color: Colors.amber, fontSize: 11, fontFamily: 'ShareTechMono')),
            TextSpan(text: 'Repo public → gratis unlimited. Repo private → kuota 2.000 mnt/bln.', style: TextStyle(color: Colors.amber.withOpacity(0.6), fontSize: 10, fontFamily: 'ShareTechMono')),
          ]))),
        ]),
      ),
      const SizedBox(height: 8),
      Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(color: const Color(0xFF001510), borderRadius: BorderRadius.circular(14), border: Border.all(color: Colors.amber.withOpacity(0.25))),
        child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Icon(Icons.notifications_active_rounded, color: Colors.amber, size: 15),
          const SizedBox(width: 10),
          Expanded(child: Text.rich(TextSpan(children: [
            const TextSpan(text: 'Mode background aktif.\n', style: TextStyle(color: Colors.amber, fontSize: 11, fontFamily: 'ShareTechMono')),
            TextSpan(text: 'Build tetap lanjut walau app ditutup. Saat dibuka lagi, status dan log terakhir akan disambungkan otomatis.', style: TextStyle(color: Colors.amber.withOpacity(0.6), fontSize: 10, fontFamily: 'ShareTechMono')),
          ]))),
        ]),
      ),
    ]);
  }

  Widget _buildProgressCard() {
    final c = _isError ? Colors.redAccent : _isDone ? const Color(0xFF00C853) : primary;
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(color: card, borderRadius: BorderRadius.circular(20), border: Border.all(color: c.withOpacity(0.3)), boxShadow: [BoxShadow(color: c.withOpacity(0.07), blurRadius: 20)]),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          AnimatedBuilder(
            animation: _pulseAnim,
            builder: (_, __) => Container(
              width: 38, height: 38,
              decoration: BoxDecoration(shape: BoxShape.circle, color: c.withOpacity(0.15 * (_isBuilding ? _pulseAnim.value : 1.0)), border: Border.all(color: c.withOpacity(0.4))),
              child: Icon(_isError ? Icons.error_outline_rounded : _isDone ? Icons.check_circle_rounded : Icons.pending_rounded, color: c, size: 20),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(_isError ? 'Build Gagal' : _isDone ? 'Build Selesai ✅' : 'Sedang Build...',
              style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 13, fontFamily: 'Orbitron')),
            const SizedBox(height: 2),
            Text(_status, style: TextStyle(color: Colors.white.withOpacity(0.5), fontSize: 10, fontFamily: 'ShareTechMono'), maxLines: 2),
          ])),
        ]),
        if (_isBuilding || _isDone) ...[
          const SizedBox(height: 16),
          ClipRRect(borderRadius: BorderRadius.circular(6), child: LinearProgressIndicator(value: _progress / 100, backgroundColor: Colors.white10, valueColor: AlwaysStoppedAnimation<Color>(c), minHeight: 6)),
          const SizedBox(height: 6),
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            Text(_currentStep >= 0 ? _steps[_currentStep.clamp(0, _steps.length-1)] : '', style: TextStyle(color: Colors.white.withOpacity(0.3), fontSize: 9, fontFamily: 'ShareTechMono')),
            Text('$_progress%', style: TextStyle(color: c, fontSize: 11, fontFamily: 'ShareTechMono', fontWeight: FontWeight.bold)),
          ]),
          if (_runId.isNotEmpty) ...[
            const SizedBox(height: 10),
            Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6), decoration: BoxDecoration(color: card2, borderRadius: BorderRadius.circular(8)),
              child: Row(children: [
                Icon(Icons.tag_rounded, color: Colors.white.withOpacity(0.3), size: 12),
                const SizedBox(width: 5),
                Text('Run ID: $_runId', style: const TextStyle(color: Colors.white38, fontSize: 10, fontFamily: 'ShareTechMono')),
              ])),
          ],
        ],
      ]),
    );
  }

  Widget _buildDownloadCard() {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(color: card, borderRadius: BorderRadius.circular(20), border: Border.all(color: const Color(0xFF00C853).withOpacity(0.4)), boxShadow: [BoxShadow(color: const Color(0xFF00C853).withOpacity(0.08), blurRadius: 20)]),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Container(width: 38, height: 38, decoration: BoxDecoration(shape: BoxShape.circle, color: const Color(0xFF00C853).withOpacity(0.15), border: Border.all(color: const Color(0xFF00C853).withOpacity(0.4))),
            child: const Icon(Icons.download_rounded, color: Color(0xFF00C853), size: 20)),
          const SizedBox(width: 12),
          const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('APK Siap!', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 14, fontFamily: 'Orbitron')),
            Text('Ambil APK dari GitHub Actions', style: TextStyle(color: Colors.white38, fontSize: 10, fontFamily: 'ShareTechMono')),
          ]),
        ]),
        const SizedBox(height: 14),
        GestureDetector(
          onTap: () => Clipboard.setData(ClipboardData(text: _downloadLink)).then((_) => _showSnack('Link disalin!')),
          child: Container(padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: card2, borderRadius: BorderRadius.circular(12), border: Border.all(color: Colors.white10)),
            child: Row(children: [
              const Icon(Icons.link_rounded, color: Colors.white38, size: 14),
              const SizedBox(width: 8),
              Expanded(child: Text(_downloadLink, style: const TextStyle(color: Colors.white60, fontSize: 10, fontFamily: 'ShareTechMono'), maxLines: 2, overflow: TextOverflow.ellipsis)),
              const Icon(Icons.copy_rounded, color: Colors.white38, size: 14),
            ])),
        ),
        const SizedBox(height: 12),
        SizedBox(
          width: double.infinity,
          child: ElevatedButton.icon(
            icon: const Icon(Icons.open_in_browser_rounded, size: 18),
            label: const Text('BUKA DI GITHUB ACTIONS', style: TextStyle(fontFamily: 'Orbitron', fontWeight: FontWeight.bold, fontSize: 11, letterSpacing: 0.5)),
            style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF00C853), foregroundColor: Colors.black, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)), padding: const EdgeInsets.symmetric(vertical: 14)),
            onPressed: () => Clipboard.setData(ClipboardData(text: _downloadLink)).then((_) => _showSnack('Link disalin! Buka di browser.')),
          ),
        ),
      ]),
    );
  }

  Widget _buildLogsCard() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(color: card, borderRadius: BorderRadius.circular(20), border: Border.all(color: Colors.white10)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          const Icon(Icons.terminal_rounded, color: Colors.white38, size: 14),
          const SizedBox(width: 8),
          const Text('BUILD LOG', style: TextStyle(color: Colors.white38, fontSize: 10, fontFamily: 'Orbitron', letterSpacing: 1.5)),
          const Spacer(),
          GestureDetector(
            onTap: () => Clipboard.setData(ClipboardData(text: _logs.join('\n'))).then((_) => _showSnack('Log disalin!')),
            child: const Icon(Icons.copy_rounded, color: Colors.white24, size: 14),
          ),
        ]),
        const SizedBox(height: 10),
        Container(
          height: 150, padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(color: card2, borderRadius: BorderRadius.circular(12)),
          child: ListView.builder(
            reverse: true, itemCount: _logs.length,
            itemBuilder: (_, i) {
              final log = _logs[_logs.length - 1 - i];
              return Padding(padding: const EdgeInsets.only(bottom: 2), child: Text(log, style: TextStyle(
                color: log.contains('❌') ? Colors.redAccent : log.contains('✅') ? const Color(0xFF00C853) : Colors.white38,
                fontSize: 10, fontFamily: 'ShareTechMono')));
            },
          ),
        ),
      ]),
    );
  }

  Widget _buildActionButton() {
    return Row(children: [
      if (_isBuilding || _isDone || _isError) ...[
        GestureDetector(
          onTap: _isBuilding ? null : _reset,
          child: Container(width: 52, height: 56, decoration: BoxDecoration(color: Colors.white.withOpacity(0.07), borderRadius: BorderRadius.circular(16), border: Border.all(color: Colors.white12)),
            child: const Center(child: Icon(Icons.refresh_rounded, color: Colors.white54, size: 22))),
        ),
        const SizedBox(width: 12),
      ],
      Expanded(
        child: GestureDetector(
          onTap: _isBuilding ? null : _startBuild,
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 200),
            height: 56,
            decoration: BoxDecoration(
              gradient: _isBuilding
                  ? LinearGradient(colors: [Colors.grey.shade700, Colors.grey.shade800])
                  : LinearGradient(colors: [primary, accent], begin: Alignment.centerLeft, end: Alignment.centerRight),
              borderRadius: BorderRadius.circular(18),
              boxShadow: _isBuilding ? [] : [BoxShadow(color: primary.withOpacity(0.4), blurRadius: 16, spreadRadius: 1)],
            ),
            child: Center(
              child: _isBuilding
                  ? Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                      AnimatedBuilder(animation: _pulseAnim, builder: (_, __) => Opacity(opacity: _pulseAnim.value, child: const Icon(Icons.bolt_rounded, color: Colors.black87, size: 22))),
                      const SizedBox(width: 10),
                      const Text('BUILDING VIA GITHUB...', style: TextStyle(color: Colors.black87, fontFamily: 'Orbitron', fontWeight: FontWeight.bold, fontSize: 12, letterSpacing: 1)),
                    ])
                  : const Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                      Icon(Icons.rocket_launch_rounded, color: Colors.black87, size: 22),
                      SizedBox(width: 10),
                      Text('Mulai Build via GitHub Actions', style: TextStyle(color: Colors.black87, fontFamily: 'Orbitron', fontWeight: FontWeight.bold, fontSize: 12, letterSpacing: 0.5)),
                    ]),
            ),
          ),
        ),
      ),
    ]);
  }
}
