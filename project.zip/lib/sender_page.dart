import 'dart:convert';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'services/api_config_service.dart';

class SenderPage extends StatefulWidget {
  final String sessionKey;
  final String role;

  const SenderPage({super.key, required this.sessionKey, required this.role});

  @override
  State<SenderPage> createState() => _SenderPageState();
}

class _SenderPageState extends State<SenderPage> with TickerProviderStateMixin {
  // Constants
  // baseUrl now fetched dynamically via ApiConfig.baseUrl
  static const Color primaryColor = Color(0xFF9E9E9E); // Changed from purple to green
  static const Color accentColor = Color(0xFF6EE7B7); // Lighter green for accent
  static const Color secondaryColor = Color(0xFF1E1E1E);

  // State variables
  Map<String, dynamic> connections = {"private": [], "global": []};
  bool isLoading = false;
  String _currentFilter = "all"; // Filter: "all", "private", "global"
  late AnimationController _fabController;
  late Animation<double> _fabAnimation;

  @override
  void initState() {
    super.initState();
    _initializeAnimations();
    _fetchSenders();
  }

  void _initializeAnimations() {
    _fabController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 300),
    );
    _fabAnimation = Tween<double>(begin: 1.0, end: 1.2).animate(
      CurvedAnimation(parent: _fabController, curve: Curves.easeInOut),
    );
  }

  Future<void> _fetchSenders() async {
    if (isLoading) return;

    setState(() => isLoading = true);

    try {
      final res = await ApiService.getMySender(widget.sessionKey);

      if (res['valid'] == true) {
        // DEBUG: Cetak respons dari server untuk membantu debugging
        print("RESPONSE FROM SERVER: ${res["connections"]}");

        setState(() {
          connections = res["connections"] ?? {"private": [], "global": []};
        });
      } else {
        _showErrorSnackBar(res['message'] ?? "Failed to fetch senders");
      }
    } catch (e) {
      debugPrint("Error fetching senders: $e");
      _showErrorSnackBar("Failed to fetch senders. Please try again.");
    }

    setState(() => isLoading = false);
  }

  void _showErrorSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: Colors.red.withOpacity(0.8),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10),
        ),
      ),
    );
  }

  void _showSuccessSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: primaryColor.withOpacity(0.8),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10),
        ),
      ),
    );
  }

  void _showAddSenderDialog() {
    final isOwner = ['owner', 'high owner', 'dev'].contains(widget.role.toLowerCase());

    if (isOwner) {
      // Owner: pilih tipe dulu
      showDialog(
        context: context,
        builder: (_) => Dialog(
          backgroundColor: secondaryColor,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
            side: BorderSide(color: primaryColor.withOpacity(0.3)),
          ),
          child: Padding(
            padding: const EdgeInsets.all(20.0),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: primaryColor.withOpacity(0.2),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: const Icon(Icons.add, color: Color(0xFF9E9E9E)),
                    ),
                    const SizedBox(width: 12),
                    const Text(
                      "Pilih Tipe Sender",
                      style: TextStyle(
                        color: Color(0xFF9E9E9E),
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        fontFamily: 'Orbitron',
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 20),
                // Private Card
                GestureDetector(
                  onTap: () {
                    Navigator.pop(context);
                    _showInputSenderDialog(isGlobal: false);
                  },
                  child: Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(16),
                    margin: const EdgeInsets.only(bottom: 10),
                    decoration: BoxDecoration(
                      color: primaryColor.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: primaryColor.withOpacity(0.4)),
                    ),
                    child: Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color: primaryColor.withOpacity(0.2),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: const Icon(Icons.person, color: Color(0xFF9E9E9E), size: 20),
                        ),
                        const SizedBox(width: 12),
                        const Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text("Private Sender",
                                style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 14)),
                            SizedBox(height: 2),
                            Text("Sender milik kamu sendiri",
                                style: TextStyle(color: Colors.white54, fontSize: 11)),
                          ],
                        ),
                        const Spacer(),
                        const Icon(Icons.chevron_right, color: Colors.white38),
                      ],
                    ),
                  ),
                ),
                // Global Card
                GestureDetector(
                  onTap: () {
                    Navigator.pop(context);
                    _showInputSenderDialog(isGlobal: true);
                  },
                  child: Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: Colors.amber.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: Colors.amber.withOpacity(0.4)),
                    ),
                    child: Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color: Colors.amber.withOpacity(0.2),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: const Icon(Icons.public, color: Colors.amber, size: 20),
                        ),
                        const SizedBox(width: 12),
                        const Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text("Global Sender",
                                style: TextStyle(color: Colors.amber, fontWeight: FontWeight.bold, fontSize: 14)),
                            SizedBox(height: 2),
                            Text("Sender bisa dipakai semua user",
                                style: TextStyle(color: Colors.white54, fontSize: 11)),
                          ],
                        ),
                        const Spacer(),
                        const Icon(Icons.chevron_right, color: Colors.white38),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: const Text("Batal", style: TextStyle(color: Colors.redAccent)),
                ),
              ],
            ),
          ),
        ),
      );
    } else {
      // Non-owner: langsung add private
      _showInputSenderDialog(isGlobal: false);
    }
  }

  void _showInputSenderDialog({required bool isGlobal}) {
    final controller = TextEditingController();

    showDialog(
      context: context,
      builder: (_) => Dialog(
        backgroundColor: secondaryColor,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
          side: BorderSide(color: (isGlobal ? Colors.amber : primaryColor).withOpacity(0.3)),
        ),
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: (isGlobal ? Colors.amber : primaryColor).withOpacity(0.2),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Icon(isGlobal ? Icons.public : Icons.person,
                        color: isGlobal ? Colors.amber : const Color(0xFF9E9E9E)),
                  ),
                  const SizedBox(width: 12),
                  Text(
                    isGlobal ? "Add Global Sender" : "Add Sender",
                    style: TextStyle(
                      color: isGlobal ? Colors.amber : const Color(0xFF9E9E9E),
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'Orbitron',
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 20),
              TextField(
                controller: controller,
                keyboardType: TextInputType.phone,
                style: TextStyle(color: isGlobal ? Colors.amber : const Color(0xFF9E9E9E)),
                decoration: InputDecoration(
                  hintText: "Enter phone number",
                  hintStyle: TextStyle(color: (isGlobal ? Colors.amber : const Color(0xFF9E9E9E)).withOpacity(0.5)),
                  filled: true,
                  fillColor: Colors.black.withOpacity(0.3),
                  enabledBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: (isGlobal ? Colors.amber : const Color(0xFF9E9E9E)).withOpacity(0.3)),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: isGlobal ? Colors.amber : const Color(0xFF9E9E9E)),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  prefixIcon: Icon(Icons.phone, color: isGlobal ? Colors.amber : const Color(0xFF9E9E9E)),
                ),
              ),
              const SizedBox(height: 20),
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  TextButton(
                    style: TextButton.styleFrom(foregroundColor: Colors.redAccent),
                    child: const Text("Cancel"),
                    onPressed: () => Navigator.pop(context),
                  ),
                  const SizedBox(width: 10),
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: isGlobal ? Colors.amber : const Color(0xFF9E9E9E),
                      foregroundColor: Colors.black,
                      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                    ),
                    child: const Text("Submit"),
                    onPressed: () async {
                      Navigator.pop(context);
                      final number = controller.text.trim();
                      if (number.isEmpty) {
                        _showErrorSnackBar("Phone number cannot be empty");
                        return;
                      }

                      try {
                        final res = isGlobal
                            ? await ApiService.getGlobalPairing(widget.sessionKey, number)
                            : await ApiService.getPairing(widget.sessionKey, number);

                        if (res['valid'] == true) {
                          _showPairingCodeDialog(number, res['pairingCode']);
                          _fetchSenders();
                        } else {
                          _showErrorSnackBar("Failed: ${res['message'] ?? 'Unknown error'}");
                        }
                      } catch (e) {
                        debugPrint("Error adding sender: $e");
                        _showErrorSnackBar("An error occurred. Please try again.");
                      }
                    },
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showPairingCodeDialog(String number, String code) {
    showDialog(
      context: context,
      builder: (_) => Dialog(
        backgroundColor: secondaryColor,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
          side: BorderSide(color: primaryColor.withOpacity(0.3)),
        ),
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: primaryColor.withOpacity(0.2),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: const Icon(Icons.phonelink_lock, color: Color(0xFF9E9E9E)),
                  ),
                  const SizedBox(width: 12),
                  const Text(
                    "Pairing Code",
                    style: TextStyle(
                      color: Color(0xFF9E9E9E),
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'Orbitron',
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 20),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: Colors.black.withOpacity(0.3),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: primaryColor.withOpacity(0.2)),
                ),
                child: Column(
                  children: [
                    Text(
                      "Number: $number",
                      style: TextStyle(
                        color: const Color(0xFF9E9E9E).withOpacity(0.7),
                        fontSize: 14,
                      ),
                    ),
                    const SizedBox(height: 15),
                    Row(
                      children: [
                        Expanded(
                          child: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 10),
                            decoration: BoxDecoration(
                              color: primaryColor.withOpacity(0.1),
                              borderRadius: BorderRadius.circular(8),
                              border: Border.all(color: primaryColor.withOpacity(0.3)),
                            ),
                            child: Text(
                              code,
                              style: const TextStyle(
                                color: Color(0xFF6EE7B7),
                                fontSize: 24,
                                fontWeight: FontWeight.bold,
                                letterSpacing: 3,
                                fontFamily: 'Orbitron',
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 15),
                    const Text(
                      "Enter this code in your WhatsApp app to complete pairing.",
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: Colors.white54,
                        fontSize: 12,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 20),
              Row(
                children: [
                  Expanded(
                    child: ElevatedButton.icon(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: primaryColor.withOpacity(0.2),
                        foregroundColor: const Color(0xFF9E9E9E),
                        padding: const EdgeInsets.symmetric(vertical: 12),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(8),
                          side: BorderSide(color: primaryColor.withOpacity(0.5)),
                        ),
                      ),
                      icon: const Icon(Icons.copy, size: 18),
                      label: const Text("Copy Code"),
                      onPressed: () {
                        Clipboard.setData(ClipboardData(text: code));
                        _showSuccessSnackBar("Pairing code copied to clipboard!");
                      },
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFF9E9E9E),
                        foregroundColor: Colors.black,
                        padding: const EdgeInsets.symmetric(vertical: 12),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(8),
                        ),
                      ),
                      onPressed: () => Navigator.pop(context),
                      child: const Text("Close"),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  // Mengambil daftar sender berdasarkan filter yang dipilih
  List<dynamic> _getFilteredSenders() {
    switch (_currentFilter) {
      case "private":
        return connections["private"] ?? [];
      case "global":
        return connections["global"] ?? [];
      default:
      // "all" - gabungkan private dan global
        return [
          ...connections["private"] ?? [],
          ...connections["global"] ?? []
        ];
    }
  }

  // Menghitung total sender berdasarkan filter
  int _getSenderCount() {
    switch (_currentFilter) {
      case "private":
        return connections["private"]?.length ?? 0;
      case "global":
        return connections["global"]?.length ?? 0;
      default:
      // "all" - gabungkan private dan global
        return (connections["private"]?.length ?? 0) + (connections["global"]?.length ?? 0);
    }
  }

  // PERBAIKAN: Fungsi baru untuk menghitung TOTAL sender yang tersedia
  int _getTotalSenderCount() {
    return (connections["private"]?.length ?? 0) + (connections["global"]?.length ?? 0);
  }

  @override
  Widget build(BuildContext context) {
    // PERBAIKAN: Gunakan total sender untuk menentukan apakah harus menampilkan empty state
    final totalSenders = _getTotalSenderCount();

    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        elevation: 0,
        automaticallyImplyLeading: false,
        title: Text(
          "My Senders (${_getSenderCount()})", // Tetap tampilkan jumlah yang difilter
          style: const TextStyle(
            color: Color(0xFF9E9E9E),
            fontFamily: 'Orbitron',
          ),
        ),
        actions: [
          Container(
            margin: const EdgeInsets.only(right: 8),
            child: IconButton(
              icon: const Icon(Icons.refresh, color: Color(0xFF6EE7B7)),
              onPressed: _fetchSenders,
            ),
          ),
        ],
      ),
      floatingActionButton: AnimatedBuilder(
        animation: _fabAnimation,
        builder: (context, child) {
          return Transform.scale(
            scale: _fabAnimation.value,
            child: FloatingActionButton(
              backgroundColor: const Color(0xFF9E9E9E),
              onPressed: () {
                _fabController.forward().then((_) {
                  _fabController.reverse();
                });
                _showAddSenderDialog();
              },
              child: const Icon(Icons.add, color: Colors.black),
            ),
          );
        },
      ),
      body: isLoading
          ? const Center(
        child: CircularProgressIndicator(
          color: Color(0xFF6EE7B7),
        ),
      )
      // PERBAIKAN: Gunakan totalSenders di sini
          : totalSenders == 0
          ? _buildEmptyState()
          : Column(
        children: [
          _buildFilterChips(),
          Expanded(child: _buildSenderList()),
        ],
      ),
    );
  }

  Widget _buildFilterChips() {
    return Container(
      padding: const EdgeInsets.all(16),
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: Row(
          children: [
            _buildFilterChip("All", "all"),
            const SizedBox(width: 8),
            _buildFilterChip("Private", "private"),
            const SizedBox(width: 8),
            _buildFilterChip("Global", "global"),
          ],
        ),
      ),
    );
  }

  Widget _buildFilterChip(String label, String filter) {
    final isSelected = _currentFilter == filter;

    return FilterChip(
      label: Text(
        label,
        style: TextStyle(
          color: isSelected ? Colors.black : const Color(0xFF9E9E9E),
          fontWeight: FontWeight.w500,
        ),
      ),
      selected: isSelected,
      onSelected: (selected) {
        setState(() {
          _currentFilter = filter;
        });
      },
      backgroundColor: Colors.white.withOpacity(0.1),
      selectedColor: const Color(0xFF9E9E9E),
      checkmarkColor: Colors.black,
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20),
        side: BorderSide(
          color: isSelected ? const Color(0xFF9E9E9E) : Colors.white.withOpacity(0.2),
        ),
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.05),
              shape: BoxShape.circle,
            ),
            child: const Icon(
              Icons.phone_disabled,
              color: Colors.white30,
              size: 60,
            ),
          ),
          const SizedBox(height: 20),
          const Text(
            "No senders found",
            style: TextStyle(
              color: Color(0xFF9E9E9E),
              fontSize: 18,
              fontFamily: 'Orbitron',
            ),
          ),
          const SizedBox(height: 10),
          const Text(
            "Add a sender to get started",
            style: TextStyle(
              color: Colors.white54,
              fontSize: 14,
            ),
          ),
          const SizedBox(height: 20),
          ElevatedButton.icon(
            onPressed: _showAddSenderDialog,
            icon: const Icon(Icons.add, color: Colors.black),
            label: const Text("Add Sender"),
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFF9E9E9E),
              foregroundColor: Colors.black,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(8),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSenderList() {
    final filteredSenders = _getFilteredSenders();

    // PERBAIKAN: Tampilkan pesan jika filter yang dipilih tidak memiliki hasil
    if (filteredSenders.isEmpty) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(32.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                Icons.filter_list_off,
                color: const Color(0xFF9E9E9E).withOpacity(0.5),
                size: 50,
              ),
              const SizedBox(height: 16),
              Text(
                "No senders found in '${_currentFilter.toUpperCase()}' filter",
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: const Color(0xFF9E9E9E).withOpacity(0.7),
                  fontSize: 16,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                "Try selecting a different filter or add a new sender.",
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Colors.white.withOpacity(0.5),
                  fontSize: 14,
                ),
              ),
            ],
          ),
        ),
      );
    }

    return RefreshIndicator(
      onRefresh: _fetchSenders,
      color: const Color(0xFF6EE7B7),
      child: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: filteredSenders.length,
        itemBuilder: (context, index) {
          final sender = filteredSenders[index];
          final isGlobal = sender['owner'] == "global";

          return Container(
            margin: const EdgeInsets.only(bottom: 12),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.05),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: isGlobal
                    ? accentColor.withOpacity(0.3)
                    : const Color(0xFF9E9E9E).withOpacity(0.1),
              ),
            ),
            child: ListTile(
              contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              leading: Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: isGlobal
                      ? accentColor.withOpacity(0.2)
                      : const Color(0xFF9E9E9E).withOpacity(0.2),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Icon(
                  Icons.phone,
                  color: isGlobal ? accentColor : const Color(0xFF9E9E9E),
                ),
              ),
              title: Text(
                sender['sessionName'] ?? 'Unknown',
                style: const TextStyle(
                  color: Color(0xFF9E9E9E),
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Orbitron',
                  fontSize: 14,
                ),
              ),
              subtitle: Padding(
                padding: const EdgeInsets.only(top: 4),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "Type: ${sender['type'] ?? 'N/A'}",
                      style: TextStyle(
                        color: const Color(0xFF9E9E9E).withOpacity(0.7),
                        fontSize: 14,
                      ),
                    ),
                    Text(
                      "Owner: ${isGlobal ? 'Global (VIP)' : sender['owner'] ?? 'N/A'}",
                      style: TextStyle(
                        color: const Color(0xFF9E9E9E).withOpacity(0.7),
                        fontSize: 14,
                      ),
                    ),
                  ],
                ),
              ),
              trailing: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  if (isGlobal)
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                      decoration: BoxDecoration(
                        color: accentColor.withOpacity(0.2),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: const Text(
                        "VIP",
                        style: TextStyle(
                          color: Color(0xFF6EE7B7),
                          fontSize: 12,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  const SizedBox(width: 8),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                      color: const Color(0xFF9E9E9E).withOpacity(0.2),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: const Text(
                      "Active",
                      style: TextStyle(
                        color: Color(0xFF9E9E9E),
                        fontSize: 12,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  @override
  void dispose() {
    _fabController.dispose();
    super.dispose();
  }
}

// API Service untuk komunikasi dengan backend
class ApiService {
  // _baseUrl now fetched dynamically via ApiConfig.baseUrl

  static Future<Map<String, dynamic>> getMySender(String sessionKey) async {
    try {
      final baseUrl = await ApiConfig.baseUrl;
      final response = await http.get(
        Uri.parse("$baseUrl/api/whatsapp/mySender?key=$sessionKey"),
      );

      if (response.statusCode == 200) {
        return jsonDecode(response.body);
      } else {
        throw Exception('Failed to fetch senders: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Error fetching senders: $e');
    }
  }

  static Future<Map<String, dynamic>> getPairing(String sessionKey, String number) async {
    try {
      final baseUrl = await ApiConfig.baseUrl;
      final response = await http.get(
        Uri.parse("$baseUrl/api/whatsapp/getPairing?key=$sessionKey&number=$number"),
      );

      if (response.statusCode == 200) {
        return jsonDecode(response.body);
      } else {
        throw Exception('Failed to get pairing code: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Error getting pairing code: $e');
    }
  }

  static Future<Map<String, dynamic>> getGlobalPairing(String sessionKey, String number) async {
    try {
      final baseUrl = await ApiConfig.baseUrl;
      final response = await http.get(
        Uri.parse("$baseUrl/api/whatsapp/addGlobalSender?key=$sessionKey&number=$number"),
      );

      if (response.statusCode == 200) {
        return jsonDecode(response.body);
      } else {
        throw Exception('Failed to get global pairing code: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Error getting global pairing code: $e');
    }
  }
}