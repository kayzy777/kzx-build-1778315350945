import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';
import 'services/api_config_service.dart';

String? formatPhoneNumber(String raw) {
  final digits = raw.replaceAll(RegExp(r'\D'), '');
  if (digits.startsWith('0')) return '62${digits.substring(1)}';
  if (digits.startsWith('62')) return digits;
  if (digits.length >= 8) return '62$digits';
  return null;
}

class AttackPage extends StatefulWidget {
  final String username;
  final String password;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final String role;
  final String expiredDate;

  const AttackPage({
    super.key,
    required this.username,
    required this.password,
    required this.sessionKey,
    required this.listBug,
    required this.role,
    required this.expiredDate,
  });

  @override
  State<AttackPage> createState() => _AttackPageState();
}

class _AttackPageState extends State<AttackPage> {
  final targetController = TextEditingController();
  String? _baseUrl;
  bool _isLoadingConfig = true;
  String selectedBugId = '';
  bool _isSending = false;
  String _selectedSenderType = 'pribadi';
  int _globalSenderCount = 0;

  static const Color teal = Color(0xFF00E5CC);
  static const Color tealDark = Color(0xFF00BFA5);
  static const Color cardBg = Color(0xFF0D1F2D);
  static const Color cardBg2 = Color(0xFF111E2B);

  @override
  void initState() {
    super.initState();
    _loadServerUrl();
    _fetchSenderCount();
    if (widget.listBug.isNotEmpty) selectedBugId = widget.listBug[0]['bug_id'] ?? '';
  }

  @override
  void dispose() {
    targetController.dispose();
    super.dispose();
  }

  Future<void> _loadServerUrl() async {
    try {
      final url = await ApiConfig.baseUrl;
      if (mounted) setState(() { _baseUrl = url; _isLoadingConfig = false; });
    } catch (_) {
      if (mounted) setState(() => _isLoadingConfig = false);
    }
  }

  Future<void> _fetchSenderCount() async {
    try {
      final baseUrl = await ApiConfig.baseUrl;
      final res = await http.get(Uri.parse('$baseUrl/api/whatsapp/senderCount?key=${widget.sessionKey}')).timeout(const Duration(seconds: 10));
      final data = jsonDecode(res.body);
      if (mounted) setState(() => _globalSenderCount = data['globalCount'] ?? 0);
    } catch (_) {}
  }

  Future<bool> _checkPrivateSender() async {
    try {
      final baseUrl = await ApiConfig.baseUrl;
      final res = await http.get(Uri.parse('$baseUrl/api/whatsapp/mySender?key=${widget.sessionKey}')).timeout(const Duration(seconds: 10));
      final data = jsonDecode(res.body);
      final List private = data['connections']?['private'] ?? [];
      return private.isNotEmpty;
    } catch (_) { return false; }
  }

  Future<void> _sendBug() async {
    if (_isSending || _baseUrl == null) return;
    if (_selectedSenderType == 'pribadi') {
      final has = await _checkPrivateSender();
      if (!has) { _showNoSenderDialog(); return; }
    }
    setState(() => _isSending = true);
    final target = formatPhoneNumber(targetController.text.trim());
    if (target == null) {
      _showAlert('❌ Invalid', 'Nomor tidak valid. Gunakan format 62xxx.');
      setState(() => _isSending = false);
      return;
    }
    try {
      final res = await http.get(Uri.parse('$_baseUrl/api/whatsapp/sendBug?key=${widget.sessionKey}&target=$target&bug=$selectedBugId&senderType=$_selectedSenderType')).timeout(const Duration(seconds: 15));
      final data = jsonDecode(res.body);
      if (data['cooldown'] == true) _showAlert('⏳ Cooldown', 'Tunggu sebentar sebelum kirim lagi.');
      else if (data['senderOn'] == false) _showAlert('⚠️ Gagal', 'Sender kosong, hubungi seller.');
      else if (data['valid'] == false) _showAlert('❌ Key Invalid', 'Session key tidak valid.');
      else if (data['sended'] == false) _showAlert('⚠️ Gagal', 'Server sedang maintenance.');
      else _showSuccessPopup(target);
    } catch (e) {
      _showAlert('❌ Error', e.toString());
    } finally {
      if (mounted) setState(() => _isSending = false);
    }
  }

  void _showSuccessPopup(String target) {
    showDialog(context: context, barrierDismissible: false, builder: (_) => SuccessVideoDialog(target: target, onDismiss: () => Navigator.of(context).pop()));
  }

  void _showAlert(String title, String msg) {
    showDialog(context: context, builder: (_) => AlertDialog(
      backgroundColor: cardBg,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      title: Text(title, style: const TextStyle(color: Colors.white, fontFamily: 'Orbitron')),
      content: Text(msg, style: const TextStyle(color: Colors.white70, fontFamily: 'ShareTechMono')),
      actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('OK', style: TextStyle(color: teal)))],
    ));
  }

  void _showNoSenderDialog() {
    showDialog(context: context, builder: (_) => AlertDialog(
      backgroundColor: cardBg,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      title: const Text('Sender Pribadi Kosong', style: TextStyle(color: Colors.white, fontFamily: 'Orbitron', fontSize: 16)),
      content: const Text('Kamu belum punya sender pribadi.\nTambah sender dulu atau pilih Global.', style: TextStyle(color: Colors.white70, fontFamily: 'ShareTechMono')),
      actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('OK', style: TextStyle(color: teal)))],
    ));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF060E17),
      body: _isLoadingConfig
          ? const Center(child: CircularProgressIndicator(color: teal))
          : Container(
              decoration: const BoxDecoration(
                gradient: LinearGradient(colors: [Color(0xFF060E17), Color(0xFF0A1929)], begin: Alignment.topCenter, end: Alignment.bottomCenter),
              ),
              child: SafeArea(
                child: SingleChildScrollView(
                  physics: const BouncingScrollPhysics(),
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    children: [
                      _buildAppHeader(),
                      const SizedBox(height: 16),
                      _buildProfileCard(),
                      const SizedBox(height: 16),
                      _buildNomorTarget(),
                      const SizedBox(height: 12),
                      _buildPilihBug(),
                      const SizedBox(height: 12),
                      _buildPilihSender(),
                      const SizedBox(height: 20),
                      _buildSendButton(),
                      const SizedBox(height: 16),
                      _buildFooter(),
                    ],
                  ),
                ),
              ),
            ),
    );
  }

  Widget _buildAppHeader() {
    return Row(
      children: [
        GestureDetector(
          onTap: () => Navigator.pop(context),
          child: Container(
            width: 40, height: 40,
            decoration: BoxDecoration(color: teal.withOpacity(0.15), borderRadius: BorderRadius.circular(12), border: Border.all(color: teal.withOpacity(0.4))),
            child: const Icon(Icons.shield_rounded, color: teal, size: 20),
          ),
        ),
        const SizedBox(width: 12),
        const Text('TEXAS BUG', style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w900, fontFamily: 'Orbitron', letterSpacing: 2)),
        const Spacer(),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
          decoration: BoxDecoration(color: teal.withOpacity(0.1), borderRadius: BorderRadius.circular(20), border: Border.all(color: teal.withOpacity(0.4))),
          child: const Text('v3.0', style: TextStyle(color: teal, fontSize: 12, fontFamily: 'ShareTechMono', fontWeight: FontWeight.bold)),
        ),
      ],
    );
  }

  Widget _buildProfileCard() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(color: cardBg, borderRadius: BorderRadius.circular(24), border: Border.all(color: teal.withOpacity(0.2)), boxShadow: [BoxShadow(color: teal.withOpacity(0.08), blurRadius: 20)]),
      child: Column(
        children: [
          Row(
            children: [
              Container(
                width: 64, height: 64,
                decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: teal.withOpacity(0.5), width: 2), color: cardBg2),
                child: ClipOval(child: Image.asset('assets/images/aw.png', fit: BoxFit.cover, errorBuilder: (_, __, ___) => const Icon(Icons.shield_rounded, color: teal, size: 30))),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(widget.username, style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 4),
                    Text(widget.role.toUpperCase(), style: const TextStyle(color: teal, fontSize: 12, fontFamily: 'Orbitron', fontWeight: FontWeight.bold, letterSpacing: 1)),
                  ],
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                decoration: BoxDecoration(color: teal.withOpacity(0.1), borderRadius: BorderRadius.circular(20), border: Border.all(color: teal.withOpacity(0.4))),
                child: Row(mainAxisSize: MainAxisSize.min, children: [
                  const Icon(Icons.timer_outlined, color: teal, size: 14),
                  const SizedBox(width: 6),
                  Text(widget.expiredDate, style: const TextStyle(color: teal, fontSize: 11, fontFamily: 'ShareTechMono', fontWeight: FontWeight.bold)),
                ]),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(color: cardBg2, borderRadius: BorderRadius.circular(18)),
            child: Row(
              children: [
                _statItem(Icons.bug_report_rounded, '${widget.listBug.length}', 'Total Bugs', const Color(0xFF00B8D4)),
                Container(width: 1, height: 60, color: Colors.white12),
                _statItem(Icons.bolt_rounded, 'GACOR', 'Success Rate', const Color(0xFF00C853)),
                Container(width: 1, height: 60, color: Colors.white12),
                _statItem(Icons.verified_rounded, 'ACTIVE', 'Status', const Color(0xFF00C853)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _statItem(IconData icon, String value, String label, Color color) {
    return Expanded(
      child: Column(
        children: [
          Container(width: 44, height: 44, decoration: BoxDecoration(shape: BoxShape.circle, color: color.withOpacity(0.15), border: Border.all(color: color.withOpacity(0.4), width: 1.5)), child: Icon(icon, color: color, size: 20)),
          const SizedBox(height: 8),
          Text(value, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 15, fontFamily: 'Orbitron')),
          const SizedBox(height: 2),
          Text(label, style: TextStyle(color: Colors.white.withOpacity(0.45), fontSize: 10, fontFamily: 'ShareTechMono'), textAlign: TextAlign.center),
        ],
      ),
    );
  }

  Widget _buildNomorTarget() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(color: cardBg, borderRadius: BorderRadius.circular(20), border: Border.all(color: teal.withOpacity(0.2))),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(children: [
            Container(width: 36, height: 36, decoration: BoxDecoration(shape: BoxShape.circle, color: teal.withOpacity(0.15), border: Border.all(color: teal.withOpacity(0.4))), child: const Icon(Icons.smartphone_rounded, color: teal, size: 18)),
            const SizedBox(width: 10),
            const Text('NOMOR TARGET', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontFamily: 'Orbitron', fontSize: 14, letterSpacing: 1)),
          ]),
          const SizedBox(height: 12),
          TextField(
            controller: targetController,
            style: const TextStyle(color: Colors.white, fontSize: 15, fontFamily: 'ShareTechMono'),
            cursorColor: teal,
            keyboardType: TextInputType.phone,
            decoration: InputDecoration(
              hintText: '62xxxxxxxxxx',
              hintStyle: TextStyle(color: Colors.white.withOpacity(0.3), fontFamily: 'ShareTechMono'),
              filled: true, fillColor: cardBg2,
              prefixIcon: const Icon(Icons.language_rounded, color: Colors.white38, size: 20),
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
              enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
              focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: const BorderSide(color: teal, width: 1.5)),
              contentPadding: const EdgeInsets.symmetric(vertical: 14, horizontal: 14),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPilihBug() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(color: cardBg, borderRadius: BorderRadius.circular(20), border: Border.all(color: teal.withOpacity(0.2))),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(children: [
            Container(width: 36, height: 36, decoration: BoxDecoration(shape: BoxShape.circle, color: Colors.red.withOpacity(0.15), border: Border.all(color: Colors.red.withOpacity(0.4))), child: const Icon(Icons.bug_report_rounded, color: Colors.redAccent, size: 18)),
            const SizedBox(width: 10),
            const Text('PILIH BUG', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontFamily: 'Orbitron', fontSize: 14, letterSpacing: 1)),
          ]),
          const SizedBox(height: 12),
          SizedBox(
            height: 160,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              itemCount: widget.listBug.length,
              itemBuilder: (_, i) {
                final bug = widget.listBug[i];
                final isSelected = selectedBugId == bug['bug_id'];
                return GestureDetector(
                  onTap: () => setState(() => selectedBugId = bug['bug_id']),
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 200),
                    width: 150, margin: const EdgeInsets.only(right: 10), padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: isSelected ? teal.withOpacity(0.15) : cardBg2,
                      borderRadius: BorderRadius.circular(18),
                      border: Border.all(color: isSelected ? teal : Colors.white12, width: isSelected ? 2 : 1),
                      boxShadow: isSelected ? [BoxShadow(color: teal.withOpacity(0.25), blurRadius: 12)] : [],
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Container(width: 38, height: 38, decoration: BoxDecoration(shape: BoxShape.circle, color: (isSelected ? teal : Colors.white).withOpacity(0.1), border: Border.all(color: (isSelected ? teal : Colors.white).withOpacity(0.3))), child: Icon(Icons.shield_rounded, color: isSelected ? teal : Colors.white54, size: 18)),
                            if (isSelected) Container(width: 24, height: 24, decoration: const BoxDecoration(color: Color(0xFF00C853), shape: BoxShape.circle), child: const Icon(Icons.check, color: Colors.white, size: 14)),
                          ],
                        ),
                        const Spacer(),
                        Text((bug['bug_name'] ?? 'Unknown').toString().toUpperCase(), style: TextStyle(color: isSelected ? Colors.white : Colors.white70, fontWeight: FontWeight.w900, fontFamily: 'Orbitron', fontSize: 11), maxLines: 2, overflow: TextOverflow.ellipsis),
                        const SizedBox(height: 6),
                        Container(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3), decoration: BoxDecoration(color: Colors.white.withOpacity(0.08), borderRadius: BorderRadius.circular(6)), child: Text(bug['bug_id']?.toString() ?? '', style: const TextStyle(color: Colors.white54, fontSize: 10, fontFamily: 'ShareTechMono'))),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
          const SizedBox(height: 10),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: List.generate(widget.listBug.length.clamp(1, 8), (i) {
              final isActive = i < widget.listBug.length && selectedBugId == widget.listBug[i]['bug_id'];
              return Container(width: isActive ? 20 : 7, height: 6, margin: const EdgeInsets.symmetric(horizontal: 2), decoration: BoxDecoration(color: isActive ? teal : Colors.white24, borderRadius: BorderRadius.circular(3)));
            }),
          ),
        ],
      ),
    );
  }

  Widget _buildPilihSender() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(color: cardBg, borderRadius: BorderRadius.circular(20), border: Border.all(color: teal.withOpacity(0.2))),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(width: 36, height: 36, decoration: BoxDecoration(shape: BoxShape.circle, color: teal.withOpacity(0.15), border: Border.all(color: teal.withOpacity(0.4))), child: const Icon(Icons.swap_horiz_rounded, color: teal, size: 18)),
              const SizedBox(width: 10),
              const Text('PILIH SENDER', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontFamily: 'Orbitron', fontSize: 14, letterSpacing: 1)),
              const Spacer(),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                decoration: BoxDecoration(color: Colors.green.withOpacity(0.15), borderRadius: BorderRadius.circular(20), border: Border.all(color: Colors.green.withOpacity(0.4))),
                child: Row(mainAxisSize: MainAxisSize.min, children: [
                  Container(width: 6, height: 6, decoration: const BoxDecoration(color: Colors.green, shape: BoxShape.circle)),
                  const SizedBox(width: 5),
                  Text('$_globalSenderCount sender online', style: const TextStyle(color: Colors.green, fontSize: 10, fontWeight: FontWeight.bold, fontFamily: 'ShareTechMono')),
                ]),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              _senderCard('pribadi', Icons.person_rounded, 'Pribadi', '# Kosong'),
              const SizedBox(width: 10),
              _senderCard('global', Icons.language_rounded, 'Global', '$_globalSenderCount sender'),
            ],
          ),
          if (_selectedSenderType == 'global') ...[
            const SizedBox(height: 10),
            Row(children: [
              Icon(Icons.info_outline, color: teal.withOpacity(0.6), size: 12),
              const SizedBox(width: 6),
              Text('Sisa kirim global hari ini: 3 / 3', style: TextStyle(color: Colors.white.withOpacity(0.45), fontSize: 11, fontFamily: 'ShareTechMono')),
            ]),
          ],
        ],
      ),
    );
  }

  Widget _senderCard(String type, IconData icon, String label, String sublabel) {
    final isSelected = _selectedSenderType == type;
    return Expanded(
      child: GestureDetector(
        onTap: () => setState(() => _selectedSenderType = type),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 10),
          decoration: BoxDecoration(color: isSelected ? teal.withOpacity(0.2) : cardBg2, borderRadius: BorderRadius.circular(16), border: Border.all(color: isSelected ? teal : Colors.white12, width: isSelected ? 2 : 1)),
          child: Column(children: [
            Icon(icon, color: isSelected ? teal : Colors.white54, size: 26),
            const SizedBox(height: 8),
            Text(label, style: TextStyle(color: isSelected ? Colors.white : Colors.white54, fontWeight: FontWeight.bold, fontFamily: 'Orbitron', fontSize: 12)),
            const SizedBox(height: 2),
            Text(sublabel, style: TextStyle(color: Colors.white.withOpacity(0.4), fontSize: 10, fontFamily: 'ShareTechMono')),
          ]),
        ),
      ),
    );
  }

  Widget _buildSendButton() {
    return Container(
      width: double.infinity, height: 58,
      decoration: BoxDecoration(
        gradient: const LinearGradient(colors: [teal, tealDark], begin: Alignment.centerLeft, end: Alignment.centerRight),
        borderRadius: BorderRadius.circular(30),
        boxShadow: [BoxShadow(color: teal.withOpacity(0.35), blurRadius: 20, spreadRadius: 2)],
      ),
      child: ElevatedButton.icon(
        icon: _isSending ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2)) : const Icon(Icons.send_rounded, color: Colors.white, size: 20),
        label: Text(_isSending ? 'MENGIRIM...' : 'KIRIM BUG', style: const TextStyle(fontSize: 16, fontFamily: 'Orbitron', fontWeight: FontWeight.bold, letterSpacing: 2, color: Colors.white)),
        style: ElevatedButton.styleFrom(backgroundColor: Colors.transparent, foregroundColor: Colors.white, shadowColor: Colors.transparent, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)), padding: const EdgeInsets.symmetric(vertical: 14)),
        onPressed: _isSending ? null : _sendBug,
      ),
    );
  }

  Widget _buildFooter() {
    return Column(children: [
      const Text('TEXAS TEAM', style: TextStyle(color: Colors.white24, fontSize: 11, fontFamily: 'ShareTechMono', letterSpacing: 2)),
      const SizedBox(height: 4),
      Text('© 2026 TEXAS Always For You', style: TextStyle(color: Colors.white.withOpacity(0.15), fontSize: 10, fontFamily: 'ShareTechMono')),
      const SizedBox(height: 16),
    ]);
  }
}

class SuccessVideoDialog extends StatefulWidget {
  final String target;
  final VoidCallback onDismiss;
  const SuccessVideoDialog({super.key, required this.target, required this.onDismiss});
  @override
  State<SuccessVideoDialog> createState() => _SuccessVideoDialogState();
}

class _SuccessVideoDialogState extends State<SuccessVideoDialog> with TickerProviderStateMixin {
  late VideoPlayerController _vc;
  bool _init = false;
  static const Color teal = Color(0xFF00E5CC);
  static const Color cardBg = Color(0xFF0D1F2D);
  static const Color cardBg2 = Color(0xFF111E2B);

  @override
  void initState() {
    super.initState();
    _vc = VideoPlayerController.asset('assets/videos/r.mp4')
      ..initialize().then((_) { if (mounted) { setState(() => _init = true); _vc.play(); _vc.setLooping(true); } }).catchError((_) {});
  }

  @override
  void dispose() { _vc.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: Colors.transparent,
      child: Container(
        padding: const EdgeInsets.all(24),
        decoration: BoxDecoration(color: cardBg, borderRadius: BorderRadius.circular(28), border: Border.all(color: teal.withOpacity(0.4), width: 1.5), boxShadow: [BoxShadow(color: teal.withOpacity(0.2), blurRadius: 30)]),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          if (_init)
            ClipRRect(borderRadius: BorderRadius.circular(16), child: SizedBox(height: 180, width: double.infinity, child: FittedBox(fit: BoxFit.cover, child: SizedBox(width: _vc.value.size.width, height: _vc.value.size.height, child: VideoPlayer(_vc)))))
          else
            Container(height: 120, width: double.infinity, decoration: BoxDecoration(color: cardBg2, borderRadius: BorderRadius.circular(16)), child: const Icon(Icons.check_circle_rounded, color: teal, size: 60)),
          const SizedBox(height: 20),
          const Text('BUG TERKIRIM!', style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold, fontFamily: 'Orbitron', letterSpacing: 2)),
          const SizedBox(height: 8),
          Text('Target: ${widget.target}', style: TextStyle(color: Colors.white.withOpacity(0.6), fontFamily: 'ShareTechMono', fontSize: 13)),
          const SizedBox(height: 20),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: widget.onDismiss,
              style: ElevatedButton.styleFrom(backgroundColor: teal, foregroundColor: Colors.black, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)), padding: const EdgeInsets.symmetric(vertical: 14)),
              child: const Text('TUTUP', style: TextStyle(fontWeight: FontWeight.bold, fontFamily: 'Orbitron', letterSpacing: 1)),
            ),
          ),
        ]),
      ),
    );
  }
}
