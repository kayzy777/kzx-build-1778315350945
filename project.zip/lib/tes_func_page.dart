import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;

import 'services/api_config_service.dart';

class TesFuncPage extends StatefulWidget {
  final String sessionKey;
  final String username;
  final String role;

  const TesFuncPage({
    super.key,
    required this.sessionKey,
    required this.username,
    required this.role,
  });

  @override
  State<TesFuncPage> createState() => _TesFuncPageState();
}

class _TesFuncPageState extends State<TesFuncPage>
    with TickerProviderStateMixin {
  static const Color teal      = Color(0xFF00C896);
  static const Color tealLight = Color(0xFF00E5A8);
  static const Color bgDark    = Color(0xFF061610);
  static const Color bgMid     = Color(0xFF0A1F18);
  static const Color cardBg    = Color(0xFF0D2920);

  final TextEditingController _targetCtrl = TextEditingController();
  final TextEditingController _funcCtrl   = TextEditingController();
  final TextEditingController _delayCtrl  = TextEditingController(text: '1000');
  final TextEditingController _loopsCtrl  = TextEditingController(text: '1');

  late AnimationController _glowCtrl;
  late Animation<double>    _glowAnim;

  bool   _isSending  = false;
  String _statusText = '';

  final List<Map<String, String>> _history = [];

  @override
  void initState() {
    super.initState();
    _glowCtrl = AnimationController(
      duration: const Duration(milliseconds: 1500),
      vsync: this,
    )..repeat(reverse: true);
    _glowAnim = CurvedAnimation(parent: _glowCtrl, curve: Curves.easeInOut);
  }

  @override
  void dispose() {
    _glowCtrl.dispose();
    _targetCtrl.dispose();
    _funcCtrl.dispose();
    _delayCtrl.dispose();
    _loopsCtrl.dispose();
    super.dispose();
  }

  Future<void> _pasteFromClipboard() async {
    final data = await Clipboard.getData(Clipboard.kTextPlain);
    if (data?.text != null && data!.text!.isNotEmpty) {
      setState(() => _funcCtrl.text = data.text!);
      _showSnack('Teks berhasil di-paste dari clipboard!', teal);
    } else {
      _showSnack('Clipboard kosong.', Colors.orange);
    }
  }

  Future<void> _send() async {
    final target  = _targetCtrl.text.trim().replaceAll(RegExp(r'\D'), '');
    final func    = _funcCtrl.text.trim();
    final delayMs = int.tryParse(_delayCtrl.text.trim()) ?? 1000;
    final loops   = int.tryParse(_loopsCtrl.text.trim()) ?? 1;

    if (target.isEmpty) { _showSnack('Masukkan nomor target dulu!', Colors.red); return; }
    if (func.isEmpty)   { _showSnack('Function / Message tidak boleh kosong!', Colors.red); return; }

    setState(() { _isSending = true; _statusText = 'Mengirim...'; });

    try {
      final baseUrl = await ApiConfig.baseUrl;
      final uri = Uri.parse(
        '$baseUrl/api/whatsapp/testFunc'
        '?key=${widget.sessionKey}'
        '&target=$target'
        '&message=${Uri.encodeComponent(func)}'
        '&delay=$delayMs'
        '&loops=$loops',
      );

      final response = await http.get(uri).timeout(const Duration(seconds: 30));
      final data     = jsonDecode(response.body) as Map<String, dynamic>;

      if (!mounted) return;

      if (data['valid'] == true) {
        setState(() {
          _statusText = '✅ Terkirim ke $target';
          _history.insert(0, {
            'target': target,
            'func'  : func.length > 40 ? '${func.substring(0, 40)}...' : func,
            'loops' : loops.toString(),
            'delay' : delayMs.toString(),
            'status': 'success',
            'time'  : _timeNow(),
          });
        });
        _showSnack('Function berhasil dikirim!', teal);
      } else {
        setState(() => _statusText = '❌ ${data['message'] ?? 'Gagal kirim'}');
        _showSnack(data['message'] ?? 'Gagal kirim', Colors.red);
      }
    } catch (e) {
      if (!mounted) return;
      setState(() => _statusText = '❌ Error: $e');
      _showSnack('Error: $e', Colors.red);
    } finally {
      if (mounted) setState(() => _isSending = false);
    }
  }

  String _timeNow() {
    final n = DateTime.now();
    return '${n.hour.toString().padLeft(2,'0')}:${n.minute.toString().padLeft(2,'0')}:${n.second.toString().padLeft(2,'0')}';
  }

  void _showSnack(String msg, Color color) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg, style: const TextStyle(color: Colors.white)),
      backgroundColor: color,
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      duration: const Duration(seconds: 2),
    ));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgDark,
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [bgMid, bgDark],
          ),
        ),
        child: SafeArea(
          child: Column(children: [
            _buildAppBar(),
            Expanded(
              child: SingleChildScrollView(
                physics: const BouncingScrollPhysics(),
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _buildHeaderCard(),
                    const SizedBox(height: 16),
                    _buildTargetField(),
                    const SizedBox(height: 12),
                    _buildFuncField(),
                    const SizedBox(height: 12),
                    _buildDelayLoops(),
                    const SizedBox(height: 16),
                    _buildActionRow(),
                    if (_statusText.isNotEmpty) ...[
                      const SizedBox(height: 12),
                      _buildStatusBadge(),
                    ],
                    const SizedBox(height: 16),
                    _buildInfoBox(),
                    if (_history.isNotEmpty) ...[
                      const SizedBox(height: 16),
                      _buildHistoryList(),
                    ],
                    const SizedBox(height: 24),
                  ],
                ),
              ),
            ),
          ]),
        ),
      ),
    );
  }

  Widget _buildAppBar() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.35),
        border: Border(bottom: BorderSide(color: teal.withOpacity(0.15))),
      ),
      child: Row(children: [
        GestureDetector(
          onTap: () => Navigator.pop(context),
          child: Container(
            width: 36, height: 36,
            decoration: BoxDecoration(
              color: teal.withOpacity(0.1),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: teal.withOpacity(0.3)),
            ),
            child: const Icon(Icons.arrow_back_ios_new, color: teal, size: 16),
          ),
        ),
        const Spacer(),
        ShaderMask(
          shaderCallback: (b) => const LinearGradient(colors: [tealLight, teal]).createShader(b),
          child: const Text('TES FUNC', style: TextStyle(
            color: Colors.white, fontSize: 16, fontWeight: FontWeight.w900,
            fontFamily: 'Orbitron', letterSpacing: 3,
          )),
        ),
        const Spacer(),
        GestureDetector(
          onTap: _showHistoryDialog,
          child: Container(
            width: 36, height: 36,
            decoration: BoxDecoration(
              color: teal.withOpacity(0.1),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: teal.withOpacity(0.3)),
            ),
            child: const Icon(Icons.history, color: teal, size: 18),
          ),
        ),
      ]),
    );
  }

  Widget _buildHeaderCard() {
    return AnimatedBuilder(
      animation: _glowAnim,
      builder: (_, __) => Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            colors: [Color(0xFF0D3D2A), Color(0xFF072214)],
            begin: Alignment.topLeft, end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: teal.withOpacity(0.22 + _glowAnim.value * 0.2)),
          boxShadow: [BoxShadow(
            color: teal.withOpacity(_glowAnim.value * 0.08),
            blurRadius: 16, spreadRadius: 2,
          )],
        ),
        child: Row(children: [
          Container(
            width: 52, height: 52,
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [Color(0xFF00C896), Color(0xFF007A58)],
                begin: Alignment.topLeft, end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(14),
              boxShadow: [BoxShadow(
                color: teal.withOpacity(0.4 + _glowAnim.value * 0.25), blurRadius: 12,
              )],
            ),
            child: const Center(child: Icon(Icons.code_rounded, color: Colors.white, size: 26)),
          ),
          const SizedBox(width: 14),
          Expanded(child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('Test Function', style: TextStyle(
                color: Colors.white, fontSize: 16, fontWeight: FontWeight.w800, fontFamily: 'Orbitron',
              )),
              const SizedBox(height: 3),
              Text('Kirim function custom dengan delay & loops',
                style: TextStyle(color: Colors.white.withOpacity(0.6), fontSize: 12)),
            ],
          )),
        ]),
      ),
    );
  }

  Widget _buildTargetField() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('Nomor Target', style: TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w600)),
        const SizedBox(height: 8),
        Container(
          decoration: BoxDecoration(
            color: cardBg, borderRadius: BorderRadius.circular(14),
            border: Border.all(color: teal.withOpacity(0.2)),
          ),
          child: TextField(
            controller: _targetCtrl,
            keyboardType: TextInputType.phone,
            inputFormatters: [FilteringTextInputFormatter.digitsOnly],
            style: const TextStyle(color: Colors.white, fontSize: 14),
            decoration: InputDecoration(
              hintText: '62xxx (contoh: 6281234567890)',
              hintStyle: TextStyle(color: Colors.white.withOpacity(0.35), fontSize: 13),
              prefixIcon: Icon(Icons.phone_android_rounded, color: teal, size: 20),
              border: InputBorder.none,
              contentPadding: const EdgeInsets.symmetric(vertical: 14, horizontal: 12),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildFuncField() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('Function / Message', style: TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w600)),
        const SizedBox(height: 8),
        Container(
          height: 160,
          decoration: BoxDecoration(
            color: cardBg, borderRadius: BorderRadius.circular(14),
            border: Border.all(color: teal.withOpacity(0.2)),
          ),
          child: TextField(
            controller: _funcCtrl,
            maxLines: null,
            expands: true,
            textAlignVertical: TextAlignVertical.top,
            style: const TextStyle(color: Colors.white, fontSize: 13, fontFamily: 'monospace'),
            decoration: InputDecoration(
              hintText: 'Paste function atau message di sini...',
              hintStyle: TextStyle(color: Colors.white.withOpacity(0.3), fontSize: 13),
              border: InputBorder.none,
              contentPadding: const EdgeInsets.all(14),
            ),
          ),
        ),
        const SizedBox(height: 8),
        Row(children: [
          Expanded(
            child: GestureDetector(
              onTap: _pasteFromClipboard,
              child: Container(
                height: 44,
                decoration: BoxDecoration(
                  color: teal.withOpacity(0.12),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: teal.withOpacity(0.4)),
                ),
                child: const Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.content_paste_rounded, color: teal, size: 18),
                    SizedBox(width: 8),
                    Text('Pilih File .js', style: TextStyle(color: teal, fontSize: 13, fontWeight: FontWeight.w600)),
                  ],
                ),
              ),
            ),
          ),
          const SizedBox(width: 10),
          GestureDetector(
            onTap: () => setState(() => _funcCtrl.clear()),
            child: Container(
              height: 44, width: 70,
              decoration: BoxDecoration(
                color: Colors.red.withOpacity(0.15),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: Colors.red.withOpacity(0.5)),
              ),
              child: const Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.close, color: Colors.redAccent, size: 16),
                  SizedBox(width: 4),
                  Text('Clear', style: TextStyle(color: Colors.redAccent, fontSize: 12, fontWeight: FontWeight.w600)),
                ],
              ),
            ),
          ),
        ]),
      ],
    );
  }

  Widget _buildDelayLoops() {
    return Row(children: [
      Expanded(child: _numField('Delay (ms)', _delayCtrl, Icons.timer_outlined)),
      const SizedBox(width: 12),
      Expanded(child: _numField('Jumlah Loops', _loopsCtrl, Icons.repeat_rounded)),
    ]);
  }

  Widget _numField(String label, TextEditingController ctrl, IconData icon) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: const TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.w600)),
        const SizedBox(height: 6),
        Container(
          decoration: BoxDecoration(
            color: cardBg, borderRadius: BorderRadius.circular(12),
            border: Border.all(color: teal.withOpacity(0.2)),
          ),
          child: TextField(
            controller: ctrl,
            keyboardType: TextInputType.number,
            inputFormatters: [FilteringTextInputFormatter.digitsOnly],
            style: const TextStyle(color: Colors.white, fontSize: 14),
            decoration: InputDecoration(
              prefixIcon: Icon(icon, color: teal, size: 18),
              border: InputBorder.none,
              contentPadding: const EdgeInsets.symmetric(vertical: 12, horizontal: 10),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildActionRow() {
    return Row(children: [
      Expanded(
        child: GestureDetector(
          onTap: _isSending ? null : _send,
          child: Container(
            height: 52,
            decoration: BoxDecoration(
              gradient: _isSending
                  ? LinearGradient(colors: [teal.withOpacity(0.4), teal.withOpacity(0.4)])
                  : const LinearGradient(colors: [Color(0xFF00C896), Color(0xFF00E5A8)]),
              borderRadius: BorderRadius.circular(14),
              boxShadow: [
                if (!_isSending)
                  BoxShadow(color: teal.withOpacity(0.4), blurRadius: 12, offset: const Offset(0, 4)),
              ],
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                if (_isSending)
                  const SizedBox(width: 18, height: 18,
                    child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                else
                  const Icon(Icons.send_rounded, color: Colors.white, size: 20),
                const SizedBox(width: 10),
                Text(
                  _isSending ? 'SENDING...' : 'KIRIM FUNCTION',
                  style: const TextStyle(
                    color: Colors.white, fontSize: 14, fontWeight: FontWeight.w900,
                    letterSpacing: 1.5, fontFamily: 'Orbitron',
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
      const SizedBox(width: 10),
      GestureDetector(
        onTap: () => setState(() {
          _targetCtrl.clear(); _funcCtrl.clear();
          _delayCtrl.text = '1000'; _loopsCtrl.text = '1'; _statusText = '';
        }),
        child: Container(
          width: 52, height: 52,
          decoration: BoxDecoration(
            color: Colors.red.withOpacity(0.12),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: Colors.red.withOpacity(0.4)),
          ),
          child: const Icon(Icons.refresh_rounded, color: Colors.redAccent, size: 22),
        ),
      ),
    ]);
  }

  Widget _buildStatusBadge() {
    final ok = _statusText.startsWith('✅');
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
        color: ok ? teal.withOpacity(0.12) : Colors.red.withOpacity(0.12),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: ok ? teal.withOpacity(0.4) : Colors.red.withOpacity(0.4)),
      ),
      child: Row(children: [
        Icon(ok ? Icons.check_circle_outline : Icons.error_outline,
          color: ok ? teal : Colors.redAccent, size: 18),
        const SizedBox(width: 8),
        Expanded(child: Text(_statusText, style: TextStyle(
          color: ok ? teal : Colors.redAccent, fontSize: 13, fontWeight: FontWeight.w600,
        ))),
      ]),
    );
  }

  Widget _buildInfoBox() {
    const items = [
      'Gunakan format nomor internasional (62xxx)',
      'Paste function atau message langsung di textarea',
      'Delay dalam milidetik (ms)',
      'Loops menentukan jumlah pengiriman',
      'Function akan dikirim sebagai payload',
    ];
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: cardBg, borderRadius: BorderRadius.circular(14),
        border: Border.all(color: teal.withOpacity(0.15)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Row(children: [
            Icon(Icons.info_outline_rounded, color: teal, size: 18),
            SizedBox(width: 8),
            Text('informasi', style: TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.w700)),
          ]),
          const SizedBox(height: 10),
          ...items.map((e) => Padding(
            padding: const EdgeInsets.only(bottom: 5),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('• ', style: TextStyle(color: teal, fontSize: 13)),
                Expanded(child: Text(e, style: TextStyle(color: Colors.white.withOpacity(0.7), fontSize: 12))),
              ],
            ),
          )),
        ],
      ),
    );
  }

  Widget _buildHistoryList() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('Riwayat Kirim', style: TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.w700)),
        const SizedBox(height: 8),
        ..._history.take(5).map((h) => Container(
          margin: const EdgeInsets.only(bottom: 8),
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(
            color: cardBg, borderRadius: BorderRadius.circular(10),
            border: Border.all(color: h['status'] == 'success'
              ? teal.withOpacity(0.25) : Colors.red.withOpacity(0.25)),
          ),
          child: Row(children: [
            Icon(
              h['status'] == 'success' ? Icons.check_circle_outline : Icons.cancel_outlined,
              color: h['status'] == 'success' ? teal : Colors.redAccent, size: 16,
            ),
            const SizedBox(width: 8),
            Expanded(child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(h['target'] ?? '', style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w600)),
                Text(h['func'] ?? '', style: TextStyle(color: Colors.white.withOpacity(0.5), fontSize: 11),
                  maxLines: 1, overflow: TextOverflow.ellipsis),
              ],
            )),
            Text(h['time'] ?? '', style: TextStyle(color: Colors.white.withOpacity(0.4), fontSize: 11)),
          ]),
        )),
      ],
    );
  }

  void _showHistoryDialog() {
    showModalBottomSheet(
      context: context,
      backgroundColor: bgMid,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (_) => Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Riwayat Pengiriman', style: TextStyle(
              color: Colors.white, fontSize: 15, fontWeight: FontWeight.w800, fontFamily: 'Orbitron')),
            const SizedBox(height: 12),
            if (_history.isEmpty)
              Center(child: Text('Belum ada riwayat.', style: TextStyle(color: Colors.white.withOpacity(0.5))))
            else
              ..._history.map((h) => ListTile(
                contentPadding: EdgeInsets.zero,
                leading: Icon(
                  h['status'] == 'success' ? Icons.check_circle_outline : Icons.cancel_outlined,
                  color: h['status'] == 'success' ? teal : Colors.redAccent,
                ),
                title: Text(h['target'] ?? '', style: const TextStyle(color: Colors.white, fontSize: 13)),
                subtitle: Text(h['func'] ?? '',
                  style: TextStyle(color: Colors.white.withOpacity(0.5), fontSize: 11),
                  maxLines: 1, overflow: TextOverflow.ellipsis),
                trailing: Text(h['time'] ?? '',
                  style: TextStyle(color: Colors.white.withOpacity(0.4), fontSize: 11)),
              )),
          ],
        ),
      ),
    );
  }
}
