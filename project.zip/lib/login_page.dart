import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:url_launcher/url_launcher.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:video_player/video_player.dart';
import 'dart:ui';
import 'services/api_config_service.dart'; // Import ApiConfigService
import 'buy_account.dart';

// HAPUS baris ini:
// const String baseUrl = "http://milikallah.404-eror.systems:5435";

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> with TickerProviderStateMixin {
  final userController = TextEditingController();
  final passController = TextEditingController();
  bool isLoading = false;
  String? androidId;
  late VideoPlayerController _videoController;
  late AnimationController _fadeController;
  late AnimationController _slideController;
  late Animation<double> _fadeAnimation;
  late Animation<Offset> _slideAnimation;
  
  // Tambahkan variable untuk menyimpan baseUrl
  String? _baseUrl;
  bool _isLoadingConfig = true;
  int _retryCount = 0;

  @override
  void initState() {
    super.initState();
    _loadBaseUrlAndInit();
    
    _initAnimations();
    _initVideoPlayer();
  }
  
  Future<void> _loadBaseUrlAndInit() async {
    setState(() {
      _isLoadingConfig = true;
    });
    
    try {
      print('🌐 LoginPage: Fetching ACTIVE URL from Gist...');
      final apiConfig = ApiConfigService();
      _baseUrl = await apiConfig.getBaseUrl();
      
      if (_baseUrl != null && _baseUrl!.isNotEmpty) {
        print('✅ Base URL loaded: $_baseUrl');
        setState(() {
          _isLoadingConfig = false;
          _retryCount = 0;
        });
        
        // Setelah baseUrl didapat, jalankan initLogin
        await initLogin();
      } else {
        throw Exception('Base URL is empty');
      }
      
    } catch (e) {
      print('❌ Error loading base URL: $e');
      
      // Retry mechanism dengan exponential backoff
      if (_retryCount < 3) {
        _retryCount++;
        final delay = Duration(seconds: _retryCount * 2);
        print('🔄 Retry $_retryCount/3 in ${delay.inSeconds} seconds...');
        
        Future.delayed(delay, () {
          if (mounted) {
            _loadBaseUrlAndInit();
          }
        });
      } else {
        // Fallback - tidak ada URL, user harus coba lagi
        setState(() {
          _baseUrl = null;
          _isLoadingConfig = false;
        });
        print('⚠️ Failed to get base URL, please retry');
        
        // Show error snackbar
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Row(
                children: [
                  Icon(Icons.warning_amber_rounded, color: Colors.white, size: 20),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      'Using fallback server. Configuration may be outdated.',
                      style: const TextStyle(fontSize: 12),
                    ),
                  ),
                ],
              ),
              backgroundColor: Colors.orange.shade900,
              behavior: SnackBarBehavior.floating,
              duration: const Duration(seconds: 3),
            ),
          );
        }
        
        // Tetap jalankan initLogin dengan fallback
        await initLogin();
      }
    }
  }
  
  void _initAnimations() {
    _fadeController = AnimationController(
      duration: const Duration(milliseconds: 1500),
      vsync: this,
    );

    _slideController = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    );

    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _fadeController, curve: Curves.easeInOut),
    );

    _slideAnimation = Tween<Offset>(
      begin: const Offset(0, 0.3),
      end: Offset.zero,
    ).animate(
      CurvedAnimation(parent: _slideController, curve: Curves.easeOutCubic),
    );

    _fadeController.forward();
    _slideController.forward();
  }
  
  void _initVideoPlayer() {
    _videoController = VideoPlayerController.asset('assets/videos/login.mp4')
      ..initialize().then((_) {
        if (mounted) {
          setState(() {});
          _videoController.setLooping(true);
          _videoController.play();
          _videoController.setVolume(0);
        }
      });
  }

  @override
  void dispose() {
    _videoController.dispose();
    _fadeController.dispose();
    _slideController.dispose();
    super.dispose();
  }

  Future<void> initLogin() async {
    androidId = await getAndroidId();

    final prefs = await SharedPreferences.getInstance();
    final savedUser = prefs.getString("username");
    final savedPass = prefs.getString("password");
    final savedKey = prefs.getString("key");

    if (savedUser != null && savedPass != null && savedKey != null && _baseUrl != null) {
      final uri = Uri.parse(
        "$_baseUrl/api/auth/myInfo?username=$savedUser&password=$savedPass&androidId=$androidId&key=$savedKey",
      );
      try {
        final res = await http.get(uri).timeout(const Duration(seconds: 10));
        final data = jsonDecode(res.body);

        if (data['valid'] == true && mounted) {
          Navigator.pushReplacementNamed(
            context,
            '/splash',
            arguments: {
              'username': savedUser,
              'password': savedPass,
              'role': data['role'],
              'key': data['key'],
              'expiredDate': data['expiredDate'],
              'listBug': data['listBug'] ?? [],
              'listPayload': data['listPayload'] ?? [],
              'listDDoS': data['listDDoS'] ?? [],
              'news': data['news'] ?? [],
            },
          );
        }
      } catch (e) {
        print('Auto login error: $e');
      }
    }
  }

  Future<String> getAndroidId() async {
    final deviceInfo = DeviceInfoPlugin();
    final android = await deviceInfo.androidInfo;
    return android.id ?? "unknown_device";
  }

  Future<void> login() async {
    final username = userController.text.trim();
    final password = passController.text.trim();

    if (username.isEmpty || password.isEmpty) {
      _showAlert("⚠️ Error", "Username and password are required.");
      return;
    }
    
    if (_baseUrl == null) {
      _showAlert("⚠️ Error", "Loading server configuration, please try again.");
      return;
    }

    setState(() => isLoading = true);

    try {
      final validate = await http.post(
        Uri.parse("$_baseUrl/api/auth/validate"),
        body: {
          "username": username,
          "password": password,
          "androidId": androidId ?? "unknown_device",
        },
      ).timeout(const Duration(seconds: 15));

      final validData = jsonDecode(validate.body);

      if (validData['expired'] == true) {
        _showAlert("⛔ Access Expired", "Your access has expired.\nPlease renew it.", showContact: true);
      } else if (validData['valid'] != true) {
        _showAlert("🚫 Login Failed", "Invalid username or password.", showContact: true);
      } else {
        final prefs = await SharedPreferences.getInstance();
        prefs.setString("username", username);
        prefs.setString("password", password);
        prefs.setString("key", validData['key']);

        if (mounted) {
          Navigator.pushNamed(
            context,
            '/splash',
            arguments: {
              'username': username,
              'password': password,
              'role': validData['role'],
              'key': validData['key'],
              'expiredDate': validData['expiredDate'],
              'listBug': validData['listBug'] ?? [],
              'listPayload': validData['listPayload'] ?? [],
              'listDDoS': validData['listDDoS'] ?? [],
              'news': validData['news'] ?? [],
            },
          );
        }
      }
    } catch (e) {
      print('Login error: $e');
      _showAlert("🌐 Connection Error", "Failed to connect to the server.\nPlease check your connection.");
    }

    if (mounted) {
      setState(() => isLoading = false);
    }
  }

  void _showAlert(String title, String msg, {bool showContact = false}) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: const Color(0xFF1E1E1E),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
        ),
        title: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.1),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Icon(
                title.contains("Error") || title.contains("Failed")
                    ? Icons.error_outline
                    : title.contains("Expired")
                    ? Icons.timer_off
                    : Icons.info_outline,
                color: title.contains("Error") || title.contains("Failed")
                    ? Colors.redAccent
                    : title.contains("Expired")
                    ? Colors.amber
                    : Colors.blue,
              ),
            ),
            const SizedBox(width: 12),
            Text(
              title,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 18,
                fontWeight: FontWeight.bold,
                fontFamily: 'Orbitron',
              ),
            ),
          ],
        ),
        content: Text(
          msg,
          style: const TextStyle(
            color: Colors.white70,
            fontSize: 14,
            fontFamily: 'ShareTechMono',
          ),
        ),
        actions: [
          if (showContact)
            TextButton.icon(
              onPressed: () async {
                final uri = Uri.parse("tg://resolve?domain=RaldzzXyz");
                if (await canLaunchUrl(uri)) {
                  await launchUrl(uri, mode: LaunchMode.externalApplication);
                } else {
                  await launchUrl(Uri.parse("https://t.me/RaldzzXyz"),
                      mode: LaunchMode.externalApplication);
                }
              },
              icon: const Icon(Icons.message, size: 18),
              label: const Text(
                "Contact Admin",
                style: TextStyle(
                  color: Colors.white,
                  fontFamily: 'Orbitron',
                  fontWeight: FontWeight.bold,
                ),
              ),
              style: TextButton.styleFrom(
                backgroundColor: Colors.blue.withOpacity(0.2),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
            ),
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text(
              "CLOSE",
              style: TextStyle(
                color: Colors.white,
                fontFamily: 'Orbitron',
                fontWeight: FontWeight.bold,
              ),
            ),
            style: TextButton.styleFrom(
              backgroundColor: Colors.white.withOpacity(0.1),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(8),
              ),
            ),
          ),
        ],
      ),
    );
  }
  
  // Fungsi untuk manual refresh base URL
  Future<void> _refreshBaseUrl() async {
    setState(() {
      _isLoadingConfig = true;
    });
    
    try {
      print('🔄 Manually refreshing base URL...');
      final apiConfig = ApiConfigService();
      final newUrl = await apiConfig.forceRefresh();
      
      if (newUrl.isNotEmpty) {
        setState(() {
          _baseUrl = newUrl;
          _isLoadingConfig = false;
        });
        print('✅ Base URL refreshed: $_baseUrl');
        
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Row(
                children: [
                  Icon(Icons.check_circle, color: Colors.white, size: 18),
                  const SizedBox(width: 8),
                  Text(
                    'Server configuration updated',
                    style: const TextStyle(fontSize: 12),
                  ),
                ],
              ),
              backgroundColor: Colors.green,
              behavior: SnackBarBehavior.floating,
              duration: const Duration(seconds: 2),
            ),
          );
        }
      } else {
        throw Exception('Base URL is empty after refresh');
      }
    } catch (e) {
      print('❌ Failed to refresh base URL: $e');
      setState(() {
        _isLoadingConfig = false;
      });
      
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: const Text('Failed to update server configuration'),
            backgroundColor: Colors.red.shade900,
            behavior: SnackBarBehavior.floating,
            duration: const Duration(seconds: 2),
          ),
        );
      }
    }
  }

  bool _obscurePassword = true;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF181818),
      body: _isLoadingConfig
          ? Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const CircularProgressIndicator(color: Color(0xFF64FFDA), strokeWidth: 2),
                  const SizedBox(height: 16),
                  const Text('Loading...', style: TextStyle(color: Colors.white54, fontSize: 12, fontFamily: 'ShareTechMono')),
                  if (_retryCount > 0)
                    Text('Retry $_retryCount/3', style: TextStyle(color: Colors.white38, fontSize: 10, fontFamily: 'ShareTechMono')),
                ],
              ),
            )
          : Stack(
              children: [
                // Background - dark dengan sedikit noise
                Container(
                  decoration: const BoxDecoration(
                    gradient: RadialGradient(
                      center: Alignment(0, -0.3),
                      radius: 1.2,
                      colors: [Color(0xFF1C1C1C), Color(0xFF141414)],
                    ),
                  ),
                ),

                // Login content
                SafeArea(
                  child: Center(
                    child: SingleChildScrollView(
                      padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 20),
                      child: FadeTransition(
                        opacity: _fadeAnimation,
                        child: SlideTransition(
                          position: _slideAnimation,
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              const SizedBox(height: 30),

                              // ── Logo circle ──
                              Container(
                                width: 110,
                                height: 110,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: const Color(0xFF1E1E2E),
                                  border: Border.all(color: Colors.white12, width: 1),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.black.withOpacity(0.4),
                                      blurRadius: 20,
                                      spreadRadius: 2,
                                    ),
                                  ],
                                ),
                                child: ClipOval(
                                  child: Image.asset(
                                    'assets/images/logo.png',
                                    fit: BoxFit.cover,
                                    errorBuilder: (_, __, ___) => const Icon(
                                      Icons.shield_rounded,
                                      color: Color(0xFF64FFDA),
                                      size: 48,
                                    ),
                                  ),
                                ),
                              ),

                              const SizedBox(height: 28),

                              // ── TEXAS title ──
                              RichText(
                                text: const TextSpan(
                                  children: [
                                    TextSpan(
                                      text: "TEXAS",
                                      style: TextStyle(
                                        color: Colors.white,
                                        fontSize: 32,
                                        fontWeight: FontWeight.w900,
                                        fontFamily: 'Orbitron',
                                        letterSpacing: 4,
                                      ),
                                    ),
                                    TextSpan(
                                      text: "X",
                                      style: TextStyle(
                                        color: Color(0xFF64FFDA),
                                        fontSize: 32,
                                        fontWeight: FontWeight.w900,
                                        fontFamily: 'Orbitron',
                                        letterSpacing: 4,
                                        shadows: [
                                          Shadow(color: Color(0xFF64FFDA), blurRadius: 12),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),

                              const SizedBox(height: 8),

                              // Subtitle
                              const Text(
                                "S i l a h k a n  L o g i n",
                                style: TextStyle(
                                  color: Colors.white38,
                                  fontSize: 13,
                                  fontFamily: 'ShareTechMono',
                                  letterSpacing: 1,
                                ),
                              ),

                              const SizedBox(height: 36),

                              // ── Form card ──
                              Container(
                                padding: const EdgeInsets.all(24),
                                decoration: BoxDecoration(
                                  color: const Color(0xFF1E1E1E),
                                  borderRadius: BorderRadius.circular(24),
                                  border: Border.all(color: Colors.white.withOpacity(0.07), width: 1),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.black.withOpacity(0.3),
                                      blurRadius: 24,
                                      spreadRadius: 2,
                                      offset: const Offset(0, 8),
                                    ),
                                  ],
                                ),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    const Text(
                                      "Welcome back",
                                      style: TextStyle(
                                        color: Colors.white,
                                        fontSize: 22,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                    const SizedBox(height: 4),
                                    const Text(
                                      "Masukkan Akunmu",
                                      style: TextStyle(
                                        color: Colors.white38,
                                        fontSize: 13,
                                        fontFamily: 'ShareTechMono',
                                      ),
                                    ),

                                    const SizedBox(height: 24),

                                    // Username field
                                    _buildTextField(
                                      controller: userController,
                                      hint: "Username",
                                      icon: Icons.person_outline_rounded,
                                    ),

                                    const SizedBox(height: 14),

                                    // Password field
                                    _buildPasswordField(),

                                    const SizedBox(height: 24),

                                    // SIGN IN button
                                    SizedBox(
                                      width: double.infinity,
                                      height: 54,
                                      child: GestureDetector(
                                        onTap: isLoading || _baseUrl == null ? null : login,
                                        child: Container(
                                          decoration: BoxDecoration(
                                            borderRadius: BorderRadius.circular(30),
                                            border: Border.all(color: const Color(0xFF64FFDA), width: 1.5),
                                            color: const Color(0xFF64FFDA).withOpacity(0.08),
                                          ),
                                          child: Center(
                                            child: isLoading
                                                ? const SizedBox(
                                                    width: 22,
                                                    height: 22,
                                                    child: CircularProgressIndicator(
                                                      color: Color(0xFF64FFDA),
                                                      strokeWidth: 2,
                                                    ),
                                                  )
                                                : const Row(
                                                    mainAxisAlignment: MainAxisAlignment.center,
                                                    children: [
                                                      Text(
                                                        "SiGN iN",
                                                        style: TextStyle(
                                                          color: Color(0xFF64FFDA),
                                                          fontSize: 15,
                                                          fontWeight: FontWeight.bold,
                                                          fontFamily: 'ShareTechMono',
                                                          letterSpacing: 2,
                                                        ),
                                                      ),
                                                      SizedBox(width: 8),
                                                      Icon(Icons.arrow_forward_rounded, color: Color(0xFF64FFDA), size: 18),
                                                    ],
                                                  ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),

                              const SizedBox(height: 36),

                              // ── Footer ──
                              Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Container(width: 40, height: 1, color: Colors.white12),
                                  const Padding(
                                    padding: EdgeInsets.symmetric(horizontal: 12),
                                    child: Text(
                                      "TEXAS TEAM",
                                      style: TextStyle(
                                        color: Colors.white24,
                                        fontSize: 11,
                                        fontFamily: 'ShareTechMono',
                                        letterSpacing: 2,
                                      ),
                                    ),
                                  ),
                                  Container(width: 40, height: 1, color: Colors.white12),
                                ],
                              ),
                              const SizedBox(height: 12),

                              // ── Buy Access Button ──
                              GestureDetector(
                                onTap: () => Navigator.push(
                                  context,
                                  MaterialPageRoute(builder: (_) => const BuyAccountPage()),
                                ),
                                child: Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(12),
                                    border: Border.all(color: Colors.purpleAccent.withOpacity(0.5), width: 1),
                                    color: Colors.purpleAccent.withOpacity(0.07),
                                  ),
                                  child: Row(
                                    mainAxisSize: MainAxisSize.min,
                                    children: const [
                                      Icon(Icons.shopping_bag_outlined, color: Colors.purpleAccent, size: 15),
                                      SizedBox(width: 8),
                                      Text(
                                        'Buy Access',
                                        style: TextStyle(
                                          fontFamily: 'Orbitron',
                                          fontSize: 12,
                                          fontWeight: FontWeight.bold,
                                          color: Colors.purpleAccent,
                                          letterSpacing: 1.5,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),

                              const SizedBox(height: 12),
                              Text(
                                "v2.0.2  ·  © 2026",
                                style: TextStyle(
                                  color: Colors.white.withOpacity(0.18),
                                  fontSize: 11,
                                  fontFamily: 'ShareTechMono',
                                  letterSpacing: 1,
                                ),
                              ),

                              const SizedBox(height: 20),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
    );
  }

  Widget _buildTextField({
    required TextEditingController controller,
    required String hint,
    required IconData icon,
  }) {
    return Container(
      decoration: BoxDecoration(
        color: const Color(0xFF252525),
        borderRadius: BorderRadius.circular(14),
      ),
      child: TextField(
        controller: controller,
        style: const TextStyle(color: Colors.white, fontFamily: 'ShareTechMono', fontSize: 14),
        decoration: InputDecoration(
          prefixIcon: Icon(icon, color: Colors.white38, size: 20),
          hintText: hint,
          hintStyle: const TextStyle(color: Colors.white24, fontFamily: 'ShareTechMono', fontSize: 14),
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
          enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: const BorderSide(color: Color(0xFF64FFDA), width: 1),
          ),
          contentPadding: const EdgeInsets.symmetric(vertical: 16, horizontal: 16),
        ),
      ),
    );
  }

  Widget _buildPasswordField() {
    return Container(
      decoration: BoxDecoration(
        color: const Color(0xFF252525),
        borderRadius: BorderRadius.circular(14),
      ),
      child: TextField(
        controller: passController,
        obscureText: _obscurePassword,
        style: const TextStyle(color: Colors.white, fontFamily: 'ShareTechMono', fontSize: 14),
        decoration: InputDecoration(
          prefixIcon: const Icon(Icons.lock_outline_rounded, color: Colors.white38, size: 20),
          suffixIcon: GestureDetector(
            onTap: () => setState(() => _obscurePassword = !_obscurePassword),
            child: Icon(
              _obscurePassword ? Icons.visibility_outlined : Icons.visibility_off_outlined,
              color: Colors.white38,
              size: 20,
            ),
          ),
          hintText: "Password",
          hintStyle: const TextStyle(color: Colors.white24, fontFamily: 'ShareTechMono', fontSize: 14),
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
          enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: const BorderSide(color: Color(0xFF64FFDA), width: 1),
          ),
          contentPadding: const EdgeInsets.symmetric(vertical: 16, horizontal: 16),
        ),
      ),
    );
  }}
