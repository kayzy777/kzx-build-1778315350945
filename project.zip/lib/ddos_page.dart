import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'chat_page.dart';
import 'nik_check_page.dart';
import 'phone_lookup.dart';
import 'subdomain_finder_page.dart';
import 'anime.dart';

class ToolsPage extends StatefulWidget {
  final String sessionKey;
  final String userRole;

  const ToolsPage({
    super.key,
    required this.sessionKey,
    required this.userRole,
  });

  @override
  State<ToolsPage> createState() => _ToolsPageState();
}

class _ToolsPageState extends State<ToolsPage> with TickerProviderStateMixin {
  late AnimationController _glowController;
  late Animation<double> _glowAnimation;

  final List<Map<String, dynamic>> _tools = [
    {
      'title': 'Chat AI',
      'description': 'AI-powered\nconversation',
      'icon': Icons.chat_bubble_rounded,
      'color': const Color(0xFF00B4FF),
      'bgColor': const Color(0xFF001E2E),
      'page': 'chat',
    },
    {
      'title': 'NIK Check',
      'description': 'Validate Indonesian\nidentity',
      'icon': Icons.badge_rounded,
      'color': const Color(0xFF00D4FF),
      'bgColor': const Color(0xFF001E2E),
      'page': 'nik',
    },
    {
      'title': 'Phone Lookup',
      'description': 'Find phone number\ninfo',
      'icon': Icons.phone_rounded,
      'color': const Color(0xFFFF9800),
      'bgColor': const Color(0xFF2A1800),
      'page': 'phone',
    },
    {
      'title': 'Subdomain Fi...',
      'description': 'Discover subdomains',
      'icon': Icons.language_rounded,
      'color': const Color(0xFFCC44FF),
      'bgColor': const Color(0xFF1A0028),
      'page': 'subdomain',
    },
    {
      'title': 'Anime',
      'description': 'Streaming, 18+',
      'icon': Icons.movie_rounded,
      'color': const Color(0xFFFF2D6B),
      'bgColor': const Color(0xFF280010),
      'page': 'anime',
    },
  ];

  @override
  void initState() {
    super.initState();
    _glowController = AnimationController(
      duration: const Duration(milliseconds: 1800),
      vsync: this,
    )..repeat(reverse: true);
    _glowAnimation = CurvedAnimation(
      parent: _glowController,
      curve: Curves.easeInOut,
    );
  }

  @override
  void dispose() {
    _glowController.dispose();
    super.dispose();
  }

  void _openTool(String page) {
    Widget? target;
    switch (page) {
      case 'chat':
        target = ChatPage(sessionKey: widget.sessionKey, username: '', role: widget.userRole);
        break;
      case 'nik':
        target = NIKCheckPage(sessionKey: widget.sessionKey);
        break;
      case 'phone':
        target = PhoneLookupPage(sessionKey: widget.sessionKey);
        break;
      case 'subdomain':
        target = SubdomainFinderPage(sessionKey: widget.sessionKey);
        break;
      case 'anime':
        target = const HomeAnimePage();
        break;
    }
    if (target != null) {
      Navigator.push(context, MaterialPageRoute(builder: (_) => target!));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0A0A12),
      appBar: AppBar(
        backgroundColor: const Color(0xFF0A0A12),
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Color(0xFF00B4FF)),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'TOOLS TEXAS',
          style: TextStyle(
            color: Color(0xFF00B4FF),
            fontSize: 20,
            fontWeight: FontWeight.bold,
            fontFamily: 'Orbitron',
            letterSpacing: 2,
          ),
        ),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        physics: const BouncingScrollPhysics(),
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildHeader(),
            const SizedBox(height: 24),
            _buildGrid(),
            const SizedBox(height: 16),
            Text(
              '${_tools.length} item',
              style: TextStyle(
                color: Colors.white.withOpacity(0.4),
                fontSize: 14,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ── HEADER ────────────────────────────────────────────────────────────────
  Widget _buildHeader() {
    return AnimatedBuilder(
      animation: _glowAnimation,
      builder: (_, __) => Container(
        width: double.infinity,
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: const Color(0xFF001A2E),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: const Color(0xFF00B4FF)
                .withOpacity(0.4 + _glowAnimation.value * 0.4),
            width: 1.5,
          ),
          boxShadow: [
            BoxShadow(
              color: const Color(0xFF00B4FF)
                  .withOpacity(0.1 + _glowAnimation.value * 0.15),
              blurRadius: 20,
              spreadRadius: 2,
            ),
          ],
        ),
        child: Column(
          children: [
            // Icon + teks
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  width: 60,
                  height: 60,
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [Color(0xFF00B4FF), Color(0xFF0077CC)],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    borderRadius: BorderRadius.circular(16),
                    boxShadow: [
                      BoxShadow(
                        color: const Color(0xFF00B4FF)
                            .withOpacity(0.4 + _glowAnimation.value * 0.3),
                        blurRadius: 16,
                        spreadRadius: 2,
                      ),
                    ],
                  ),
                  child: const Icon(Icons.build_rounded,
                      color: Colors.white, size: 30),
                ),
                const SizedBox(width: 16),
                const Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'TEXAS',
                      style: TextStyle(
                        color: Colors.white54,
                        fontSize: 13,
                        letterSpacing: 2,
                      ),
                    ),
                    Text(
                      'Gateway Tools',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 22,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ],
            ),

            const SizedBox(height: 16),

            // Badge bawah
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
              decoration: BoxDecoration(
                color: const Color(0xFF001428),
                borderRadius: BorderRadius.circular(30),
                border: Border.all(
                  color: const Color(0xFF00B4FF)
                      .withOpacity(0.5 + _glowAnimation.value * 0.3),
                  width: 1.5,
                ),
                boxShadow: [
                  BoxShadow(
                    color: const Color(0xFF00B4FF)
                        .withOpacity(0.1 + _glowAnimation.value * 0.1),
                    blurRadius: 12,
                  ),
                ],
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    'Tools Texas',
                    style: TextStyle(
                      color: const Color(0xFF00B4FF),
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                      shadows: [
                        Shadow(
                          color: const Color(0xFF00B4FF)
                              .withOpacity(0.6 + _glowAnimation.value * 0.4),
                          blurRadius: 12,
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 10),
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 12, vertical: 5),
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(
                        colors: [Color(0xFF00B4FF), Color(0xFF0077CC)],
                      ),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Text(
                      '${_tools.length} item',
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 13,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ── GRID ──────────────────────────────────────────────────────────────────
  Widget _buildGrid() {
    // Susun mirip screenshot: 2 kolom, card terakhir kiri bawah sendirian
    final rows = <Widget>[];
    for (int i = 0; i < _tools.length; i += 2) {
      if (i + 1 < _tools.length) {
        rows.add(Row(
          children: [
            Expanded(child: _buildCard(_tools[i])),
            const SizedBox(width: 12),
            Expanded(child: _buildCard(_tools[i + 1])),
          ],
        ));
      } else {
        rows.add(Row(
          children: [
            Expanded(child: _buildCard(_tools[i])),
            const SizedBox(width: 12),
            const Expanded(child: SizedBox()),
          ],
        ));
      }
      if (i + 2 < _tools.length) rows.add(const SizedBox(height: 12));
    }
    return Column(children: rows);
  }

  Widget _buildCard(Map<String, dynamic> tool) {
    final Color color = tool['color'] as Color;
    final Color bg = tool['bgColor'] as Color;

    return GestureDetector(
      onTap: () => _openTool(tool['page'] as String),
      child: AnimatedBuilder(
        animation: _glowAnimation,
        builder: (_, __) => Container(
          height: 150,
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: bg,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(
              color: color.withOpacity(0.45 + _glowAnimation.value * 0.3),
              width: 1.5,
            ),
            boxShadow: [
              BoxShadow(
                color: color.withOpacity(0.12 + _glowAnimation.value * 0.1),
                blurRadius: 16,
                spreadRadius: 1,
              ),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Icon box
              Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(
                  color: color.withOpacity(0.18),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(tool['icon'] as IconData,
                    color: color, size: 24),
              ),

              const Spacer(),

              // Title
              Text(
                tool['title'] as String,
                style: TextStyle(
                  color: color,
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  shadows: [
                    Shadow(
                      color: color.withOpacity(0.4),
                      blurRadius: 6,
                    ),
                  ],
                ),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),

              const SizedBox(height: 4),

              // Description
              Text(
                tool['description'] as String,
                style: TextStyle(
                  color: Colors.white.withOpacity(0.55),
                  fontSize: 11,
                  height: 1.4,
                ),
                maxLines: 2,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
