import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:web_socket_channel/io.dart';
import 'package:intl/intl.dart';

import 'services/api_config_service.dart';

// ============ WARNA ============
class AppColors {
  static const Color background = Color(0xFFF8FAFC);
  static const Color surface = Colors.white;
  static const Color surfaceDark = Color(0xFFF1F5F9);
  static const Color primary = Color(0xFF2563EB);
  static const Color primaryLight = Color(0xFF3B82F6);
  static const Color success = Color(0xFF10B981);
  static const Color error = Color(0xFFEF4444);
  static const Color textPrimary = Color(0xFF0F172A);
  static const Color textSecondary = Color(0xFF475569);
  static const Color textTertiary = Color(0xFF94A3B8);
  static const Color border = Color(0xFFE2E8F0);
  
  // Role colors
  static const Color owner = Color(0xFFEF4444);
  static const Color vip = Color(0xFFF59E0B);
  static const Color reseller = Color(0xFF3B82F6);
  static const Color user = Color(0xFF64748B);
}

// ============ MODEL ============
class ChatMessage {
  final String username;
  final String role;
  final String message;
  final DateTime timestamp;
  final bool isMe;
  final bool isSending; // Untuk animasi loading

  ChatMessage({
    required this.username,
    required this.role,
    required this.message,
    required this.timestamp,
    required this.isMe,
    this.isSending = false,
  });

  factory ChatMessage.fromJson(Map<String, dynamic> json, String currentUser) {
    return ChatMessage(
      username: json['username'] ?? 'Unknown',
      role: json['role'] ?? 'user',
      message: json['message'] ?? '',
      timestamp: DateTime.tryParse(json['time'] ?? '') ?? DateTime.now(),
      isMe: json['username'] == currentUser,
    );
  }

  ChatMessage copyWith({bool? isSending}) {
    return ChatMessage(
      username: username,
      role: role,
      message: message,
      timestamp: timestamp,
      isMe: isMe,
      isSending: isSending ?? this.isSending,
    );
  }

  String get formattedTime => DateFormat('HH:mm').format(timestamp.toLocal());
}

class OnlineUser {
  final String username;
  final String role;

  OnlineUser({required this.username, required this.role});

  factory OnlineUser.fromJson(Map<String, dynamic> json) {
    return OnlineUser(
      username: json['username'] ?? '',
      role: json['role'] ?? 'user',
    );
  }

  Color get roleColor {
    switch (role.toLowerCase()) {
      case 'owner': return AppColors.owner;
      case 'vip': return AppColors.vip;
      case 'reseller': return AppColors.reseller;
      default: return AppColors.user;
    }
  }

  String get roleBadge {
    switch (role.toLowerCase()) {
      case 'owner': return 'OWNER';
      case 'vip': return 'VIP';
      case 'reseller': return 'RESELLER';
      default: return 'MEMBER';
    }
  }
}

// ============ CHAT PAGE ============
class ChatPage extends StatefulWidget {
  final String sessionKey;
  final String username;
  final String role;

  const ChatPage({
    super.key,
    required this.sessionKey,
    required this.username,
    required this.role,
  });

  @override
  State<ChatPage> createState() => _ChatPageState();
}

class _ChatPageState extends State<ChatPage> with TickerProviderStateMixin {
  // WebSocket
  late IOWebSocketChannel _channel;
  bool _isConnected = false;
  bool _isConnecting = true;
  Timer? _reconnectTimer;

  // Data
  final List<ChatMessage> _messages = [];
  final List<OnlineUser> _onlineUsers = [];
  final TextEditingController _messageController = TextEditingController();
  final ScrollController _scrollController = ScrollController();
  final FocusNode _focusNode = FocusNode();

  // UI State
  bool _showOnlineUsers = false;
  String _searchQuery = '';
  
  // Animations
  late AnimationController _fadeController;
  late Animation<double> _fadeAnimation;

  @override
  void initState() {
    super.initState();
    _initAnimations();
    _connect();
  }

  void _initAnimations() {
    _fadeController = AnimationController(
      duration: const Duration(milliseconds: 300),
      vsync: this,
    );
    _fadeAnimation = CurvedAnimation(
      parent: _fadeController,
      curve: Curves.easeInOut,
    );
    _fadeController.forward();
  }

  Future<void> _connect() async {
    setState(() {
      _isConnecting = true;
      _isConnected = false;
    });

    try {
      // Ambil base URL dari ApiConfigService lalu convert ke WS URL
      final baseUrl = await ApiConfigService().getBaseUrl();
      final wsUrl = baseUrl
          .replaceFirst(RegExp(r'^https://'), 'wss://')
          .replaceFirst(RegExp(r'^http://'), 'ws://');

      _channel = IOWebSocketChannel.connect(wsUrl);

      _channel.stream.listen(
        _onMessage,
        onError: _onError,
        onDone: _onDone,
      );

      Future.delayed(const Duration(milliseconds: 500), () {
        if (_channel.sink != null) {
          _channel.sink.add(jsonEncode({
            'type': 'joinGlobalChat',
            'username': widget.username,
            'role': widget.role,
          }));
        }
      });
    } catch (e) {
      _onError(e);
    }
  }

  void _onMessage(dynamic rawData) {
    try {
      final data = jsonDecode(rawData);
      
      switch (data['type']) {
        case 'chatHistory':
          final List msgs = data['messages'] ?? [];
          setState(() {
            _messages.clear();
            for (var msg in msgs.reversed) {
              _messages.add(ChatMessage.fromJson(msg, widget.username));
            }
            _isConnected = true;
            _isConnecting = false;
          });
          _scrollToBottom();
          break;

        case 'globalChat':
          final newMsg = ChatMessage.fromJson(data, widget.username);
          
          // Cek dan hapus pesan "sending" jika ada
          setState(() {
            _messages.removeWhere((m) => m.isSending == true);
            _messages.insert(0, newMsg);
          });
          
          // Animasi fade in untuk pesan baru
          _fadeController.reset();
          _fadeController.forward();
          _scrollToBottom();
          break;

        case 'onlineUsers':
          final List users = data['users'] ?? [];
          setState(() {
            _onlineUsers.clear();
            for (var user in users) {
              _onlineUsers.add(OnlineUser.fromJson(user));
            }
          });
          break;

        case 'system':
          _showSystemMessage(data['message']);
          break;

        case 'error':
          _showError(data['message']);
          break;
      }
    } catch (e) {
      debugPrint('Parse error: $e');
    }
  }

  void _onError(dynamic err) {
    debugPrint('WebSocket error: $err');
    setState(() {
      _isConnected = false;
      _isConnecting = false;
    });
    _scheduleReconnect();
  }

  void _onDone() {
    debugPrint('WebSocket disconnected');
    setState(() {
      _isConnected = false;
      _isConnecting = false;
    });
    _scheduleReconnect();
  }

  void _scheduleReconnect() {
    _reconnectTimer?.cancel();
    _reconnectTimer = Timer(const Duration(seconds: 5), () {
      if (mounted) _connect();
    });
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          0,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  // ============ SEND MESSAGE DENGAN ANIMASI ============
  void _sendMessage() async {
    final text = _messageController.text.trim();
    
    if (text.isEmpty) {
      _showError('Message cannot be empty');
      return;
    }
    
    if (text.length > 500) {
      _showError('Message too long (max 500)');
      return;
    }
    
    if (!_isConnected) {
      _showError('Not connected to server');
      return;
    }

    // Buat pesan sementara dengan status "sending"
    final tempMessage = ChatMessage(
      username: widget.username,
      role: widget.role,
      message: text,
      timestamp: DateTime.now(),
      isMe: true,
      isSending: true,
    );

    setState(() {
      _messages.insert(0, tempMessage);
      _messageController.clear();
    });
    _scrollToBottom();

    try {
      _channel.sink.add(jsonEncode({
        'type': 'globalChat',
        'message': text,
      }));
    } catch (e) {
      // Hapus pesan sending jika gagal
      setState(() {
        _messages.removeWhere((m) => m.isSending == true);
      });
      _showError('Failed to send message');
    }
  }

  void _showSystemMessage(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            Icon(Icons.info_outline, color: Colors.white, size: 18),
            const SizedBox(width: 8),
            Expanded(child: Text(message)),
          ],
        ),
        backgroundColor: AppColors.primary,
        behavior: SnackBarBehavior.floating,
        duration: const Duration(seconds: 2),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
      ),
    );
  }

  void _showError(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            Icon(Icons.error_outline, color: Colors.white, size: 18),
            const SizedBox(width: 8),
            Expanded(child: Text(message)),
          ],
        ),
        backgroundColor: AppColors.error,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
      ),
    );
  }

  void _showUserProfile(OnlineUser user) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (context) => FadeTransition(
        opacity: _fadeAnimation,
        child: Container(
          decoration: const BoxDecoration(
            color: AppColors.surface,
            borderRadius: BorderRadius.only(
              topLeft: Radius.circular(24),
              topRight: Radius.circular(24),
            ),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 40,
                height: 4,
                margin: const EdgeInsets.only(top: 12),
                decoration: BoxDecoration(
                  color: AppColors.border,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  children: [
                    Hero(
                      tag: user.username,
                      child: CircleAvatar(
                        radius: 40,
                        backgroundColor: user.roleColor.withOpacity(0.1),
                        child: Text(
                          user.username.isNotEmpty ? user.username[0].toUpperCase() : '?',
                          style: TextStyle(color: user.roleColor, fontSize: 32, fontWeight: FontWeight.bold),
                        ),
                      ),
                    ),
                    const SizedBox(height: 16),
                    Text(
                      user.username,
                      style: const TextStyle(color: AppColors.textPrimary, fontSize: 20, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 8),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                      decoration: BoxDecoration(
                        color: user.roleColor.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Text(
                        user.roleBadge,
                        style: TextStyle(color: user.roleColor, fontWeight: FontWeight.w600, fontSize: 12),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    _reconnectTimer?.cancel();
    if (_channel.sink != null) _channel.sink.close();
    _messageController.dispose();
    _scrollController.dispose();
    _focusNode.dispose();
    _fadeController.dispose();
    super.dispose();
  }


  // Extra state for new features
  bool _showEmoji = false;
  String _groupName = "Obrolan Global";

  void _showRenameDialog() {
    if (widget.role.toLowerCase() != 'owner') return;
    final ctrl = TextEditingController(text: _groupName);
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: const Color(0xFF1A1F2E),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Text("Ubah Nama Group", style: TextStyle(color: Colors.white, fontSize: 16)),
        content: TextField(
          controller: ctrl,
          style: const TextStyle(color: Colors.white),
          decoration: InputDecoration(
            hintText: "Nama group...",
            hintStyle: TextStyle(color: Colors.white38),
            filled: true,
            fillColor: Colors.white.withOpacity(0.08),
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide.none),
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text("Batal", style: TextStyle(color: Colors.white54))),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF5C6BC0)),
            onPressed: () {
              setState(() => _groupName = ctrl.text.trim().isNotEmpty ? ctrl.text.trim() : _groupName);
              Navigator.pop(context);
              // Send rename event via WS
              _channel.sink.add(jsonEncode({'type': 'renameGroup', 'name': _groupName, 'username': widget.username}));
            },
            child: const Text("Simpan"),
          ),
        ],
      ),
    );
  }

  Future<void> _pickAndSendImage() async {
    // Kirim placeholder foto
    if (!_isConnected) return;
    _channel.sink.add(jsonEncode({
      'type': 'sendMessage',
      'username': widget.username,
      'role': widget.role,
      'message': '[📷 Foto]',
    }));
  }

  void _sendVoiceMessage() {
    _channel.sink.add(jsonEncode({
      'type': 'sendMessage',
      'username': widget.username,
      'role': widget.role,
      'message': '[🎤 Pesan Suara]',
    }));
  }

  @override
  Widget build(BuildContext context) {
    const darkBg = Color(0xFF0D1117);
    const navyBg = Color(0xFF131720);

    return Scaffold(
      backgroundColor: darkBg,
      body: SafeArea(
        child: Column(
          children: [
            // ── AppBar ──
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
              decoration: BoxDecoration(
                color: navyBg,
                border: Border(bottom: BorderSide(color: Colors.white.withOpacity(0.06))),
              ),
              child: Row(
                children: [
                  GestureDetector(
                    onTap: () => Navigator.pop(context),
                    child: const Icon(Icons.arrow_back, color: Colors.white, size: 24),
                  ),
                  const SizedBox(width: 12),
                  // Avatar group
                  CircleAvatar(
                    radius: 20,
                    backgroundColor: const Color(0xFF5C6BC0),
                    child: Text(
                      _groupName.isNotEmpty ? _groupName[0].toUpperCase() : "G",
                      style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: GestureDetector(
                      onTap: widget.role.toLowerCase() == 'owner' ? _showRenameDialog : null,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Text(_groupName, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16)),
                              if (widget.role.toLowerCase() == 'owner') ...[
                                const SizedBox(width: 4),
                                const Icon(Icons.edit, color: Colors.white38, size: 13),
                              ],
                            ],
                          ),
                          Text(
                            "${_messages.length} pesan • ${_onlineUsers.length} peserta",
                            style: TextStyle(color: Colors.white38, fontSize: 11),
                          ),
                        ],
                      ),
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.search, color: Colors.white70, size: 22),
                    onPressed: () {},
                  ),
                  IconButton(
                    icon: const Icon(Icons.more_vert, color: Colors.white70, size: 22),
                    onPressed: () => setState(() => _showOnlineUsers = !_showOnlineUsers),
                  ),
                ],
              ),
            ),

            // ── Body ──
            Expanded(
              child: Stack(
                children: [
                  // Messages
                  _isConnecting
                      ? const Center(child: CircularProgressIndicator(color: Color(0xFF5C6BC0)))
                      : !_isConnected
                          ? _buildDisconnected()
                          : _messages.isEmpty
                              ? _buildEmpty()
                              : ListView.builder(
                                  controller: _scrollController,
                                  reverse: true,
                                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                                  itemCount: _messages.length,
                                  itemBuilder: (_, i) => _buildMessageBubble(_messages[i]),
                                ),

                  // Online users overlay
                  if (_showOnlineUsers)
                    Positioned(
                      top: 0, right: 0, bottom: 0,
                      child: GestureDetector(
                        onTap: () {},
                        child: Container(
                          width: MediaQuery.of(context).size.width * 0.75,
                          decoration: BoxDecoration(
                            color: navyBg,
                            border: Border(left: BorderSide(color: Colors.white.withOpacity(0.08))),
                            boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.3), blurRadius: 20)],
                          ),
                          child: _buildSidebar(),
                        ),
                      ),
                    ),
                  if (_showOnlineUsers)
                    Positioned(
                      top: 0, left: 0, right: 0, bottom: 0,
                      child: GestureDetector(
                        onTap: () => setState(() => _showOnlineUsers = false),
                        child: Container(
                          color: Colors.black.withOpacity(0.3),
                          margin: EdgeInsets.only(right: MediaQuery.of(context).size.width * 0.75),
                        ),
                      ),
                    ),
                ],
              ),
            ),

            // ── Emoji picker placeholder ──
            if (_showEmoji)
              Container(
                height: 250,
                color: navyBg,
                child: GridView.builder(
                  padding: const EdgeInsets.all(8),
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 8, mainAxisSpacing: 4, crossAxisSpacing: 4),
                  itemCount: _commonEmojis.length,
                  itemBuilder: (_, i) => GestureDetector(
                    onTap: () {
                      _messageController.text += _commonEmojis[i];
                      _messageController.selection = TextSelection.fromPosition(TextPosition(offset: _messageController.text.length));
                    },
                    child: Center(child: Text(_commonEmojis[i], style: const TextStyle(fontSize: 24))),
                  ),
                ),
              ),

            // ── Input bar ──
            _buildInput(),
          ],
        ),
      ),
    );
  }

  static const List<String> _commonEmojis = [
    '😀','😂','😍','🥰','😎','😭','😡','🤔',
    '👍','👎','❤️','🔥','💯','🎉','😱','🙏',
    '😴','🤣','😊','😏','🥺','😤','🤩','😇',
    '👋','✌️','🤙','💪','🫡','🫶','🤝','👀',
    '💀','😈','🤡','👻','💩','🎭','🌚','☠️',
  ];

  Widget _buildMessageBubble(ChatMessage message) {
    final isMe = message.isMe;
    final Color avatarColor;
    switch (message.role.toLowerCase()) {
      case 'owner': avatarColor = Colors.red.shade400; break;
      case 'vip': avatarColor = Colors.amber.shade400; break;
      case 'reseller': avatarColor = const Color(0xFF5C6BC0); break;
      default: avatarColor = const Color(0xFF5C6BC0);
    }

    return Padding(
      padding: EdgeInsets.only(
        bottom: 4,
        left: isMe ? 40 : 0,
        right: isMe ? 0 : 40,
      ),
      child: Column(
        crossAxisAlignment: isMe ? CrossAxisAlignment.end : CrossAxisAlignment.start,
        children: [
          if (!isMe)
            Padding(
              padding: const EdgeInsets.only(left: 48, bottom: 2),
              child: Text(message.username, style: TextStyle(color: avatarColor, fontSize: 12, fontWeight: FontWeight.w600)),
            ),
          Row(
            mainAxisAlignment: isMe ? MainAxisAlignment.end : MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              if (!isMe) ...[
                CircleAvatar(
                  radius: 18,
                  backgroundColor: avatarColor,
                  child: Text(
                    message.username.isNotEmpty ? message.username[0].toUpperCase() : "?",
                    style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 14),
                  ),
                ),
                const SizedBox(width: 8),
              ],
              Flexible(
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                  decoration: BoxDecoration(
                    color: isMe ? const Color(0xFF3949AB) : const Color(0xFF1E2333),
                    borderRadius: BorderRadius.only(
                      topLeft: const Radius.circular(18),
                      topRight: const Radius.circular(18),
                      bottomLeft: Radius.circular(isMe ? 18 : 4),
                      bottomRight: Radius.circular(isMe ? 4 : 18),
                    ),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Text(
                        message.message,
                        style: TextStyle(
                          color: isMe ? Colors.white : Colors.white.withOpacity(0.9),
                          fontSize: 14,
                          height: 1.4,
                        ),
                      ),
                      const SizedBox(height: 3),
                      Text(
                        message.formattedTime,
                        style: TextStyle(color: Colors.white.withOpacity(0.4), fontSize: 10),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildEmpty() {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.chat_bubble_outline, color: Colors.white12, size: 64),
          const SizedBox(height: 12),
          Text("Belum ada pesan", style: TextStyle(color: Colors.white38, fontSize: 14)),
        ],
      ),
    );
  }

  Widget _buildDisconnected() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.wifi_off, color: Colors.white24, size: 48),
          const SizedBox(height: 12),
          const Text("Terputus", style: TextStyle(color: Colors.white54, fontSize: 16)),
          const SizedBox(height: 16),
          ElevatedButton.icon(
            onPressed: _connect,
            icon: const Icon(Icons.refresh, size: 18),
            label: const Text("Reconnect"),
            style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF5C6BC0), foregroundColor: Colors.white),
          ),
        ],
      ),
    );
  }

  Widget _buildInput() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
      color: const Color(0xFF131720),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          // Emoji button
          GestureDetector(
            onTap: () => setState(() => _showEmoji = !_showEmoji),
            child: Container(
              width: 40, height: 40,
              decoration: const BoxDecoration(shape: BoxShape.circle),
              child: Icon(
                _showEmoji ? Icons.keyboard : Icons.emoji_emotions_outlined,
                color: Colors.white54, size: 24,
              ),
            ),
          ),

          // Attachment button
          GestureDetector(
            onTap: _pickAndSendImage,
            child: Container(
              width: 40, height: 40,
              child: const Icon(Icons.attach_file, color: Colors.white54, size: 24),
            ),
          ),

          // Text field
          Expanded(
            child: Container(
              constraints: const BoxConstraints(maxHeight: 120),
              margin: const EdgeInsets.symmetric(horizontal: 4),
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 2),
              decoration: BoxDecoration(
                color: const Color(0xFF1E2333),
                borderRadius: BorderRadius.circular(24),
              ),
              child: TextField(
                controller: _messageController,
                focusNode: _focusNode,
                style: const TextStyle(color: Colors.white, fontSize: 14),
                maxLines: null,
                enabled: _isConnected,
                onTap: () => setState(() => _showEmoji = false),
                decoration: InputDecoration(
                  hintText: "Ketik pesan...",
                  hintStyle: TextStyle(color: Colors.white.withOpacity(0.3), fontSize: 14),
                  border: InputBorder.none,
                  contentPadding: const EdgeInsets.symmetric(vertical: 10),
                  counterText: '',
                ),
                onSubmitted: (_) => _sendMessage(),
              ),
            ),
          ),

          // Send / Mic button
          GestureDetector(
            onTap: () {
              if (_messageController.text.trim().isNotEmpty) {
                _sendMessage();
              } else {
                _sendVoiceMessage();
              }
            },
            child: Container(
              width: 44, height: 44,
              decoration: const BoxDecoration(color: Color(0xFF5C6BC0), shape: BoxShape.circle),
              child: ValueListenableBuilder<TextEditingValue>(
                valueListenable: _messageController,
                builder: (_, val, __) => Icon(
                  val.text.trim().isNotEmpty ? Icons.send_rounded : Icons.mic,
                  color: Colors.white, size: 20,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSidebar() {
    final filtered = _onlineUsers.where((u) => u.username.toLowerCase().contains(_searchQuery.toLowerCase())).toList();
    final me = OnlineUser(username: widget.username, role: widget.role);

    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            children: [
              const Icon(Icons.people, color: Color(0xFF5C6BC0), size: 18),
              const SizedBox(width: 8),
              Text("Online (${_onlineUsers.length})", style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
              const Spacer(),
              GestureDetector(
                onTap: () => setState(() => _showOnlineUsers = false),
                child: const Icon(Icons.close, color: Colors.white38, size: 20),
              ),
            ],
          ),
        ),
        Expanded(
          child: ListView(
            children: [
              _buildUserTile(me, isMe: true),
              ...filtered.where((u) => u.username != widget.username).map(_buildUserTile),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildUserTile(OnlineUser user, {bool isMe = false}) {
    final Color roleColor;
    switch (user.role.toLowerCase()) {
      case 'owner': roleColor = Colors.red.shade400; break;
      case 'vip': roleColor = Colors.amber.shade400; break;
      default: roleColor = const Color(0xFF5C6BC0);
    }
    return ListTile(
      leading: CircleAvatar(
        backgroundColor: roleColor.withOpacity(0.2),
        child: Text(user.username.isNotEmpty ? user.username[0].toUpperCase() : "?",
            style: TextStyle(color: roleColor, fontWeight: FontWeight.bold)),
      ),
      title: Text(isMe ? "You" : user.username, style: TextStyle(color: isMe ? const Color(0xFF5C6BC0) : Colors.white, fontWeight: FontWeight.w600)),
      subtitle: Text(user.role.toUpperCase(), style: TextStyle(color: roleColor, fontSize: 10)),
    );
  }

}
