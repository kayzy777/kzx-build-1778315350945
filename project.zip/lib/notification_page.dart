import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;

import 'services/api_config_service.dart';

class NotificationPage extends StatefulWidget {
  final String sessionKey;

  const NotificationPage({super.key, required this.sessionKey});

  @override
  State<NotificationPage> createState() => _NotificationPageState();
}

class _NotificationPageState extends State<NotificationPage>
    with SingleTickerProviderStateMixin {
  static const Color teal      = Color(0xFF00C896);
  static const Color tealLight = Color(0xFF00E5A8);
  static const Color bgDark    = Color(0xFF061610);
  static const Color bgMid     = Color(0xFF0A1F18);
  static const Color cardBg    = Color(0xFF0D2920);
  static const Color redCard   = Color(0xFF1F0A0A);

  List<Map<String, dynamic>> _notifs = [];
  bool _isLoading = true;
  String? _error;

  late AnimationController _bellCtrl;
  late Animation<double>   _bellAnim;

  @override
  void initState() {
    super.initState();
    _bellCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    );
    _bellAnim = Tween<double>(begin: -0.1, end: 0.1).animate(
      CurvedAnimation(parent: _bellCtrl, curve: Curves.elasticIn),
    );
    _bellCtrl.repeat(reverse: true);
    _loadNotifications();
  }

  @override
  void dispose() {
    _bellCtrl.dispose();
    super.dispose();
  }

  // ─── Load ──────────────────────────────────────────────────────────────────
  Future<void> _loadNotifications() async {
    setState(() { _isLoading = true; _error = null; });
    try {
      final baseUrl = await ApiConfig.baseUrl;
      final res = await http.get(
        Uri.parse('$baseUrl/api/user/getNotifications?key=${widget.sessionKey}'),
      ).timeout(const Duration(seconds: 15));

      final data = jsonDecode(res.body) as Map<String, dynamic>;
      if (!mounted) return;
      if (data['valid'] == true) {
        setState(() {
          _notifs = List<Map<String, dynamic>>.from(data['notifications'] ?? []);
          _isLoading = false;
        });
      } else {
        setState(() { _error = data['message'] ?? 'Gagal load'; _isLoading = false; });
      }
    } catch (e) {
      if (!mounted) return;
      setState(() { _error = 'Error: $e'; _isLoading = false; });
    }
  }

  // ─── Tandai dibaca ─────────────────────────────────────────────────────────
  Future<void> _markRead(String notifId) async {
    try {
      final baseUrl = await ApiConfig.baseUrl;
      await http.post(
        Uri.parse('$baseUrl/api/user/markNotifRead'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'key': widget.sessionKey, 'notifId': notifId}),
      );
      setState(() {
        final idx = _notifs.indexWhere((n) => n['id'] == notifId);
        if (idx != -1) _notifs[idx]['isRead'] = true;
      });
    } catch (_) {}
  }

  // ─── Tandai semua dibaca ───────────────────────────────────────────────────
  Future<void> _markAllRead() async {
    try {
      final baseUrl = await ApiConfig.baseUrl;
      await http.post(
        Uri.parse('$baseUrl/api/user/markAllNotifRead'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'key': widget.sessionKey}),
      );
      setState(() {
        for (final n in _notifs) n['isRead'] = true;
      });
    } catch (_) {}
  }

  // ─── Hapus notif ───────────────────────────────────────────────────────────
  Future<void> _deleteNotif(String notifId) async {
    try {
      final baseUrl = await ApiConfig.baseUrl;
      await http.delete(
        Uri.parse('$baseUrl/api/user/deleteNotif?key=${widget.sessionKey}&notifId=$notifId'),
      );
      setState(() => _notifs.removeWhere((n) => n['id'] == notifId));
      _showSnack('Notifikasi dihapus', Colors.red.shade700);
    } catch (_) {}
  }

  // ─── Helpers ───────────────────────────────────────────────────────────────
  int get _unreadCount => _notifs.where((n) => n['isRead'] != true).length;

  String _timeAgo(String? iso) {
    if (iso == null) return '';
    try {
      final dt   = DateTime.parse(iso).toLocal();
      final diff = DateTime.now().difference(dt);
      if (diff.inSeconds < 60)  return '${diff.inSeconds}d yang lalu';
      if (diff.inMinutes < 60)  return '${diff.inMinutes}m yang lalu';
      if (diff.inHours < 24)    return '${diff.inHours}h yang lalu';
      return '${diff.inDays}h yang lalu';
    } catch (_) {
      return '';
    }
  }

  void _showSnack(String msg, Color color) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg, style: const TextStyle(color: Colors.white)),
      backgroundColor: color,
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      duration: const Duration(seconds: 2),
    ));
  }

  void _showContextMenu(Map<String, dynamic> notif) {
    final id    = notif['id'] as String;
    final msg   = '${notif['title']}\n${notif['message']}';
    final isRead = notif['isRead'] == true;

    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF0F1E19),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (_) => Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const SizedBox(height: 8),
          Container(width: 36, height: 4,
            decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(2))),
          const SizedBox(height: 12),
          if (!isRead)
            _contextItem(Icons.check_circle_outline, 'Tandai Dibaca', Colors.white, () {
              Navigator.pop(context); _markRead(id);
            }),
          _contextItem(Icons.delete_outline, 'Hapus Notifikasi', Colors.redAccent, () {
            Navigator.pop(context); _deleteNotif(id);
          }),
          _contextItem(Icons.copy_outlined, 'Salin Pesan', Colors.white, () {
            Navigator.pop(context);
            Clipboard.setData(ClipboardData(text: msg));
            _showSnack('Pesan disalin!', teal);
          }),
          const Divider(color: Colors.white12, height: 1),
          _contextItem(Icons.cancel_outlined, 'Tutup', Colors.white54, () => Navigator.pop(context)),
          const SizedBox(height: 12),
        ],
      ),
    );
  }

  Widget _contextItem(IconData icon, String label, Color color, VoidCallback onTap) {
    return InkWell(
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
        child: Row(children: [
          Icon(icon, color: color, size: 22),
          const SizedBox(width: 16),
          Text(label, style: TextStyle(color: color, fontSize: 15, fontWeight: FontWeight.w500)),
        ]),
      ),
    );
  }

  // ─── Build ─────────────────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgDark,
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter, end: Alignment.bottomCenter,
            colors: [bgMid, bgDark],
          ),
        ),
        child: SafeArea(child: Column(children: [
          _buildHeader(),
          Expanded(child: _buildBody()),
          _buildFooter(),
        ])),
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.4),
        border: Border(bottom: BorderSide(color: teal.withOpacity(0.15))),
      ),
      child: Row(children: [
        GestureDetector(
          onTap: () => Navigator.pop(context),
          child: Container(
            width: 36, height: 36,
            decoration: BoxDecoration(
              color: teal.withOpacity(0.1), borderRadius: BorderRadius.circular(10),
              border: Border.all(color: teal.withOpacity(0.3)),
            ),
            child: const Icon(Icons.arrow_back_ios_new, color: teal, size: 16),
          ),
        ),
        const SizedBox(width: 12),
        // Bell icon animasi
        AnimatedBuilder(
          animation: _bellAnim,
          builder: (_, child) => Transform.rotate(angle: _bellAnim.value, child: child),
          child: Container(
            width: 36, height: 36,
            decoration: BoxDecoration(
              color: Colors.red.withOpacity(0.15),
              shape: BoxShape.circle,
              border: Border.all(color: Colors.red.withOpacity(0.4)),
            ),
            child: const Icon(Icons.notifications_active, color: Colors.redAccent, size: 20),
          ),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('Notifikasi', style: TextStyle(
              color: Colors.white, fontSize: 16, fontWeight: FontWeight.w800, fontFamily: 'Orbitron',
            )),
            Text(
              _isLoading ? 'Memuat...' : '$_unreadCount pesan baru',
              style: TextStyle(color: Colors.white.withOpacity(0.55), fontSize: 12),
            ),
          ]),
        ),
        GestureDetector(
          onTap: () => Navigator.pop(context),
          child: Container(
            width: 30, height: 30,
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.08),
              shape: BoxShape.circle,
            ),
            child: const Icon(Icons.close, color: Colors.white54, size: 16),
          ),
        ),
      ]),
    );
  }

  Widget _buildBody() {
    if (_isLoading) {
      return const Center(child: CircularProgressIndicator(color: teal));
    }
    if (_error != null) {
      return Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
        const Icon(Icons.error_outline, color: Colors.redAccent, size: 40),
        const SizedBox(height: 8),
        Text(_error!, style: const TextStyle(color: Colors.white54, fontSize: 13)),
        const SizedBox(height: 12),
        GestureDetector(
          onTap: _loadNotifications,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
            decoration: BoxDecoration(
              color: teal.withOpacity(0.15),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: teal.withOpacity(0.4)),
            ),
            child: const Text('Coba Lagi', style: TextStyle(color: teal, fontWeight: FontWeight.w600)),
          ),
        ),
      ]));
    }
    if (_notifs.isEmpty) {
      return Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
        Icon(Icons.notifications_none, color: Colors.white.withOpacity(0.2), size: 60),
        const SizedBox(height: 12),
        Text('Belum ada notifikasi', style: TextStyle(color: Colors.white.withOpacity(0.4), fontSize: 14)),
      ]));
    }

    return RefreshIndicator(
      color: teal,
      backgroundColor: bgMid,
      onRefresh: _loadNotifications,
      child: ListView.separated(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
        itemCount: _notifs.length,
        separatorBuilder: (_, __) => const SizedBox(height: 8),
        itemBuilder: (ctx, i) => _buildNotifCard(_notifs[i]),
      ),
    );
  }

  Widget _buildNotifCard(Map<String, dynamic> notif) {
    final isRead  = notif['isRead'] == true;
    final isBaru  = notif['isBaru'] == true;
    final id      = notif['id'] as String? ?? '';
    final title   = notif['title'] as String? ?? '';
    final message = notif['message'] as String? ?? '';
    final time    = _timeAgo(notif['createdAt'] as String?);

    return GestureDetector(
      onLongPress: () => _showContextMenu(notif),
      onTap: () { if (!isRead) _markRead(id); },
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 300),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: isRead ? cardBg : (isBaru ? redCard : const Color(0xFF0F1E15)),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: isRead
                ? Colors.white.withOpacity(0.06)
                : (isBaru ? Colors.red.withOpacity(0.4) : teal.withOpacity(0.3)),
            width: isRead ? 1 : 1.5,
          ),
          boxShadow: isRead ? [] : [
            BoxShadow(
              color: (isBaru ? Colors.red : teal).withOpacity(0.08),
              blurRadius: 12, spreadRadius: 1,
            ),
          ],
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Expanded(child: Row(children: [
              Text(
                title,
                style: TextStyle(
                  color: isRead ? Colors.white70 : Colors.white,
                  fontSize: 14,
                  fontWeight: isRead ? FontWeight.w500 : FontWeight.w800,
                ),
              ),
              if (isBaru && !isRead) ...[
                const SizedBox(width: 8),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
                  decoration: BoxDecoration(
                    color: Colors.red.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(5),
                    border: Border.all(color: Colors.red.withOpacity(0.5)),
                  ),
                  child: const Text('BARU', style: TextStyle(
                    color: Colors.redAccent, fontSize: 9, fontWeight: FontWeight.w900, letterSpacing: 1,
                  )),
                ),
              ],
            ])),
            GestureDetector(
              onTap: () => _showContextMenu(notif),
              child: Icon(Icons.more_vert, color: Colors.white.withOpacity(0.3), size: 18),
            ),
          ]),
          const SizedBox(height: 6),
          Text(
            message,
            style: TextStyle(
              color: isRead ? Colors.white38 : Colors.white.withOpacity(0.7),
              fontSize: 12.5,
              height: 1.4,
            ),
            maxLines: 3,
            overflow: TextOverflow.ellipsis,
          ),
          const SizedBox(height: 10),
          Row(children: [
            Icon(Icons.access_time, color: Colors.white.withOpacity(0.3), size: 12),
            const SizedBox(width: 4),
            Text(time, style: TextStyle(color: Colors.white.withOpacity(0.35), fontSize: 11)),
          ]),
        ]),
      ),
    );
  }

  Widget _buildFooter() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.4),
        border: Border(top: BorderSide(color: teal.withOpacity(0.1))),
      ),
      child: Row(children: [
        Expanded(
          child: GestureDetector(
            onTap: _markAllRead,
            child: Container(
              height: 46,
              decoration: BoxDecoration(
                color: const Color(0xFF0F1E19),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: Colors.white.withOpacity(0.1)),
              ),
              child: const Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                Icon(Icons.check_circle_outline, color: Colors.white70, size: 18),
                SizedBox(width: 8),
                Text('Tandai Semua Dibaca', style: TextStyle(
                  color: Colors.white70, fontSize: 13, fontWeight: FontWeight.w600,
                )),
              ]),
            ),
          ),
        ),
        const SizedBox(width: 10),
        GestureDetector(
          onTap: _loadNotifications,
          child: Container(
            width: 46, height: 46,
            decoration: BoxDecoration(
              color: Colors.red.withOpacity(0.15),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: Colors.red.withOpacity(0.3)),
            ),
            child: const Icon(Icons.refresh, color: Colors.redAccent, size: 20),
          ),
        ),
      ]),
    );
  }
}
