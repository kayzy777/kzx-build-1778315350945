// ignore_for_file: use_build_context_synchronously
import 'dart:ui';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/status.dart' as status;
import 'package:url_launcher/url_launcher.dart';
import 'package:video_player/video_player.dart';
import 'package:http/http.dart' as http;

import 'telegram.dart';
import 'admin_page.dart';
import 'home_page.dart';
import 'seller_page.dart';
import 'change_password_page.dart';
import 'ddos_page.dart';
import 'chat_page.dart';
import 'login_page.dart';
import 'custom_bug.dart';
import 'bug_group.dart';
import 'ddos_panel.dart';
import 'sender_page.dart';
import 'txs_menu_page.dart';
import 'quick_actions_widget.dart';
import 'tqto.dart';
import 'alquran_page.dart';
import 'hadith_widget.dart';
import 'services/api_config_service.dart';
import 'contact_page.dart'; // Import ContactPage
import 'notification_page.dart';
import 'nik_check_page.dart';
import 'debug_connection_page.dart';
import 'anime.dart';
import 'manta_music_page.dart';
import 'build_app_page.dart';
import 'device_dashboard.dart';
import 'phone_lookup.dart';
import 'chat_ai_page.dart';

class DashboardPage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listPayload;
  final List<Map<String, dynamic>> listDDoS;
  final List<dynamic> news;

  const DashboardPage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.listBug,
    required this.listPayload,
    required this.listDDoS,
    required this.sessionKey,
    required this.news,
  });

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _animation;
  late WebSocketChannel channel;
  late VideoPlayerController _videoController;
  bool _videoInitialized = false;

  late String sessionKey;
  late String username;
  late String password;
  late String role;
  late String expiredDate;
  late List<Map<String, dynamic>> listBug;
  late List<Map<String, dynamic>> listPayload;
  late List<Map<String, dynamic>> listDDoS;
  late List<dynamic> newsList;
  String androidId = "unknown";
  int _unreadNotifCount = 0;

  int _selectedIndex = 0;
  Widget _selectedPage = const Placeholder();
  int _currentNavIndex = 0; // 0=home, 1=group bug, 2=texas menu, 3=tools

  // Nav items untuk NXOB bar
  late List<Map<String, dynamic>> _navItems;
  final ScrollController _homeScrollController = ScrollController();
  double _bannerOpacity = 1.0;
  double _subtitleOpacity = 1.0;

  void _initNavItems() {
    _navItems = [
      {'label': 'Home',      'color': const Color(0xFF9E9E9E), 'page': 'home',  'subtitle': ''},
      {'label': 'Group Bug', 'color': const Color(0xFF9C27B0), 'page': 'group', 'subtitle': ''},
      {'label': 'Texas Bug', 'color': const Color(0xFF00C896), 'page': 'lx',    'subtitle': ''},
      {'label': 'Tools',     'color': const Color(0xFF00BCD4), 'page': 'tools', 'subtitle': ''},
    ];
  }

  void _applyNavItem(Map<String, dynamic> item) {
    switch (item['page']) {
      case 'home':
        // Reset banner & scroll saat balik ke home
        if (_homeScrollController.hasClients) {
          _homeScrollController.jumpTo(0);
        }
        setState(() {
          _bannerOpacity = 1.0;
          _subtitleOpacity = 1.0;
          _selectedPage = _buildHomePage();
        });
        break;
      case 'group':
        setState(() => _selectedPage = GroupBugPage(
          username: username, password: password,
          role: role, expiredDate: expiredDate, sessionKey: sessionKey,
        ));
        break;
      case 'lx':
        setState(() => _selectedPage = TxsMenuPage(
          username: username, password: password,
          role: role, expiredDate: expiredDate, sessionKey: sessionKey,
          listBug: listBug, listPayload: listPayload,
        ));
        break;
      case 'tools':
        setState(() => _selectedPage = _buildToolsPage());
        break;
    }
  }

  // Activity log state
  List<Map<String, dynamic>> _activityLogs = [];
  bool _isLoadingActivityLogs = false;
  bool _hasActivityLogsError = false;

  // Stats
  int _onlineUsers = 0;
  int _activeConnections = 0;

  // Define blue color theme
  static const Color primaryBlue = Color(0xFF9E9E9E);
  static const Color darkBlue = Color(0xFF616161);
  static const Color lightBlue = Color(0xFFBDBDBD);

  @override
  void initState() {
    super.initState();
    _homeScrollController.addListener(() {
      final offset = _homeScrollController.offset;
      setState(() {
        _bannerOpacity = (1.0 - (offset / 160.0)).clamp(0.0, 1.0);
        _subtitleOpacity = (1.0 - (offset / 80.0)).clamp(0.0, 1.0);
      });
    });
    sessionKey = widget.sessionKey;
    username = widget.username;
    password = widget.password;
    role = widget.role;
    expiredDate = widget.expiredDate;
    listBug = widget.listBug;
    listPayload = widget.listPayload;
    listDDoS = widget.listDDoS;
    newsList = widget.news;

    _controller = AnimationController(
      duration: const Duration(milliseconds: 400),
      vsync: this,
    );
    _animation = CurvedAnimation(parent: _controller, curve: Curves.easeInOut);
    _controller.forward();

    _selectedPage = _buildHomePage();
    _initNavItems();

    _initVideo();
    _initAndroidIdAndConnect();

    // Fetch activity logs when the page is first loaded
    _fetchActivityLogs();
    
    // Fetch unread notification count
    _fetchUnreadNotifCount();
    
    // Simulasi update stats
    _updateStats(10, 5);
  }

  Future<void> _fetchUnreadNotifCount() async {
    try {
      final baseUrl = await ApiConfig.baseUrl;
      final res = await http.get(
        Uri.parse('$baseUrl/api/user/getNotifications?key=$sessionKey'),
      ).timeout(const Duration(seconds: 10));
      final data = jsonDecode(res.body) as Map<String, dynamic>;
      if (data['valid'] == true && mounted) {
        final notifs = data['notifications'] as List? ?? [];
        setState(() {
          _unreadNotifCount = notifs.where((n) => n['isRead'] != true).length;
        });
      }
    } catch (_) {}
  }

  void _initVideo() {
    _videoController = VideoPlayerController.asset('assets/videos/r.mp4')
      ..initialize().then((_) {
        setState(() {
          _videoInitialized = true;
        });
        _videoController.play();
        _videoController.setLooping(true);
        _videoController.setVolume(0.5);
      }).catchError((error) {
        print("Error initializing video: $error");
      });
  }

  Future<void> _initAndroidIdAndConnect() async {
    final deviceInfo = await DeviceInfoPlugin().androidInfo;
    androidId = deviceInfo.id;
    _connectToWebSocket();
  }

  void _connectToWebSocket() {
    channel = WebSocketChannel.connect(Uri.parse('wss://ws.nullxteam.fun'));
    channel.sink.add(jsonEncode({
      "type": "validate",
      "key": sessionKey,
      "androidId": androidId,
    }));

    channel.sink.add(jsonEncode({"type": "stats"}));

    channel.stream.listen((event) {
      final data = jsonDecode(event);

      if (data['type'] == 'myInfo') {
        if (data['valid'] == false) {
          if (data['reason'] == 'androidIdMismatch') {
            _handleInvalidSession("Your account has logged on another device.");
          } else if (data['reason'] == 'keyInvalid') {
            _handleInvalidSession("Key is not valid. Please login again.");
          }
        }
      } else if (data['type'] == 'stats') {
        _updateStats(data['onlineUsers'] ?? 0, data['activeConnections'] ?? 0);
      }
    });
  }

  void _updateStats(int online, int active) {
    setState(() {
      _onlineUsers = online;
      _activeConnections = active;
    });
  }

  Future<void> _fetchActivityLogs() async {
    setState(() {
      _isLoadingActivityLogs = true;
      _hasActivityLogsError = false;
    });

    try {
      final baseUrl = await ApiConfig.baseUrl;
      final url = Uri.parse('$baseUrl/api/user/getActivityLogs?key=$sessionKey');
      
      final response = await http.get(url).timeout(
        const Duration(seconds: 15),
        onTimeout: () {
          throw Exception('Connection timeout. Server not responding.');
        },
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['valid'] == true && data['logs'] != null) {
          setState(() {
            _activityLogs = List<Map<String, dynamic>>.from(data['logs']);
            _isLoadingActivityLogs = false;
          });
        } else {
          setState(() {
            _isLoadingActivityLogs = false;
            _hasActivityLogsError = true;
          });
        }
      } else {
        throw Exception('HTTP Error ${response.statusCode}');
      }
    } catch (e) {
      print('Error fetching activity logs: $e');
      try {
        await ApiConfig.refresh();
      } catch (refreshError) {
        // Ignore refresh error
      }
      setState(() {
        _isLoadingActivityLogs = false;
        _hasActivityLogsError = true;
      });
    }
  }

  Future<void> _refreshBaseUrl() async {
    try {
      final newUrl = await ApiConfig.refresh();
      if (!mounted) return;
      
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Row(
            children: [
              const Icon(Icons.check_circle, color: Colors.white),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  'Base URL updated: $newUrl',
                  style: const TextStyle(color: Colors.white),
                ),
              ),
            ],
          ),
          backgroundColor: primaryBlue,
          duration: const Duration(seconds: 2),
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(8),
          ),
        ),
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Failed to refresh URL: ${e.toString()}'),
          backgroundColor: Colors.red,
          behavior: SnackBarBehavior.floating,
        ),
      );
    }
  }

  void _handleInvalidSession(String message) async {
    await Future.delayed(const Duration(milliseconds: 300));
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();

    if (!mounted) return;
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        backgroundColor: Colors.black.withOpacity(0.8),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(18),
          side: BorderSide(color: primaryBlue.withOpacity(0.3), width: 1),
        ),
        title: const Text("⚠️ Session Expired", style: TextStyle(color: Colors.white, fontFamily: "Orbitron")),
        content: Text(message, style: const TextStyle(color: Colors.white70, fontFamily: "ShareTechMono")),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(context).pushAndRemoveUntil(
                MaterialPageRoute(builder: (_) => const LoginPage()),
                (route) => false,
              );
            },
            child: Text("OK", style: TextStyle(color: primaryBlue)),
          ),
        ],
      ),
    );
  }

  Widget _buildHomePage() {
    return RefreshIndicator(
      color: primaryBlue,
      onRefresh: () async {
        await _fetchActivityLogs();
        await Future.delayed(const Duration(seconds: 1));
        setState(() {});
      },
      child: SingleChildScrollView(
        controller: _homeScrollController,
        physics: const AlwaysScrollableScrollPhysics(),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // TEXAS BANNER - smooth collapse on scroll down, expand on scroll up
            AnimatedOpacity(
              opacity: _bannerOpacity,
              duration: const Duration(milliseconds: 16),
              child: SizedBox(
                height: 260 * _bannerOpacity,
                child: OverflowBox(
                  alignment: Alignment.topCenter,
                  maxHeight: 260,
                  child: _buildMantaBanner(),
                ),
              ),
            ),

            // HEADER
            _buildHeaderWithCircle(),

            const SizedBox(height: 16),

            // NEWS WIDGET
            _buildNewsWidget(),

            const SizedBox(height: 20),

            // QUICK ACTIONS WIDGET
            QuickActionsWidget(
              username: username,
              role: role,
              expiredDate: expiredDate,
              sessionKey: sessionKey,
              listBug: listBug,
              listPayload: listPayload,
              listDDoS: listDDoS,
            ),

            const SizedBox(height: 20),

            // JOIN COMMUNITY BUTTON
            _buildJoinCommunityButton(),

            const SizedBox(height: 20),

            // HADITH WIDGET
            const HadithWidget(),

            const SizedBox(height: 20),

            // CONNECT WIDGET
            _buildConnectWidget(),

            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  Widget _buildJoinCommunityButton() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Row(
        children: [
          // Button kiri: Join Channel
          Expanded(
            child: GestureDetector(
              onTap: () => _launchUrl('https://t.me/maklolacurrr'),
              child: Container(
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  color: const Color(0xFF1A1A1A),
                  borderRadius: BorderRadius.circular(18),
                  border: Border.all(color: Colors.white.withOpacity(0.08), width: 1),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      width: 44,
                      height: 44,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(color: Colors.white54, width: 1.5),
                        color: Colors.transparent,
                      ),
                      child: const Icon(
                        Icons.send_rounded,
                        color: Colors.white,
                        size: 20,
                      ),
                    ),
                    const SizedBox(height: 16),
                    const Text(
                      'Join Channel',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 15,
                        fontWeight: FontWeight.bold,
                        fontFamily: 'ShareTechMono',
                        letterSpacing: 0.5,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      'Get updates',
                      style: TextStyle(
                        color: Colors.white.withOpacity(0.45),
                        fontSize: 12,
                        fontFamily: 'ShareTechMono',
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),

          const SizedBox(width: 12),

          // Button kanan: Room Chat Global
          Expanded(
            child: GestureDetector(
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => ChatPage(
                      sessionKey: sessionKey,
                      username: username,
                      role: role,
                    ),
                  ),
                );
              },
              child: Container(
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  color: const Color(0xFF1A1A1A),
                  borderRadius: BorderRadius.circular(18),
                  border: Border.all(color: Colors.white.withOpacity(0.08), width: 1),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      width: 44,
                      height: 44,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(6),
                        border: Border.all(color: Colors.white54, width: 1.5),
                        color: Colors.transparent,
                      ),
                      child: const Icon(
                        Icons.chat_bubble_outline_rounded,
                        color: Colors.white,
                        size: 20,
                      ),
                    ),
                    const SizedBox(height: 16),
                    const Text(
                      'Room Chat',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 15,
                        fontWeight: FontWeight.bold,
                        fontFamily: 'ShareTechMono',
                        letterSpacing: 0.5,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      'Global chat room',
                      style: TextStyle(
                        color: Colors.white.withOpacity(0.45),
                        fontSize: 12,
                        fontFamily: 'ShareTechMono',
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMantaBanner() {
    return SizedBox(
      width: double.infinity,
      height: 260,
      child: Stack(
        children: [
          // Hexagon pattern full area
          Positioned.fill(
            child: CustomPaint(
              painter: _HexPatternPainter(),
            ),
          ),
          // Content centered
          Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const SizedBox(height: 10),
                // Main title "texas"
                Text(
                  "texas",
                  style: GoogleFonts.pacifico(
                    fontSize: 78,
                    color: const Color(0xFF64FFDA),
                    letterSpacing: 2,
                    shadows: const [
                      Shadow(color: Color(0xFF64FFDA), blurRadius: 30),
                      Shadow(color: Color(0xFF00BFA5), blurRadius: 60),
                    ],
                  ),
                ),
                const SizedBox(height: 10),
                // Pill badge + tagline fade on scroll
                AnimatedOpacity(
                  opacity: _subtitleOpacity,
                  duration: const Duration(milliseconds: 30),
                  child: Column(
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 7),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(30),
                          border: Border.all(color: const Color(0xFF64FFDA).withOpacity(0.6), width: 1),
                          color: const Color(0xFF64FFDA).withOpacity(0.05),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: const [
                            Icon(Icons.circle_outlined, color: Color(0xFF64FFDA), size: 8),
                            SizedBox(width: 10),
                            Text(
                              "TEXAS FOR YOU",
                              style: TextStyle(
                                color: Color(0xFF64FFDA),
                                fontSize: 13,
                                fontWeight: FontWeight.bold,
                                fontFamily: "ShareTechMono",
                                letterSpacing: 2.5,
                              ),
                            ),
                            SizedBox(width: 10),
                            Icon(Icons.circle_outlined, color: Color(0xFF64FFDA), size: 8),
                          ],
                        ),
                      ),
                      const SizedBox(height: 10),
                      const Text(
                        "Gacor  ·  Terupdate  ·  Mantaps",
                        style: TextStyle(
                          color: Color(0xFF8899AA),
                          fontSize: 14,
                          letterSpacing: 1.5,
                          fontFamily: "ShareTechMono",
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeaderWithCircle() {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.fromLTRB(16, 10, 16, 5),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: const Color(0xFF1C1C1C),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: const Color(0xFF64FFDA).withOpacity(0.15), width: 1),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.4),
            blurRadius: 20,
            spreadRadius: 2,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // ── Row atas: avatar + info + timer icon ──
          Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              // Avatar circle - pink/red gradient dengan shield icon
              Container(
                width: 64,
                height: 64,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: const LinearGradient(
                    colors: [Color(0xFFE91E63), Color(0xFFC2185B)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: const Color(0xFFE91E63).withOpacity(0.4),
                      blurRadius: 12,
                      spreadRadius: 1,
                    ),
                  ],
                ),
                child: ClipOval(
                  child: Image.asset(
                    'assets/images/ryn.png',
                    fit: BoxFit.cover,
                    errorBuilder: (_, __, ___) => const Icon(
                      Icons.verified_user,
                      color: Colors.white,
                      size: 30,
                    ),
                  ),
                ),
              ),

              const SizedBox(width: 14),

              // Welcome + username + role pill
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Welcome Back,',
                      style: TextStyle(
                        color: Colors.white54,
                        fontSize: 13,
                        fontFamily: 'ShareTechMono',
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      username,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 22,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 0.3,
                      ),
                    ),
                    const SizedBox(height: 6),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
                      decoration: BoxDecoration(
                        color: const Color(0xFF2A2A3A),
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(color: Colors.white24, width: 1),
                      ),
                      child: Text(
                        role.toUpperCase(),
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 11,
                          fontWeight: FontWeight.bold,
                          fontFamily: 'ShareTechMono',
                          letterSpacing: 1.5,
                        ),
                      ),
                    ),
                  ],
                ),
              ),

              // Notification bell button (teal)
              GestureDetector(
                onTap: () async {
                  await Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => NotificationPage(sessionKey: sessionKey),
                    ),
                  );
                  _fetchUnreadNotifCount();
                },
                child: Stack(
                  clipBehavior: Clip.none,
                  children: [
                    Container(
                      width: 44,
                      height: 44,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: const Color(0xFF00BFA5),
                        boxShadow: [
                          BoxShadow(
                            color: const Color(0xFF00BFA5).withOpacity(0.4),
                            blurRadius: 10,
                            spreadRadius: 1,
                          ),
                        ],
                      ),
                      child: const Icon(Icons.notifications_rounded, color: Colors.white, size: 22),
                    ),
                    if (_unreadNotifCount > 0)
                      Positioned(
                        top: -2, right: -2,
                        child: Container(
                          padding: const EdgeInsets.all(4),
                          decoration: BoxDecoration(
                            color: Colors.red,
                            shape: BoxShape.circle,
                            border: Border.all(color: const Color(0xFF1C1C1C), width: 1.5),
                          ),
                          child: Text(
                            _unreadNotifCount > 9 ? '9+' : '$_unreadNotifCount',
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 8,
                              fontWeight: FontWeight.w900,
                            ),
                          ),
                        ),
                      ),
                  ],
                ),
              ),
            ],
          ),

          const SizedBox(height: 18),

          // ── TEXAS DASHBOARD pill ──
          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(vertical: 10),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(30),
              border: Border.all(color: const Color(0xFF64FFDA).withOpacity(0.4), width: 1),
              color: const Color(0xFF64FFDA).withOpacity(0.04),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: const [
                Icon(Icons.circle_outlined, color: Color(0xFF64FFDA), size: 8),
                SizedBox(width: 10),
                Text(
                  'TEXAS DASHBOARD',
                  style: TextStyle(
                    color: Color(0xFF64FFDA),
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'ShareTechMono',
                    letterSpacing: 2.5,
                  ),
                ),
                SizedBox(width: 10),
                Icon(Icons.circle_outlined, color: Color(0xFF64FFDA), size: 8),
              ],
            ),
          ),

          const SizedBox(height: 20),

          // ── Stats row: Online Users | Active Connections | Expiration ──
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              // Online Users
              _buildStatItem(
                icon: Icons.group_rounded,
                iconColor: const Color(0xFF4CAF50),
                iconBg: const Color(0xFF1B3A2A),
                value: '$_onlineUsers',
                label: 'Online Users',
              ),
              // Active Connections
              _buildStatItem(
                icon: Icons.link_rounded,
                iconColor: const Color(0xFF9E9E9E),
                iconBg: const Color(0xFF1A2A3A),
                value: '$_activeConnections',
                label: 'Active Connections',
              ),
              // Expiration
              _buildStatItem(
                icon: Icons.calendar_month_rounded,
                iconColor: const Color(0xFFFF9800),
                iconBg: const Color(0xFF3A2A10),
                value: expiredDate,
                label: 'Expiration',
                valueSize: 13,
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildStatItem({
    required IconData icon,
    required Color iconColor,
    required Color iconBg,
    required String value,
    required String label,
    double valueSize = 20,
  }) {
    return Column(
      children: [
        Container(
          width: 56,
          height: 56,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: iconBg,
            border: Border.all(color: iconColor.withOpacity(0.3), width: 1.5),
            boxShadow: [
              BoxShadow(
                color: iconColor.withOpacity(0.2),
                blurRadius: 10,
                spreadRadius: 1,
              ),
            ],
          ),
          child: Icon(icon, color: iconColor, size: 26),
        ),
        const SizedBox(height: 8),
        Text(
          value,
          style: TextStyle(
            color: Colors.white,
            fontSize: valueSize,
            fontWeight: FontWeight.bold,
            fontFamily: 'ShareTechMono',
          ),
        ),
        const SizedBox(height: 2),
        Text(
          label,
          style: TextStyle(
            color: Colors.white.withOpacity(0.45),
            fontSize: 10,
            fontFamily: 'ShareTechMono',
          ),
          textAlign: TextAlign.center,
        ),
      ],
    );
  }

  Widget _buildNewsWidget() {
    // Jika tidak ada berita dari server, tampilkan loading
    if (newsList.isEmpty) {
      return Container(
        width: double.infinity,
        margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        decoration: BoxDecoration(
          color: const Color(0xFF1E1E1E),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: primaryBlue.withOpacity(0.5),
            width: 1.5,
          ),
          boxShadow: [
            BoxShadow(
              color: primaryBlue.withOpacity(0.3),
              blurRadius: 15,
              spreadRadius: 2,
              offset: const Offset(0, 5),
            ),
          ],
        ),
        child: const Center(
          child: Padding(
            padding: EdgeInsets.all(40),
            child: CircularProgressIndicator(color: primaryBlue),
          ),
        ),
      );
    }

    // Ambil berita pertama dari server
    final latestNews = newsList.first;
    final String title = latestNews['title'] ?? '';
    final String desc = latestNews['desc'] ?? '';
    final String imageUrl = latestNews['image'] ?? '';

    return Container(
      width: double.infinity,
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      decoration: BoxDecoration(
        color: const Color(0xFF1E1E1E),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: primaryBlue.withOpacity(0.5),
          width: 1.5,
        ),
        boxShadow: [
          BoxShadow(
            color: primaryBlue.withOpacity(0.3),
            blurRadius: 15,
            spreadRadius: 2,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // GAMBAR (tanpa border radius sendiri)
          SizedBox(
            height: 180,
            width: double.infinity,
            child: ClipRRect(
              borderRadius: const BorderRadius.only(
                topLeft: Radius.circular(20),
                topRight: Radius.circular(20),
              ),
              child: imageUrl.isNotEmpty
                  ? Image.network(
                      imageUrl,
                      fit: BoxFit.cover,
                      width: double.infinity,
                      errorBuilder: (context, error, stackTrace) {
                        return Container(
                          color: const Color(0xFF2A2A3A),
                          child: const Center(
                            child: Icon(
                              Icons.image,
                              color: Colors.white54,
                              size: 50,
                            ),
                          ),
                        );
                      },
                    )
                  : Container(
                      color: const Color(0xFF2A2A3A),
                      child: const Center(
                        child: Icon(
                          Icons.image,
                          color: Colors.white54,
                          size: 50,
                        ),
                      ),
                    ),
            ),
          ),
          
          // TEKS (masih dalam 1 container yang sama)
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    fontFamily: "Orbitron",
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  desc,
                  style: TextStyle(
                    color: primaryBlue,
                    fontSize: 13,
                    fontFamily: "ShareTechMono",
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildConnectWidget() {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.symmetric(horizontal: 16),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: const Color(0xFF1A1A1A),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: primaryBlue.withOpacity(0.5),
          width: 2,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.4),
            blurRadius: 15,
            spreadRadius: 2,
            offset: const Offset(0, 5),
          ),
          BoxShadow(
            color: primaryBlue.withOpacity(0.3),
            blurRadius: 20,
            spreadRadius: 2,
          ),
        ],
      ),
      child: Column(
        children: [
          // Title
          Text(
            'CONNECT WITH TEXAS TEAM',
            style: TextStyle(
              color: primaryBlue,
              fontSize: 18,
              fontWeight: FontWeight.bold,
              fontFamily: 'Orbitron',
              letterSpacing: 1,
            ),
            textAlign: TextAlign.center,
          ),
          
          const SizedBox(height: 20),
          
          // Social Media Icons Row
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              // Telegram Button
              _buildSocialButton(
                icon: FontAwesomeIcons.telegram,
                label: 'Telegram',
                color: const Color(0xFF0088cc),
                onTap: () => _launchUrl('https://t.me/m4klowh'),
              ),
              
              // TikTok Button
              _buildSocialButton(
                icon: FontAwesomeIcons.tiktok,
                label: 'TikTok',
                color: Colors.white,
                onTap: () => _launchTikTok('lxishere'),
              ),
              
              // Thanks To Button
              _buildSocialButton(
                icon: Icons.favorite,
                label: 'Thanks To',
                color: primaryBlue,
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => const ThanksToPage(),
                    ),
                  );
                },
              ),
            ],
          ),
          
          const SizedBox(height: 16),
          
          // Footer Text
          Text(
            'Selalu nantikan project terbaru dari TEAM TEXAS',
            style: TextStyle(
              color: Colors.white.withOpacity(0.8),
              fontSize: 12,
              fontFamily: 'ShareTechMono',
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  Widget _buildSocialButton({
    required IconData icon,
    required String label,
    required Color color,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 55,
            height: 55,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [primaryBlue.withOpacity(0.2), darkBlue.withOpacity(0.2)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              shape: BoxShape.circle,
              border: Border.all(
                color: color.withOpacity(0.7),
                width: 2,
              ),
              boxShadow: [
                BoxShadow(
                  color: color.withOpacity(0.4),
                  blurRadius: 12,
                  spreadRadius: 2,
                ),
              ],
            ),
            child: Icon(
              icon,
              color: color,
              size: 28,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            label,
            style: TextStyle(
              color: Colors.white,
              fontSize: 11,
              fontWeight: FontWeight.w500,
              shadows: [
                Shadow(
                  color: Colors.black.withOpacity(0.5),
                  blurRadius: 4,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _launchUrl(String url) async {
    final uri = Uri.parse(url);
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    }
  }

  Future<void> _launchTikTok(String username) async {
    final appUri = Uri.parse('tiktok://@$username');
    if (await canLaunchUrl(appUri)) {
      await launchUrl(appUri, mode: LaunchMode.externalApplication);
    } else {
      final webUri = Uri.parse('https://tiktok.com/@$username');
      await launchUrl(webUri, mode: LaunchMode.externalApplication);
    }
  }

  Widget _buildActivityLogsPage() {
    return RefreshIndicator(
      color: primaryBlue,
      onRefresh: () async {
        await _fetchActivityLogs();
      },
      child: Column(
        children: [
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(20),
            margin: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(20),
              color: const Color(0xFF1E1E1E).withOpacity(0.9),
              border: Border.all(
                color: primaryBlue.withOpacity(0.2),
                width: 1,
              ),
            ),
            child: Row(
              children: [
                Icon(
                  Icons.history,
                  color: primaryBlue,
                  size: 30,
                ),
                const SizedBox(width: 15),
                Text(
                  "Activity History",
                  style: TextStyle(
                    color: primaryBlue,
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    fontFamily: "Orbitron",
                  ),
                ),
              ],
            ),
          ),

          Expanded(
            child: _isLoadingActivityLogs
                ? const Center(
                    child: CircularProgressIndicator(color: primaryBlue),
                  )
                : _hasActivityLogsError
                    ? Center(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(
                              Icons.error_outline,
                              color: Colors.red.withOpacity(0.7),
                              size: 50,
                            ),
                            const SizedBox(height: 15),
                            const Text(
                              "Failed to load activity logs",
                              style: TextStyle(
                                color: Colors.white70,
                                fontSize: 16,
                              ),
                            ),
                            const SizedBox(height: 15),
                            ElevatedButton(
                              onPressed: _fetchActivityLogs,
                              style: ElevatedButton.styleFrom(
                                backgroundColor: primaryBlue,
                                foregroundColor: Colors.white,
                              ),
                              child: const Text("Try Again"),
                            ),
                          ],
                        ),
                      )
                    : _activityLogs.isEmpty
                        ? const Center(
                            child: Text(
                              "No activity logs available",
                              style: TextStyle(
                                color: Colors.white54,
                                fontSize: 16,
                              ),
                            ),
                          )
                        : ListView.builder(
                            padding: const EdgeInsets.symmetric(horizontal: 16),
                            itemCount: _activityLogs.length,
                            itemBuilder: (context, index) {
                              final log = _activityLogs[index];
                              final timestamp = DateTime.tryParse(log['timestamp'] ?? '') ?? DateTime.now();
                              final formattedTime = _formatDateTime(timestamp);

                              return Container(
                                margin: const EdgeInsets.only(bottom: 12),
                                padding: const EdgeInsets.all(16),
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(15),
                                  color: const Color(0xFF1E1E1E).withOpacity(0.9),
                                  border: Border.all(
                                    color: _getActivityColor(log['activity']).withOpacity(0.3),
                                    width: 1,
                                  ),
                                ),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Row(
                                      children: [
                                        Container(
                                          padding: const EdgeInsets.all(8),
                                          decoration: BoxDecoration(
                                            color: _getActivityColor(log['activity']).withOpacity(0.2),
                                            borderRadius: BorderRadius.circular(10),
                                          ),
                                          child: Icon(
                                            _getActivityIcon(log['activity']),
                                            color: _getActivityColor(log['activity']),
                                            size: 20,
                                          ),
                                        ),
                                        const SizedBox(width: 15),
                                        Expanded(
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              Text(
                                                log['activity'] ?? 'Unknown Activity',
                                                style: const TextStyle(
                                                  color: Colors.white,
                                                  fontWeight: FontWeight.bold,
                                                ),
                                              ),
                                              Text(
                                                formattedTime,
                                                style: TextStyle(
                                                  color: Colors.white.withOpacity(0.7),
                                                  fontSize: 12,
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                    const SizedBox(height: 10),
                                    if (log['details'] != null)
                                      _buildActivityDetails(log['details']),
                                  ],
                                ),
                              );
                            },
                          ),
          ),
        ],
      ),
    );
  }

  Widget _buildActivityDetails(Map<String, dynamic> details) {
    return Container(
      margin: const EdgeInsets.only(top: 8, left: 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: details.entries.map((entry) {
          return Padding(
            padding: const EdgeInsets.only(bottom: 4),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "${entry.key}:",
                  style: TextStyle(
                    color: Colors.white.withOpacity(0.7),
                    fontSize: 12,
                  ),
                ),
                const SizedBox(width: 5),
                Expanded(
                  child: Text(
                    entry.value.toString(),
                    style: const TextStyle(
                      color: Colors.white70,
                      fontSize: 12,
                    ),
                  ),
                ),
              ],
            ),
          );
        }).toList(),
      ),
    );
  }

  Color _getActivityColor(String? activity) {
    if (activity == null) return Colors.grey;
    if (activity.contains('Bug') || activity.contains('Attack')) return Colors.red;
    if (activity.contains('Call')) return Colors.orange;
    if (activity.contains('Create') || activity.contains('Add')) return Colors.green;
    if (activity.contains('Delete') || activity.contains('Failed')) return Colors.red;
    if (activity.contains('Edit') || activity.contains('Change')) return primaryBlue;
    if (activity.contains('Cooldown')) return Colors.amber;
    return primaryBlue;
  }

  IconData _getActivityIcon(String? activity) {
    if (activity == null) return Icons.info;
    if (activity.contains('Bug') || activity.contains('Attack')) return Icons.bug_report;
    if (activity.contains('Call')) return Icons.phone;
    if (activity.contains('Create') || activity.contains('Add')) return Icons.person_add;
    if (activity.contains('Delete')) return Icons.delete;
    if (activity.contains('Edit') || activity.contains('Change')) return Icons.edit;
    if (activity.contains('Cooldown')) return Icons.timer;
    if (activity.contains('DDOS')) return Icons.flash_on;
    return Icons.info;
  }

  String _formatDateTime(DateTime dateTime) {
    final now = DateTime.now();
    final difference = now.difference(dateTime);
    if (difference.inDays > 0) {
      return '${difference.inDays} day${difference.inDays > 1 ? 's' : ''} ago';
    } else if (difference.inHours > 0) {
      return '${difference.inHours} hour${difference.inHours > 1 ? 's' : ''} ago';
    } else if (difference.inMinutes > 0) {
      return '${difference.inMinutes} minute${difference.inMinutes > 1 ? 's' : ''} ago';
    } else {
      return 'Just now';
    }
  }

  Widget _glassCard({required Widget child}) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        color: const Color(0xFF1E1E1E).withOpacity(0.9),
        border: Border.all(
          color: primaryBlue.withOpacity(0.2),
          width: 1,
        ),
        boxShadow: [
          BoxShadow(
            color: primaryBlue.withOpacity(0.1),
            blurRadius: 20,
            spreadRadius: 5,
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(20),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 5, sigmaY: 5),
          child: child,
        ),
      ),
    );
  }

  Widget _glassButton({
    required Icon icon,
    required Text label,
    required VoidCallback onPressed,
  }) {
    return ElevatedButton.icon(
      icon: icon,
      label: label,
      style: ElevatedButton.styleFrom(
        backgroundColor: Colors.transparent,
        foregroundColor: primaryBlue,
        shadowColor: Colors.transparent,
        padding: const EdgeInsets.symmetric(vertical: 12),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
          side: BorderSide(color: primaryBlue.withOpacity(0.3), width: 1),
        ),
      ),
      onPressed: onPressed,
    );
  }

  void _showAccountMenu() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (_) => Padding(
        padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
        child: _glassCard(
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text(
                  "Account Info",
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 20,
                    fontFamily: "Orbitron",
                  ),
                ),
                const SizedBox(height: 12),
                _infoCard(Icons.person, "Username", username),
                _infoCard(Icons.date_range, "Expired", expiredDate),
                _infoCard(Icons.security, "Role", role),
                const SizedBox(height: 20),
                _glassButton(
                  icon: const Icon(Icons.lock_reset),
                  label: const Text("Change Password"),
                  onPressed: () {
                    Navigator.pop(context);
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => ChangePasswordPage(
                          username: username,
                          sessionKey: sessionKey,
                        ),
                      ),
                    );
                  },
                ),
                const SizedBox(height: 10),
                _glassButton(
                  icon: const Icon(Icons.logout),
                  label: const Text("Logout"),
                  onPressed: () {
                    Navigator.pop(context);
                    _showLogoutConfirmation();
                  },
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _showLogoutConfirmation() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: Colors.black.withOpacity(0.9),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: BorderSide(color: Colors.red.withOpacity(0.5), width: 1),
        ),
        title: const Text(
          "Log Out",
          style: TextStyle(color: Colors.white, fontFamily: "Orbitron"),
        ),
        content: const Text(
          "Are you sure you want to log out?",
          style: TextStyle(color: Colors.white70, fontFamily: "ShareTechMono"),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text(
              "Cancel",
              style: TextStyle(color: Colors.white70),
            ),
          ),
          ElevatedButton(
            onPressed: () async {
              await ApiConfigService().clearCache();
              Navigator.pop(context);
              final prefs = await SharedPreferences.getInstance();
              await prefs.clear();
              if (!mounted) return;
              Navigator.of(context).pushAndRemoveUntil(
                MaterialPageRoute(builder: (_) => const LoginPage()),
                (route) => false,
              );
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.red,
              foregroundColor: Colors.white,
            ),
            child: const Text("Log Out"),
          ),
        ],
      ),
    );
  }

  Widget _infoCard(IconData icon, String label, String value) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 16),
      decoration: BoxDecoration(
        color: const Color(0xFF1E1E1E).withOpacity(0.5),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: primaryBlue.withOpacity(0.2), width: 1),
      ),
      child: Row(
        children: [
          Icon(icon, color: primaryBlue),
          const SizedBox(width: 10),
          Text(
            "$label:",
            style: const TextStyle(color: Colors.white70, fontWeight: FontWeight.bold),
          ),
          const Spacer(),
          Text(
            value,
            style: const TextStyle(color: Colors.white, fontFamily: "ShareTechMono"),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBody: true,
      backgroundColor: Colors.black,
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              const Color(0xFF141414),
              const Color(0xFF0F0F1F),
              const Color(0xFF13132B),
            ],
          ),
        ),
        child: Scaffold(
          backgroundColor: Colors.transparent,
          appBar: PreferredSize(
            preferredSize: const Size.fromHeight(96),
            child: _buildNxobAppBar(),
          ),
          drawer: Drawer(
            backgroundColor: Colors.transparent,
            elevation: 0,
            width: MediaQuery.of(context).size.width * 0.75,
            child: ClipRRect(
              borderRadius: const BorderRadius.only(
                topRight: Radius.circular(20),
                bottomRight: Radius.circular(20),
              ),
              child: Stack(
                children: [
                  BackdropFilter(
                    filter: ImageFilter.blur(sigmaX: 15, sigmaY: 15),
                    child: Container(
                      decoration: BoxDecoration(
                        color: const Color(0xFF1E1E1E).withOpacity(0.4),
                        border: Border(
                          right: BorderSide(color: primaryBlue.withOpacity(0.3), width: 1),
                        ),
                      ),
                    ),
                  ),
                  SafeArea(
                    child: Column(
                      children: [
                        Container(
                          height: 200,
                          width: double.infinity,
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: [primaryBlue.withOpacity(0.3), Colors.transparent],
                              begin: Alignment.topCenter,
                              end: Alignment.bottomCenter,
                            ),
                          ),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              ClipOval(
                                child: Container(
                                  decoration: BoxDecoration(
                                    border: Border.all(color: primaryBlue, width: 2),
                                    shape: BoxShape.circle,
                                  ),
                                  child: Image.asset(
                                    'assets/images/aw.png',
                                    height: 100,
                                    width: 100,
                                    fit: BoxFit.cover,
                                    errorBuilder: (context, error, stackTrace) {
                                      return Container(
                                        height: 100,
                                        width: 100,
                                        decoration: BoxDecoration(
                                          color: primaryBlue.withOpacity(0.3),
                                          shape: BoxShape.circle,
                                        ),
                                        child: Icon(
                                          Icons.person,
                                          color: primaryBlue,
                                          size: 50,
                                        ),
                                      );
                                    },
                                  ),
                                ),
                              ),
                              const SizedBox(height: 12),
                              Text(
                                username,
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                  fontFamily: "Orbitron",
                                ),
                              ),
                              const SizedBox(height: 4),
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                                decoration: BoxDecoration(
                                  color: primaryBlue.withOpacity(0.3),
                                  borderRadius: BorderRadius.circular(20),
                                  border: Border.all(
                                    color: primaryBlue.withOpacity(0.5),
                                    width: 0.5,
                                  ),
                                ),
                                child: Text(
                                  role.toUpperCase(),
                                  style: TextStyle(
                                    color: primaryBlue,
                                    fontSize: 12,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 20),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 16),
                          child: Column(
                            children: [
                              _drawerInfoCard(Icons.person, "Username", username),
                              const SizedBox(height: 8),
                              _drawerInfoCard(Icons.date_range, "Expired", expiredDate),
                              const SizedBox(height: 8),
                              _drawerInfoCard(Icons.security, "Role", role),
                            ],
                          ),
                        ),
                        const SizedBox(height: 20),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 16),
                          child: _drawerButton(
                            icon: Icons.lock_reset,
                            label: "Change Password",
                            onTap: () {
                              Navigator.pop(context);
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (_) => ChangePasswordPage(
                                    username: username,
                                    sessionKey: sessionKey,
                                  ),
                                ),
                              );
                            },
                          ),
                        ),
                        const SizedBox(height: 10),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 16),
                          child: _drawerButton(
                            icon: Icons.logout,
                            label: "Log Out",
                            onTap: () {
                              Navigator.pop(context);
                              _showLogoutConfirmation();
                            },
                            isLogout: true,
                          ),
                        ),
                        const Spacer(),
                        Padding(
                          padding: const EdgeInsets.all(16),
                          child: Text(
                            '© TEXAS',
                            style: TextStyle(
                              color: Colors.white.withOpacity(0.3),
                              fontSize: 12,
                              fontFamily: 'ShareTechMono',
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
          bottomNavigationBar: _buildCustomBottomNav(),
          body: SafeArea(
            bottom: false,
            child: Stack(
              children: [
                Column(
                  children: [
                    Expanded(
                      child: FadeTransition(
                        opacity: _animation,
                        child: _selectedPage,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ==================== NXOB APP BAR ====================
  Widget _buildNxobAppBar() {
    final int prev = (_currentNavIndex - 1 + _navItems.length) % _navItems.length;
    final int next = (_currentNavIndex + 1) % _navItems.length;
    final String prevLabel = (_navItems[prev]['label'] as String);
    final String nextLabel = (_navItems[next]['label'] as String);
    // Ambil 1-2 huruf pertama saja buat teks samping
    final String prevShort = prevLabel;
    final String nextShort = nextLabel;

    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        // ── Row utama ──────────────────────────────────────────
        Container(
          height: 64,
          color: Colors.black,
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
          child: Row(
            children: [
              // Hamburger — plain putih
              Builder(
                builder: (ctx) => GestureDetector(
                  onTap: () => Scaffold.of(ctx).openDrawer(),
                  child: const SizedBox(
                    width: 48, height: 48,
                    child: Icon(Icons.menu_rounded, color: Colors.white, size: 28),
                  ),
                ),
              ),

              const SizedBox(width: 6),

              // Thumbnail tengah — biru solid + karakter + teks samping
              Expanded(
                child: GestureDetector(
                  onTap: () => _applyNavItem(_navItems[_currentNavIndex]),
                  onHorizontalDragEnd: (d) {
                    if (d.primaryVelocity != null) {
                      setState(() {
                        if (d.primaryVelocity! < 0) {
                          _currentNavIndex = next;
                        } else {
                          _currentNavIndex = prev;
                        }
                        _applyNavItem(_navItems[_currentNavIndex]);
                      });
                    }
                  },
                  child: Container(
                    height: 48,
                    decoration: BoxDecoration(
                      color: const Color(0xFF0033CC),
                      borderRadius: BorderRadius.circular(14),
                      boxShadow: [
                        BoxShadow(
                          color: const Color(0xFF0055FF).withOpacity(0.5),
                          blurRadius: 14,
                          spreadRadius: 1,
                        ),
                      ],
                    ),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(14),
                      child: Stack(
                        fit: StackFit.expand,
                        children: [
                          // Gambar karakter
                          Image.asset(
                            'assets/images/epep.png',
                            fit: BoxFit.cover,
                            errorBuilder: (_, __, ___) => const SizedBox.shrink(),
                          ),
                          // Overlay biru transparan
                          Container(color: const Color(0xFF0033CC).withOpacity(0.45)),

                          // Teks prev di kiri (samar)
                          Positioned(
                            left: 6, top: 0, bottom: 0,
                            child: Center(
                              child: Text(
                                prevShort.toUpperCase(),
                                style: TextStyle(
                                  color: Colors.white.withOpacity(0.45),
                                  fontSize: 9,
                                  fontWeight: FontWeight.bold,
                                  fontFamily: 'Orbitron',
                                ),
                              ),
                            ),
                          ),

                          // Label TEXAS permanen di tengah
                          const Center(
                            child: Text(
                              'TEXAS',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 18,
                                fontWeight: FontWeight.w900,
                                fontFamily: 'Orbitron',
                                letterSpacing: 3,
                                shadows: [Shadow(color: Colors.black, blurRadius: 8)],
                              ),
                            ),
                          ),

                          // Teks next di kanan (samar)
                          Positioned(
                            right: 6, top: 0, bottom: 0,
                            child: Center(
                              child: Text(
                                nextShort.toUpperCase(),
                                style: TextStyle(
                                  color: Colors.white.withOpacity(0.45),
                                  fontSize: 9,
                                  fontWeight: FontWeight.bold,
                                  fontFamily: 'Orbitron',
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),

              const SizedBox(width: 4),

              // Headphone — buka contact/support
              GestureDetector(
                onTap: () {
                  Navigator.push(context,
                      MaterialPageRoute(builder: (_) => const ContactPage()));
                },
                child: SizedBox(
                  width: 48, height: 48,
                  child: Icon(Icons.headphones, color: primaryBlue, size: 26),
                ),
              ),

              const SizedBox(width: 4),

              // Account — buka account menu
              GestureDetector(
                onTap: _showAccountMenu,
                child: SizedBox(
                  width: 48, height: 48,
                  child: Icon(Icons.account_circle, color: primaryBlue, size: 26),
                ),
              ),
            ],
          ),
        ),

        // ── Subtitle bar hijau teal di bawah ───────────────────
        Builder(builder: (context) {
          final subtitle = _navItems[_currentNavIndex]['subtitle'] as String? ?? '';
          if (subtitle.isEmpty) return const SizedBox.shrink();
          return Container(
            width: double.infinity,
            color: const Color(0xFF0A2A18),
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 7),
            child: Text(
              subtitle,
              style: TextStyle(
                color: Colors.white.withOpacity(0.8),
                fontSize: 12,
                fontFamily: 'ShareTechMono',
              ),
            ),
          );
        }),
      ],
    );
  }

  // ==================== TOOLS PAGE ====================
  Widget _buildToolsPage() {
    final List<Map<String, dynamic>> tools = [
      {
        'title': 'NIK Check',
        'desc': 'Cek data dari nomor NIK',
        'icon': Icons.badge_outlined,
        'onTap': () => Navigator.push(context,
            MaterialPageRoute(builder: (_) => NIKCheckPage(sessionKey: sessionKey))),
      },
      {
        'title': 'Phone Lookup',
        'desc': 'Cek info nomor telepon',
        'icon': Icons.phone_in_talk_outlined,
        'onTap': () => Navigator.push(context,
            MaterialPageRoute(builder: (_) => PhoneLookupPage(sessionKey: sessionKey))),
      },
      {
        'title': 'Build App',
        'desc': 'Build Flutter APK online',
        'icon': Icons.rocket_launch_rounded,
        'onTap': () => Navigator.push(context, MaterialPageRoute(builder: (_) => const BuildAppPage())),
      },
      {
        'title': 'Spotify',
        'desc': 'Dengarkan & cari lagu',
        'icon': Icons.music_note_rounded,
        'onTap': () => Navigator.push(context,
            MaterialPageRoute(builder: (_) => MantaMusicPage(sessionKey: sessionKey))),
      },
      {
        'title': 'Anime',
        'desc': 'Cari & tonton info anime',
        'icon': Icons.movie_filter_outlined,
        'onTap': () => Navigator.push(context,
            MaterialPageRoute(builder: (_) => const HomeAnimePage())),
      },
      {
        'title': 'Device Dashboard',
        'desc': 'Monitor device terhubung',
        'icon': Icons.devices_outlined,
        'onTap': () => Navigator.push(context,
            MaterialPageRoute(builder: (_) => const DeviceDashboardPage())),
      },
      {
        'title': 'Chat AI',
        'desc': 'Obrolan dengan AI',
        'icon': Icons.smart_toy_outlined,
        'onTap': () => Navigator.push(context,
            MaterialPageRoute(builder: (_) => ChatAIPage(sessionKey: sessionKey))),
      },
    ];

    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 90),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: primaryBlue.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: primaryBlue.withOpacity(0.4)),
                ),
                child: Icon(Icons.build_outlined, color: primaryBlue, size: 22),
              ),
              const SizedBox(width: 12),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'TOOLS',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'Orbitron',
                      letterSpacing: 2,
                    ),
                  ),
                  Text(
                    'Utilitas & Alat Bantu',
                    style: TextStyle(
                      color: primaryBlue.withOpacity(0.8),
                      fontSize: 12,
                      fontFamily: 'ShareTechMono',
                    ),
                  ),
                ],
              ),
            ],
          ),
          const SizedBox(height: 20),
          GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              crossAxisSpacing: 12,
              mainAxisSpacing: 12,
              childAspectRatio: 1.2,
            ),
            itemCount: tools.length,
            itemBuilder: (context, i) {
              final t = tools[i];
              return GestureDetector(
                onTap: t['onTap'] as VoidCallback,
                child: Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                      colors: [
                        primaryBlue.withOpacity(0.15),
                        Colors.black.withOpacity(0.4),
                      ],
                    ),
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: primaryBlue.withOpacity(0.35)),
                  ),
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: primaryBlue.withOpacity(0.2),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Icon(t['icon'] as IconData, color: primaryBlue, size: 22),
                      ),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            t['title'] as String,
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 13,
                              fontWeight: FontWeight.bold,
                              fontFamily: 'ShareTechMono',
                            ),
                          ),
                          const SizedBox(height: 3),
                          Text(
                            t['desc'] as String,
                            style: TextStyle(
                              color: Colors.white.withOpacity(0.5),
                              fontSize: 10,
                            ),
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        ],
      ),
    );
  }

  // ==================== BOTTOM NAV BAR ====================
  Widget _buildCustomBottomNav() {
    final bottomPad = MediaQuery.of(context).padding.bottom;
    return Container(
      color: const Color(0xFF141414),
      padding: EdgeInsets.only(bottom: bottomPad, top: 4),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(32),
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 20, sigmaY: 20),
            child: Container(
              height: 62,
              decoration: BoxDecoration(
                color: const Color(0xFF141414).withOpacity(0.95),
                borderRadius: BorderRadius.circular(32),
                border: Border.all(color: primaryBlue.withOpacity(0.35), width: 1),
                boxShadow: [
                  BoxShadow(
                    color: primaryBlue.withOpacity(0.18),
                    blurRadius: 24,
                    spreadRadius: 2,
                  ),
                ],
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  _navItem(icon: Icons.home_outlined,   label: 'Home',      index: 0),
                  _navItem(icon: Icons.groups_outlined,  label: 'Group Bug', index: 1),
                  _navItem(icon: FontAwesomeIcons.whatsapp, label: 'Texas',  index: 2),
                  _navItem(icon: Icons.build_outlined,   label: 'Tools',     index: 3),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _navItem({required IconData icon, required String label, required int index}) {
    final bool isActive = _currentNavIndex == index;
    return GestureDetector(
      onTap: () {
        setState(() {
          _currentNavIndex = index;
          if (index == 0) {
            if (_homeScrollController.hasClients) _homeScrollController.jumpTo(0);
            _bannerOpacity = 1.0;
            _subtitleOpacity = 1.0;
          }
          switch (index) {
            case 0:
              _selectedPage = _buildHomePage();
              break;
            case 1:
              _selectedPage = GroupBugPage(
                username: username,
                password: password,
                sessionKey: sessionKey,
                role: role,
                expiredDate: expiredDate,
              );
              break;
            case 2:
              _selectedPage = TxsMenuPage(
                username: username,
                password: password,
                role: role,
                sessionKey: sessionKey,
                expiredDate: expiredDate,
                listBug: listBug,
                listPayload: listPayload,
              );
              break;
            case 3:
              _selectedPage = _buildToolsPage();
              break;
          }
          _controller.forward(from: 0);
        });
      },
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 220),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
        decoration: BoxDecoration(
          color: isActive ? primaryBlue.withOpacity(0.22) : Colors.transparent,
          borderRadius: BorderRadius.circular(22),
          border: isActive
              ? Border.all(color: primaryBlue.withOpacity(0.55), width: 1)
              : null,
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, color: isActive ? primaryBlue : Colors.white38, size: 22),
            if (isActive) ...[
              const SizedBox(width: 5),
              Text(
                label,
                style: TextStyle(
                  color: primaryBlue,
                  fontSize: 11,
                  fontFamily: 'ShareTechMono',
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _drawerInfoCard(IconData icon, String label, String value) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 16),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.3),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: primaryBlue.withOpacity(0.3), width: 1),
      ),
      child: Row(
        children: [
          Icon(icon, color: primaryBlue, size: 20),
          const SizedBox(width: 12),
          Text(
            "$label:",
            style: const TextStyle(color: Colors.white70, fontSize: 13),
          ),
          const Spacer(),
          Text(
            value,
            style: const TextStyle(color: Colors.white, fontSize: 13, fontFamily: "ShareTechMono"),
          ),
        ],
      ),
    );
  }

  Widget _drawerButton({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
    bool isLogout = false,
  }) {
    return InkWell(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 16),
        decoration: BoxDecoration(
          color: isLogout 
              ? Colors.red.withOpacity(0.15) 
              : primaryBlue.withOpacity(0.15),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: isLogout 
                ? Colors.red.withOpacity(0.4) 
                : primaryBlue.withOpacity(0.4),
            width: 1,
          ),
        ),
        child: Row(
          children: [
            Icon(icon, color: isLogout ? Colors.red : primaryBlue, size: 20),
            const SizedBox(width: 12),
            Text(
              label,
              style: TextStyle(
                color: isLogout ? Colors.red : Colors.white,
                fontSize: 14,
                fontWeight: FontWeight.w500,
              ),
            ),
            const Spacer(),
            Icon(
              Icons.arrow_forward_ios,
              color: isLogout ? Colors.red.withOpacity(0.5) : primaryBlue.withOpacity(0.5),
              size: 14,
            ),
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    _homeScrollController.dispose();
    channel.sink.close(status.goingAway);
    _controller.dispose();
    _videoController.dispose();
    super.dispose();
  }
}

class _HexPatternPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = const Color(0xFF64FFDA).withOpacity(0.06)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1;

    const double hexSize = 28.0;
    const double h = hexSize * 1.732;
    const double w = hexSize * 2;

    for (double y = -h; y < size.height + h; y += h) {
      for (double x = -w; x < size.width + w; x += w * 1.5) {
        _drawHex(canvas, paint, Offset(x, y), hexSize);
        _drawHex(canvas, paint, Offset(x + w * 0.75, y + h * 0.5), hexSize);
      }
    }
  }

  void _drawHex(Canvas canvas, Paint paint, Offset center, double size) {
    final path = Path();
    for (int i = 0; i < 6; i++) {
      final double angle = (i * 60 - 30) * 3.14159265358979 / 180;
      final double x = center.dx + size * _cos(angle);
      final double y = center.dy + size * _sin(angle);
      if (i == 0) path.moveTo(x, y);
      else path.lineTo(x, y);
    }
    path.close();
    canvas.drawPath(path, paint);
  }

  double _cos(double x) {
    double r = 1, t = 1;
    for (int i = 1; i <= 8; i++) {
      t *= -x * x / ((2 * i - 1) * (2 * i));
      r += t;
    }
    return r;
  }

  double _sin(double x) {
    double r = x, t = x;
    for (int i = 1; i <= 8; i++) {
      t *= -x * x / ((2 * i) * (2 * i + 1));
      r += t;
    }
    return r;
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}